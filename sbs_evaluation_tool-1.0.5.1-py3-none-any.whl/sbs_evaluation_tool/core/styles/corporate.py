import os
import base64
from typing import Dict, Optional, Tuple

COLORS: Dict[str, str] = {
    # Core brand palette — these are the only ones tests should reference by name.
    # `ORANGE` is the single warning-level colour. The historical `YELLOW`
    # slot was folded into ORANGE (warning-orange) during the colour
    # unification pass — see CLAUDE.md.
    'GREEN': '#21A038',     # primary green (traffic light)
    'GREEN_LIGHT': '#A8D08D', # light green fill
    'EMERALD': '#21BA72',   # chart lines / fills
    'GRASS': '#00D900',     # TRAIN histogram fill
    'ORANGE': '#ff7f0e',    # warning / 95 % CI band
    'RED': '#fa1929',       # primary red
    'BLUE': '#1f77b4',      # info / secondary line
    'GRAY': '#7f7f7f',      # neutral
    'TEXT': '#333F48',      # corporate text

    # Extended slots — added during the chart-style unification pass to absorb
    # all hardcoded hex values that previously lived in test files. Add new
    # named slots here when a chart genuinely needs a colour outside the core
    # palette; do NOT inline a raw hex in a test module.
    'RED_DARK': '#d62728',
    'RED_LIGHT': '#FF6B6B',
    'GOLD': '#FFD700',
    'NAVY': '#000080',
    'GRAY_DARK': '#6d6d6d',
    'GRID': '#cccccc',
    'GRID_LIGHT': '#dddddd',
    'BG_PANEL': '#f8f9fa',
    'TAB_TEXT': '#2b2f38',
}


# Standard chart sizes — picked to cover every plot type produced by the
# library after auditing the codebase (which previously used 21 distinct
# figsize tuples). New plots should choose one of these four; ad-hoc tuples
# in test files are flagged by the visual language guard.
FIGURE_SIZES: Dict[str, Tuple[float, float]] = {
    'small':  (6, 4),     # compact (ROC, single-panel summaries)
    'medium': (10, 6),    # default for most plots
    'large':  (12, 7),    # detailed plots with legends / annotated tables
    'wide':   (14, 5),    # very wide time series
    'short':  (12, 4),    # short-wide (calibration curves, narrow timelines)
}


def figure(size='medium', **kwargs):
    """Standardized matplotlib figure creator.

    Use this instead of ``plt.subplots(figsize=(...))`` in every test plot.
    The ``size`` argument accepts either:

    - a preset name from :data:`FIGURE_SIZES` (``"small"``, ``"medium"``,
      ``"large"``, ``"wide"``, ``"short"``); or
    - a ``(width, height)`` tuple in inches, when the plot genuinely needs a
      size derived from data shape (e.g. one row per feature, scaling with
      ``len(features)``). This is the escape hatch for dynamic sizing — the
      visual language guard accepts it but rejects raw ``plt.subplots`` calls
      so the styling stays auditable.

    Extra kwargs (``ncols=``, ``sharex=``, ...) flow through to ``plt.subplots``.

    Raises
    ------
    ValueError
        If ``size`` is a string not in :data:`FIGURE_SIZES`.
    """
    import matplotlib.pyplot as plt
    if isinstance(size, str):
        if size not in FIGURE_SIZES:
            raise ValueError(
                f"Unknown chart size {size!r}; choose one of {sorted(FIGURE_SIZES)}"
            )
        figsize = FIGURE_SIZES[size]
    else:
        figsize = tuple(size)
    return plt.subplots(figsize=figsize, **kwargs)

# Сопоставление статусов к корпоративным цветам.
# Warning-уровень всегда `orange` — исторический ключ `yellow` снят полностью
# (см. CLAUDE.md «Conventions discovered the hard way»).
STATUS_COLORS: Dict[str, str] = {
    'green': COLORS['GREEN'],
    'orange': COLORS['ORANGE'],
    'red': COLORS['RED'],
    'blue': COLORS['BLUE'],
    'gray': COLORS['GRAY'],
}

# Папка для шрифтов (положить сюда .ttf)
FONTS_DIR = os.path.join(os.path.dirname(__file__), 'fonts')
ASSETS_DIR = os.path.join(os.path.dirname(__file__), 'assets')


def _hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
    hex_color = hex_color.lstrip('#')
    if len(hex_color) == 3:
        hex_color = ''.join([c*2 for c in hex_color])
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))


def rgba(hex_color: str, alpha: float) -> str:
    r, g, b = _hex_to_rgb(hex_color)
    a = max(0.0, min(1.0, float(alpha)))
    return f"rgba({r}, {g}, {b}, {a})"


def load_first_font_in_dir(dir_path: str) -> Optional[str]:
    try:
        for name in os.listdir(dir_path):
            lower = name.lower()
            if lower.endswith('.ttf') or lower.endswith('.otf'):
                return os.path.join(dir_path, name)
    except Exception:
        return None
    return None


def apply_matplotlib_style(font_path: Optional[str] = None) -> None:
    """Применяет корпоративный стиль к Matplotlib (цвета и шрифты).

    - Настраивает семейство шрифтов, если найден .ttf (либо в font_path, либо первый в FONTS_DIR)
    - Задаёт стандартный цветовой цикл с упором на изумрудный для линий
    - Не трогает прозрачности (alpha) — остаются на уровне, задаваемом конкретными графиками
    """
    try:
        import matplotlib as mpl
        from matplotlib import font_manager

        # Шрифт: берём явный путь или первый .ttf из FONTS_DIR
        font_to_use = font_path or load_first_font_in_dir(FONTS_DIR)
        if font_to_use and os.path.isfile(font_to_use):
            try:
                font_manager.fontManager.addfont(font_to_use)
                font_name = font_manager.FontProperties(fname=font_to_use).get_name()
                mpl.rcParams['font.family'] = font_name
            except Exception:
                pass

        # Цветовой цикл (первым — EMERALD)
        emerald = COLORS['EMERALD']
        green = COLORS['GREEN']
        orange = COLORS['ORANGE']
        red = COLORS['RED']
        blue = COLORS['BLUE']
        gray = '#6d6d6d'
        mpl.rcParams['axes.prop_cycle'] = mpl.cycler(color=[emerald, blue, green, gray, red, orange])

        # Сетка/ось — более нейтральные
        mpl.rcParams['grid.color'] = '#cccccc'
        mpl.rcParams['axes.edgecolor'] = '#444444'
        mpl.rcParams['xtick.color'] = '#333333'
        mpl.rcParams['ytick.color'] = '#333333'

    except Exception:
        # Тихий фоллбэк — не ломаем исполнение, если Matplotlib недоступен
        pass


def _detect_font_format(ext: str) -> str:
    ext = ext.lower().lstrip('.')
    if ext == 'ttf':
        return 'truetype'
    if ext == 'otf':
        return 'opentype'
    # generic default
    return 'truetype'


def generate_font_face_css(font_path: Optional[str] = None, font_family: str = 'Corporate') -> str:
    """Генерирует CSS с встраиванием шрифта через @font-face (base64) и применением к <body>.

    Если файл шрифта не найден, возвращает CSS только с семейством запасных системных шрифтов.
    """
    # Пытаемся найти шрифт: явный путь или первый из папки FONTS_DIR
    path = font_path or load_first_font_in_dir(FONTS_DIR)
    if path and os.path.isfile(path):
        try:
            with open(path, 'rb') as f:
                data = f.read()
            b64 = base64.b64encode(data).decode('ascii')
            fmt = _detect_font_format(os.path.splitext(path)[1])
            # Используем data: URL с base64
            font_face = (
                f"@font-face {{\n"
                f"  font-family: '{font_family}';\n"
                f"  src: url(data:font/{fmt};charset=utf-8;base64,{b64}) format('{fmt}');\n"
                f"  font-weight: normal;\n"
                f"  font-style: normal;\n"
                f"  font-display: swap;\n"
                f"}}\n"
            )
            body_css = (
                f"body {{\n"
                f"  font-family: '{font_family}', -apple-system, 'Segoe UI', Arial, Helvetica, sans-serif;\n"
                f"  color: {COLORS['TEXT']};\n"
                f"}}\n"
            )
            return font_face + body_css
        except Exception:
            # Фоллбэк — только системные шрифты
            pass

    # Без встроенного шрифта: система + запасные
    return (
        "body {\n"
        "  font-family: -apple-system, 'Segoe UI', Arial, Helvetica, sans-serif;\n"
        f"  color: {COLORS['TEXT']};\n"
        "}\n"
    )


def get_logo_data_uri() -> Optional[str]:
    """Ищет логотип в ASSETS_DIR и возвращает data URI.

    Приоритетные имена: sber_logo.svg/png/jpg/jpeg, затем logo.*. Возвращает None, если файл не найден.
    """
    try:
        base_dir = os.path.dirname(__file__)
        search_dirs = [
            ASSETS_DIR,
            os.path.join(os.path.dirname(base_dir), 'assets'),  # core/assets
            os.path.join(os.path.dirname(os.path.dirname(base_dir)), 'assets'),  # <project>/assets
            base_dir,  # allow dropping logo next to this file
        ]
        allowed_exts = ('.svg', '.png', '.jpg', '.jpeg')
        candidates = [
            'sber_logo.svg', 'sber_logo.png', 'sber_logo.jpg', 'sber_logo.jpeg',
            'logo.svg', 'logo.png', 'logo.jpg', 'logo.jpeg',
        ]

        def encode_path(path: str) -> Optional[str]:
            ext = os.path.splitext(path)[1].lower()
            if ext == '.svg':
                mime = 'image/svg+xml'
            elif ext in ('.jpg', '.jpeg'):
                mime = 'image/jpeg'
            elif ext == '.png':
                mime = 'image/png'
            else:
                return None
            with open(path, 'rb') as f:
                b64 = base64.b64encode(f.read()).decode('ascii')
            return f"data:{mime};base64,{b64}"

        for d in search_dirs:
            if not os.path.isdir(d):
                continue
            # First, try prioritized names
            for name in candidates:
                path = os.path.join(d, name)
                if os.path.isfile(path):
                    uri = encode_path(path)
                    if uri:
                        return uri
            # Else, try any file starting with sber_logo or logo
            try:
                for name in os.listdir(d):
                    lower = name.lower()
                    if (lower.startswith('sber_logo') or lower.startswith('logo')) and lower.endswith(allowed_exts):
                        path = os.path.join(d, name)
                        uri = encode_path(path)
                        if uri:
                            return uri
            except Exception:
                continue
    except Exception:
        return None
    return None
