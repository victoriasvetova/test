"""GLM coefficient table → per-row scoring/value columns.

A multiplicative GLM (Poisson / Gamma with log link) is delivered to us
as an Excel coefficient table: one block per feature, each block listing
(level, multiplicative coefficient) pairs. Predicted rate for a row is::

    rate = intercept * EXP * prod_f coef_f(level_f(row))

This module turns that table into two derived columns per feature:

* ``<feature>_SCORING`` — the multiplicative coefficient looked up by level
  (1.0 = baseline). Used by ranking tests M2.2 / M2.4 / M5.2 / M5.4.
* ``<feature>_VALUE``   — ``ln(<feature>_SCORING)`` — the additive
  contribution on the linear-predictor scale. Used by M3.1 / M3.2.

Workflow::

    from sbs_evaluation_tool.core.glm_scoring import parse_glm_model, apply_glm_scoring

    model = parse_glm_model('Model Frequency total damage_GLM.xlsx')
    df = apply_glm_scoring(df, model)        # adds *_SCORING and *_VALUE
    run_sbs_evaluation(df, config, ...)

The Excel layout this parser understands (the format actuaries hand over):

* a single sheet with a leading "Base" row giving the intercept
* a header row with feature names placed at every third column
  (columns ``[0, 3, 6, 9, 12, ...]``)
* under each feature column ``c`` the next rows hold (level, coef) at
  ``(c, c+1)``; the diagnostics block ("Orthogonal Polynomial Equations",
  "Factor / Variate / Input ...") at the bottom is ignored.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, Optional, Union

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class GLMModel:
    """Parsed GLM coefficient table.

    Attributes
    ----------
    intercept
        Multiplicative intercept (``Base`` cell in the Excel).
    features
        ``{feature_name: {level: multiplicative_coefficient}}``. ``level``
        keys are kept in the dtype they appear in the Excel (string for
        ranges/categories, int/float for numeric bin codes).
    source
        Path the model was parsed from, for diagnostics.
    """

    intercept: float
    features: Dict[str, Dict[object, float]] = field(default_factory=dict)
    source: Optional[str] = None

    def feature_names(self) -> list[str]:
        return list(self.features.keys())


def parse_glm_model(
    path: Union[str, Path],
    *,
    sheet: Union[str, int] = 0,
    feature_header_row: int = 4,
    data_start_row: int = 7,
    intercept_cell: tuple = (1, 2),
) -> GLMModel:
    """Parse the GLM coefficient Excel into a :class:`GLMModel`.

    Defaults match the reference file we have on hand
    (``Model Frequency total damage_GLM.xlsx``); the named arguments
    exist so a slightly differently-shaped sheet can be opened without
    code edits.

    Parameters
    ----------
    path
        Excel file location.
    sheet
        Sheet name or index. Defaults to the first sheet.
    feature_header_row
        0-indexed row that contains feature names at columns
        ``[0, 3, 6, ...]``.
    data_start_row
        0-indexed first row of (level, coef) pairs.
    intercept_cell
        ``(row, col)`` of the multiplicative intercept ("Base" value).

    Raises
    ------
    ValueError
        If the intercept cell is empty / non-numeric or no feature header
        is found at ``feature_header_row``.
    """
    path = Path(path)
    raw = pd.read_excel(path, sheet_name=sheet, header=None)

    r_int, c_int = intercept_cell
    intercept_val = raw.iat[r_int, c_int]
    if pd.isna(intercept_val):
        raise ValueError(
            f"Intercept cell {intercept_cell} in {path.name} is empty — "
            f"check intercept_cell argument."
        )
    intercept = float(intercept_val)

    header = raw.iloc[feature_header_row]
    feat_cols: dict[str, int] = {}
    for c in header.index:
        v = header[c]
        if isinstance(v, str) and v.strip():
            feat_cols[v.strip()] = int(c)
    if not feat_cols:
        raise ValueError(
            f"No feature names found at row {feature_header_row} in {path.name}."
        )

    # Locate the diagnostics block (Orthogonal Polynomial Equations /
    # Factor / Variate ...) so feature columns that share their numeric
    # row layout (e.g. col 6 = "Input" in diagnostics) don't pick up
    # spurious levels. The block always lives in col 0.
    n_rows = len(raw)
    stop_row = n_rows
    col0 = raw.iloc[:, 0]
    for i in range(data_start_row, n_rows):
        v = col0.iat[i]
        if isinstance(v, str) and (v.startswith("Orthogonal") or v == "Factor"):
            stop_row = i
            break

    features: Dict[str, Dict[object, float]] = {}
    for fname, c in feat_cols.items():
        pairs: dict[object, float] = {}
        for i in range(data_start_row, stop_row):
            level = raw.iat[i, c]
            coef = raw.iat[i, c + 1]
            if pd.isna(level) or pd.isna(coef):
                continue
            try:
                coef_f = float(coef)
            except (TypeError, ValueError):
                continue
            pairs[level] = coef_f
        features[fname] = pairs
        logger.debug("Parsed %d levels for %s", len(pairs), fname)

    return GLMModel(intercept=intercept, features=features, source=str(path))


def apply_glm_scoring(
    df: pd.DataFrame,
    model: GLMModel,
    *,
    features: Optional[Iterable[str]] = None,
    scoring_suffix: str = "_SCORING",
    value_suffix: str = "_VALUE",
    baseline: float = 1.0,
    overwrite: bool = False,
) -> pd.DataFrame:
    """Attach ``<f>_SCORING`` and ``<f>_VALUE`` columns to ``df``.

    For every feature ``f`` in ``model``:

    * ``df[f + scoring_suffix]`` = multiplicative coefficient looked up
      from ``model.features[f]`` by row value; rows whose level is not
      in the coefficient table fall back to ``baseline`` (the GLM's
      reference category, conventionally ``1.0``).
    * ``df[f + value_suffix]``  = ``ln(df[f + scoring_suffix])``.

    Returns a new DataFrame (does not mutate the caller's copy).

    Parameters
    ----------
    df
        Input frame with the raw feature columns referenced in ``model``.
    model
        Parsed :class:`GLMModel`.
    features
        Restrict scoring to this subset; defaults to every feature in
        the model. Names not found in ``df.columns`` are skipped with a
        warning.
    scoring_suffix, value_suffix
        Suffix appended to the raw feature name. Must differ.
    baseline
        Value substituted when a row's level is missing from the
        coefficient table (typically ``1.0``).
    overwrite
        If False (default) and the target column already exists, that
        feature is skipped with a warning. Set to True to recompute.

    Notes
    -----
    Per-feature coverage is logged: a coefficient table that misses
    levels actually present in the data is the most common silent bug
    in tariff inference, so the count of fallback rows is surfaced at
    ``logger.warning`` whenever it is non-zero.
    """
    if scoring_suffix == value_suffix:
        raise ValueError("scoring_suffix and value_suffix must differ.")

    out = df.copy()
    targets = list(features) if features is not None else list(model.features.keys())

    for fname in targets:
        if fname not in out.columns:
            logger.warning("apply_glm_scoring: %s not in dataframe — skipping.", fname)
            continue
        coefs = model.features.get(fname)
        if not coefs:
            logger.warning("apply_glm_scoring: no coefficients for %s — skipping.", fname)
            continue

        sc_col = fname + scoring_suffix
        va_col = fname + value_suffix
        if (sc_col in out.columns or va_col in out.columns) and not overwrite:
            logger.info(
                "apply_glm_scoring: %s / %s already present, leaving untouched "
                "(pass overwrite=True to recompute).",
                sc_col, va_col,
            )
            continue

        # Build mapping series; pandas .map handles arbitrary key dtypes.
        # If the source column is numeric but the keys are stored as
        # numpy ints/floats with the same value, .map still matches.
        mapped = out[fname].map(coefs)

        # Coefficient tables sometimes encode integer levels as Python
        # ints while the data column is float (no NaN-side-effect of
        # pandas type promotion). Retry against an int-cast view when
        # the first pass missed almost everything.
        if mapped.isna().mean() > 0.5:
            try:
                retry = out[fname].astype("Int64").map(coefs)
                if retry.isna().mean() < mapped.isna().mean():
                    mapped = retry
            except (TypeError, ValueError):
                pass

        n_missing = int(mapped.isna().sum())
        if n_missing:
            logger.warning(
                "apply_glm_scoring: %s — %d/%d rows have no coefficient "
                "(level not in table), falling back to baseline=%s.",
                fname, n_missing, len(out), baseline,
            )
        scoring = mapped.fillna(baseline).astype(float)

        out[sc_col] = scoring
        # ln(baseline)=0 for baseline=1.0 (the typical case), which is
        # also the correct additive contribution on the linear-predictor
        # scale, so missing-level rows neutralise both columns at once.
        with np.errstate(divide="ignore"):
            out[va_col] = np.log(scoring.to_numpy())

    return out


__all__ = ["GLMModel", "parse_glm_model", "apply_glm_scoring"]
