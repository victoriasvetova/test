"""Distribution × architecture presets for SBS Evaluation.

A *preset* is an immutable bundle of every default that the methodology
specifies for a given (distribution, architecture) combination. Picking a
preset is the user-facing way to say "I'm validating a Poisson GLM on
claim counts with exposure weighting" without having to know which test
groups apply, what shape the calibration CI should take, or what
threshold to put on VIF.

Presets are *data*, not behaviour: they record the choices, but the
runner / strategy / individual tests read them and act accordingly.
That keeps the methodology mapping inspectable in one place.

Five presets cover the cases we currently support:

    POISSON_GLM        — frequency GLM (claim counts, log link, exposure)
    GAMMA_GLM          — severity GLM (claim amounts, log link, claim-count weight)
    POISSON_BLACKBOX   — tree/NN frequency model (predicting expected rate)
    GAMMA_BLACKBOX     — tree/NN severity model (predicting expected amount)
    BINARY_BLACKBOX    — PD BlackBox (0/1 default flag, probability output)

Add a new preset by appending another :class:`ValidationPreset` instance
to this file plus a row in :data:`ALL_PRESETS`. Test classes that need
per-preset behaviour should look at the preset fields directly rather
than hardcoding "if model_mode == 'frequency'" branches.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, FrozenSet, Literal


Distribution = Literal["poisson", "gamma", "binary"]
Architecture = Literal["glm", "blackbox"]
Task = Literal["regression", "classification"]
WeightRole = Literal["exposure", "claim_count", "none"]
M3Variant = Literal["glm_vif_lr", "blackbox_shap_perm"]
CalibrationDistribution = Literal["poisson", "gamma", "binomial"]
CalibrationCIAround = Literal["P_avg", "Y_avg"]


@dataclass(frozen=True)
class ValidationPreset:
    """A frozen bundle of methodology defaults for one (distribution, architecture).

    Attributes
    ----------
    name
        Slug used to look the preset up by name (``"poisson_glm"`` etc.).
        Also surfaces in HTML reports.
    distribution
        Target/error distribution implied by the preset. Drives the calibration
        formula and what target values are considered valid.
    architecture
        ``"glm"`` for coefficient-based linear models, ``"blackbox"`` for
        tree / neural / opaque models. Drives which M3 sub-tests run.
    task
        ``"regression"`` for Poisson/Gamma, ``"classification"`` for Binary.
        Kept so the existing ``cfg.task`` consumers keep working.
    model_mode
        Legacy free-text mode label (``"frequency"`` / ``"severity"`` / ``"binary"``).
        Preserved so existing tests that branch on ``cfg.model_mode`` keep
        working without changes during the migration.
    weight_role
        Semantic role of the weight column. ``"exposure"`` for policy-years
        (Poisson rate models), ``"claim_count"`` for severity aggregates,
        ``"none"`` when weights aren't standard (Binary PD).
    weight_required
        If True, ``validate_config`` must find a non-empty ``weight_column``
        in the data; if False, the column may be omitted.
    enabled_groups
        Subset of ``{"M0", "M1", "M2", "M3", "M4", "M5"}`` that the strategy
        will execute. ``frozenset`` so the preset stays hashable.
    m3_variant
        Which family of M3 tests applies:

        - ``"glm_vif_lr"`` — Likelihood-ratio (M3.1) + VIF (M3.2)
        - ``"blackbox_shap_perm"`` — Permutation importance (M3.1, placeholder)
          + SHAP drift train vs val (M3.2)
    calibration_distribution
        Which distribution drives the M4.1 / M4.2 confidence interval shape.
        Methodology rule (Часть 99 §M4.1): Poisson and Binomial CIs are built
        around the predicted mean; Gamma CIs are built around the observed
        mean because the sum of Gamma variables has no closed-form law.
    calibration_ci_around
        Either ``"P_avg"`` (Poisson, Binary) or ``"Y_avg"`` (Gamma). Redundant
        with ``calibration_distribution`` but kept explicit so individual
        tests can read it without re-deriving the mapping.
    """

    name: str
    distribution: Distribution
    architecture: Architecture
    task: Task
    model_mode: str
    weight_role: WeightRole
    weight_required: bool
    enabled_groups: FrozenSet[str]
    m3_variant: M3Variant
    calibration_distribution: CalibrationDistribution
    calibration_ci_around: CalibrationCIAround


# ---------------------------------------------------------------------------
# Five built-in presets — the actual methodology mapping
# ---------------------------------------------------------------------------

_ALL_GROUPS: FrozenSet[str] = frozenset({"M0", "M1", "M2", "M3", "M4", "M5"})


POISSON_GLM = ValidationPreset(
    name="poisson_glm",
    distribution="poisson",
    architecture="glm",
    task="regression",
    model_mode="frequency",
    weight_role="exposure",
    weight_required=True,
    enabled_groups=_ALL_GROUPS,
    m3_variant="glm_vif_lr",
    calibration_distribution="poisson",
    calibration_ci_around="P_avg",
)


GAMMA_GLM = ValidationPreset(
    name="gamma_glm",
    distribution="gamma",
    architecture="glm",
    task="regression",
    model_mode="severity",
    weight_role="claim_count",
    weight_required=False,
    enabled_groups=_ALL_GROUPS,
    m3_variant="glm_vif_lr",
    calibration_distribution="gamma",
    calibration_ci_around="Y_avg",
)


POISSON_BLACKBOX = ValidationPreset(
    name="poisson_blackbox",
    distribution="poisson",
    architecture="blackbox",
    task="regression",
    model_mode="frequency",
    weight_role="exposure",
    weight_required=True,
    enabled_groups=_ALL_GROUPS,
    m3_variant="blackbox_shap_perm",
    calibration_distribution="poisson",
    calibration_ci_around="P_avg",
)


GAMMA_BLACKBOX = ValidationPreset(
    name="gamma_blackbox",
    distribution="gamma",
    architecture="blackbox",
    task="regression",
    model_mode="severity",
    weight_role="claim_count",
    weight_required=False,
    enabled_groups=_ALL_GROUPS,
    m3_variant="blackbox_shap_perm",
    calibration_distribution="gamma",
    calibration_ci_around="Y_avg",
)


BINARY_BLACKBOX = ValidationPreset(
    name="binary_blackbox",
    distribution="binary",
    architecture="blackbox",
    task="classification",
    model_mode="binary",
    # Binary PD usually has no weight; the methodology permits analytical
    # weights with explicit justification, so we don't require one but accept
    # the column if the user supplies it.
    weight_role="none",
    weight_required=False,
    enabled_groups=_ALL_GROUPS,
    m3_variant="blackbox_shap_perm",
    calibration_distribution="binomial",
    calibration_ci_around="P_avg",
)


ALL_PRESETS: Dict[str, ValidationPreset] = {
    p.name: p for p in (
        POISSON_GLM,
        GAMMA_GLM,
        POISSON_BLACKBOX,
        GAMMA_BLACKBOX,
        BINARY_BLACKBOX,
    )
}


def get_preset(name_or_preset) -> ValidationPreset:
    """Resolve a preset by name or pass-through if already an instance.

    Accepts either a ``ValidationPreset`` (returned unchanged) or a string
    matching one of the built-in preset names. Raises :class:`KeyError`
    with the list of known names when the lookup fails.
    """
    if isinstance(name_or_preset, ValidationPreset):
        return name_or_preset
    if isinstance(name_or_preset, str):
        if name_or_preset in ALL_PRESETS:
            return ALL_PRESETS[name_or_preset]
        raise KeyError(
            f"Unknown preset {name_or_preset!r}; choose from {sorted(ALL_PRESETS)}"
        )
    raise TypeError(
        f"preset must be a ValidationPreset or a name string; got {type(name_or_preset).__name__}"
    )
