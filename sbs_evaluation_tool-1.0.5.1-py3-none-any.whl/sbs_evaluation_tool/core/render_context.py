"""Render-mode context for inline test display.

Tests stay matplotlib-only by default. ``show_test_inline(..., render="plotly")``
sets a ContextVar that selected tests read inside ``run()`` to swap a small
number of key charts (M2.1 ROC, M2.3 dynamics, M4.2/M4.3 calibration) for
interactive Plotly versions. HTML report generation and pytest are unaffected.
"""
from __future__ import annotations

from contextvars import ContextVar
from typing import Literal

RenderMode = Literal["matplotlib", "plotly"]

_VALID = {"matplotlib", "plotly"}

_render_mode: ContextVar[str] = ContextVar("sbs_render_mode", default="matplotlib")


def get_render_mode() -> str:
    return _render_mode.get()


def set_render_mode(mode: str):
    if mode not in _VALID:
        raise ValueError(f"render must be one of {sorted(_VALID)}, got {mode!r}")
    return _render_mode.set(mode)


def reset_render_mode(token) -> None:
    _render_mode.reset(token)
