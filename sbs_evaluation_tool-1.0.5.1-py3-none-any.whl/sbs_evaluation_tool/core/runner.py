"""Top-level SBS evaluation runner.

The runner stays small: validate config, pick a strategy, let the strategy
build the test groups, execute them, and write the HTML report. Concrete
test classes are no longer imported here — that responsibility lives in the
strategy (see :mod:`core.strategy`), so adding/removing tests or introducing
a new model type does not require editing this file.
"""
from datetime import datetime
from pathlib import Path

import pandas as pd

from .base_test import ModelReportBuilder
from .config_validation import validate_config
from .strategy import select_strategy
from ..tests.psi_calculator import PSICalculatorExtended


def run_sbs_evaluation(
    data: pd.DataFrame,
    config: dict,
    segment_name: str = "FMTLP",
    output_dir: str = "reports",
    size: str = "normal",
) -> str:
    """Run the full SBS evaluation cycle, write an HTML report, return its path.

    Args:
        data: DataFrame containing the columns referenced in ``config``.
        config: SBS configuration dict; see :func:`validate_config`.
        segment_name: Filename prefix for the report (e.g. ``"FMTLP"``).
        output_dir: Output directory (relative paths resolved against ``cwd``).
        size: Legacy knob. ``"heavy"`` drops the M3 group; kept for backwards
            compatibility — prefer expressing the same intent via the strategy
            directly if you call it.
    """
    print(f"🚀 Запуск SBS Evaluation для сегмента: {segment_name}")

    cfg = validate_config(config, data)
    print(
        f"Running SBS Evaluation for segment: {segment_name} | "
        f"mode={cfg.model_mode} | validation={cfg.validation_mode}"
    )

    psi_calc = PSICalculatorExtended()
    strategy = select_strategy(cfg, exclude_heavy=(size == "heavy"))
    if size == "heavy":
        print("  ⏭️  M3 (Multicollinearity) пропущена (size='heavy')")

    mr = ModelReportBuilder()
    for group, params in strategy.get_test_groups(data, cfg, psi_calc):
        print(f"  ... Running group {group.group_name}")
        group.run_all_tests(test_params=params)
        mr.add_group(group)

    html = mr.generate_html()

    cols = cfg.columns
    score_name = cols.score_column or "score"
    target_name = cols.target_column or "target"

    def _sanitize(name: str) -> str:
        return "".join(
            ch if (str(ch).isalnum() or ch in ("-", "_", ".")) else "_" for ch in str(name)
        )

    today = datetime.now().strftime("%d_%m_%Y")
    fname = (
        f"{_sanitize(segment_name)}_{_sanitize(cfg.model_mode)}_"
        f"{_sanitize(cfg.validation_mode)}_{_sanitize(score_name)}_"
        f"{_sanitize(target_name)}_{today}.html"
    )

    out_path_dir = Path(output_dir)
    if not out_path_dir.is_absolute():
        out_path_dir = Path.cwd() / output_dir
    out_path_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_path_dir / fname

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"✅ Готово! Отчет сохранен: {out_path}")
    return str(out_path)
