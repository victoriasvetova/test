from __future__ import annotations

import logging
from typing import Dict, List, Optional, Tuple, Union

import pandas as pd

from .config_validation import SBSConfig, ConfigValidationError, validate_config

logger = logging.getLogger(__name__)

SCORING_SUFFIX = "_SCORING"
VALUE_SUFFIX = "_VALUE"


TRAIN_ALIASES = {"train", "development", "dev"}
VALIDATION_ALIASES = {
    "oos": {"test", "oos", "out_of_sample", "out-of-sample", "validation", "valid", "val"},
    "oot": {"oot", "out_of_time", "out-of-time", "outoftime"},
}


def ensure_config(config: Union[Dict, SBSConfig], df: pd.DataFrame) -> SBSConfig:
    if isinstance(config, SBSConfig):
        return config
    return validate_config(config, df)


def get_col_name(cfg: SBSConfig, name: str) -> Optional[str]:
    return getattr(cfg.columns, name, None)


def get_model_mode(cfg: SBSConfig) -> str:
    return getattr(cfg, "model_mode", None) or ("binary" if str(cfg.task).lower() == "classification" else "severity")


def get_validation_mode(cfg: SBSConfig) -> str:
    return getattr(cfg, "validation_mode", None) or "oos"


def is_binary_mode(cfg: SBSConfig) -> bool:
    return get_model_mode(cfg) == "binary"


def is_generic_classification_mode(cfg: SBSConfig) -> bool:
    return get_model_mode(cfg) == "classification"


def is_regression_mode(cfg: SBSConfig) -> bool:
    return get_model_mode(cfg) in {"severity", "frequency"}


def is_big_data_mode(cfg: SBSConfig) -> bool:
    return bool(getattr(getattr(cfg, "performance", None), "big_data_mode", False))


def sample_frame_for_big_data(
    df: pd.DataFrame,
    cfg: SBSConfig,
    *,
    max_rows: int = 200_000,
    random_state: int = 42,
) -> pd.DataFrame:
    """Deterministically cap a frame only when ``performance.big_data_mode`` is enabled."""
    if not is_big_data_mode(cfg) or len(df) <= max_rows:
        return df
    sampled = df.sample(n=max_rows, random_state=random_state)
    return sampled.sort_index()


def uses_exposure(cfg: SBSConfig) -> bool:
    return get_model_mode(cfg) == "frequency"


def _normalize_sample_value(value: object) -> str:
    return str(value).strip().lower().replace(" ", "_")


def get_validation_aliases(cfg: SBSConfig) -> set[str]:
    return VALIDATION_ALIASES[get_validation_mode(cfg)]


def get_validation_label(cfg: SBSConfig) -> str:
    return get_validation_mode(cfg).upper()


def split_sample_masks(df: pd.DataFrame, cfg: SBSConfig) -> Tuple[pd.Series, pd.Series]:
    """Return boolean train/validation masks without copying dataframe rows."""
    sc = cfg.columns.sample_column
    if sc is None or sc not in df.columns:
        raise ConfigValidationError([f"Column '{sc}' (sample_column) is missing in DataFrame"])

    normalized = df[sc].map(_normalize_sample_value)
    train_mask = normalized.isin(TRAIN_ALIASES)
    validation_aliases = get_validation_aliases(cfg)
    validation_mask = normalized.isin(validation_aliases)

    if not train_mask.any():
        raise ConfigValidationError(
            [f"В `{sc}` не найдены строки TRAIN. Ожидаются метки из набора: {sorted(TRAIN_ALIASES)}"]
        )
    if not validation_mask.any():
        raise ConfigValidationError(
            [
                f"Для validation_mode='{get_validation_mode(cfg)}' в `{sc}` "
                f"не найдены строки validation-сэмпла. Ожидаются метки из набора: {sorted(validation_aliases)}"
            ]
        )
    return train_mask, validation_mask


def split_frames(df: pd.DataFrame, cfg: SBSConfig) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Splits DataFrame into train, validation, and genpop (full) based on sample_column and validation_mode.
    Returns (df_train, df_validation, df_genpop).
    """
    train_mask, validation_mask = split_sample_masks(df, cfg)

    df_train = df[train_mask].copy()
    df_validation = df[validation_mask].copy()
    return df_train, df_validation, df.copy()


def get_weight_col(df: pd.DataFrame, cfg: SBSConfig, config_dict: Optional[dict] = None) -> Optional[pd.Series]:
    weight_col = None
    if config_dict:
        cols = config_dict.get("columns") or config_dict
        weight_col = cols.get("weight_column") or cols.get("weight")

    if weight_col is None:
        weight_col = getattr(cfg.columns, "weight_column", None)

    if not weight_col or weight_col not in df.columns:
        return None

    w = pd.to_numeric(df[weight_col], errors="coerce").fillna(0.0)
    if (w > 0).sum() == 0:
        return None
    return w


def get_features(df: pd.DataFrame, cfg: SBSConfig, include_categorical: bool = True) -> List[str]:
    num = getattr(cfg.columns, "numeric_features", []) or []
    cat = getattr(cfg.columns, "categorical_features", []) or []

    feats = list(num)
    if include_categorical:
        feats.extend(list(cat))
    return list(dict.fromkeys(feats))


def _preset_architecture(cfg: SBSConfig) -> Optional[str]:
    preset = getattr(cfg, "preset", None)
    return getattr(preset, "architecture", None) if preset is not None else None


def is_glm_preset(cfg: SBSConfig) -> bool:
    """True iff cfg uses a preset declared as ``architecture='glm'``.

    Used to decide whether ``_SCORING`` / ``_VALUE`` columns are expected
    in the dataframe. Configs without a preset (legacy) return False so
    the resolver becomes a no-op and existing behaviour is preserved.
    """
    return _preset_architecture(cfg) == "glm"


def resolve_feature_columns(
    df: pd.DataFrame,
    features: List[str],
    *,
    kind: str,
    cfg: SBSConfig,
    test_code: Optional[str] = None,
) -> List[str]:
    """Map raw feature names to their ``_SCORING`` / ``_VALUE`` companions.

    For GLM presets some tests must operate on the GLM-derived columns
    rather than the raw feature: ranking tests (M2.2 / M2.4 / M5.2 /
    M5.4) want ``f + "_SCORING"`` (the multiplicative coefficient), the
    multicollinearity tests (M3.1 / M3.2) want ``f + "_VALUE"`` (the
    additive contribution on the linear-predictor scale).

    Behaviour:

    * non-GLM preset (or no preset at all) → returns ``features``
      unchanged. The resolver is a no-op for BlackBox and legacy configs.
    * GLM preset + suffix column present → substituted in place.
    * GLM preset + suffix column missing → falls back to the raw feature
      with a single aggregated ``logger.warning`` listing every missing
      column and pointing at ``apply_glm_scoring``. The test still runs.

    Parameters
    ----------
    df
        DataFrame the test will operate on. Used only to check column
        presence.
    features
        Raw feature names (typically ``cfg.columns.numeric_features``).
    kind
        ``"scoring"`` → suffix ``_SCORING``; ``"value"`` → suffix ``_VALUE``.
    cfg
        Validated SBSConfig (used to detect the GLM preset).
    test_code
        Optional tag for the warning message (e.g. ``"M 2.2"``).

    Returns
    -------
    list[str]
        Same length as ``features``. Each entry is either the suffixed
        column (when present under a GLM preset) or the raw feature
        (otherwise).
    """
    if kind == "scoring":
        suffix = SCORING_SUFFIX
    elif kind == "value":
        suffix = VALUE_SUFFIX
    else:
        raise ValueError(f"resolve_feature_columns: unknown kind={kind!r}")

    if not is_glm_preset(cfg):
        return list(features)

    resolved: List[str] = []
    missing: List[str] = []
    for f in features:
        suffixed = f + suffix
        if suffixed in df.columns:
            resolved.append(suffixed)
        else:
            resolved.append(f)
            missing.append(suffixed)

    if missing:
        tag = f"[{test_code}] " if test_code else ""
        logger.warning(
            "%sGLM preset detected but %d %s column(s) missing: %s. "
            "Falling back to raw features for now. "
            "Run `from sbs_evaluation_tool.core.glm_scoring import parse_glm_model, apply_glm_scoring; "
            "df = apply_glm_scoring(df, parse_glm_model(<your_model.xlsx>))` "
            "to populate them.",
            tag, len(missing), suffix, ", ".join(missing[:10]) + (" ..." if len(missing) > 10 else ""),
        )

    return resolved


def get_score_col(cfg: SBSConfig) -> Optional[str]:
    """Canonical score column for this config.

    For every model mode (binary / classification / frequency / severity)
    the single ``score_column`` is the model output we rank, calibrate,
    and assess stability on. ``prediction_column`` was a legacy alias and
    is no longer supported.
    """
    scol = getattr(cfg.columns, "score_column", None)
    if scol:
        return scol
    raise ConfigValidationError(["columns.score_column is required"])


def get_vectors(
    df: pd.DataFrame,
    cfg: SBSConfig,
    for_classification: bool = True,
) -> Tuple[pd.Series, Optional[pd.Series], Optional[pd.Series]]:
    """Return ``(y, pred, score)`` aligned to ``df``.

    ``pred`` is kept in the tuple for backward compatibility with callers
    that destructure three values, but it is always identical to ``score``
    now that ``prediction_column`` has been removed.
    """
    tcol = cfg.columns.target_column
    scol = cfg.columns.score_column

    if tcol not in df.columns:
        raise ConfigValidationError([f"target_column '{tcol}' not in df"])

    y = df[tcol]
    score = df[scol] if (scol and scol in df.columns) else None
    if score is None:
        raise ConfigValidationError([f"score_column '{scol}' not in df"])

    return y, score, score
