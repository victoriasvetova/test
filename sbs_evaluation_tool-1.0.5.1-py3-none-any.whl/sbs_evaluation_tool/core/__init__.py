"""Core API surface for the SBS Evaluation Tool.

This package contains the core implementation of the SBS Evaluation Tool.

Typical imports:

    from sbs_evaluation_tool.core.base_test import BaseModelTest, TestGroupBuilder, ModelReportBuilder
    from sbs_evaluation_tool.core.config_validation import SBSConfig, ColumnsConfig, validate_config
    from sbs_evaluation_tool.core.inline_display import show_test_inline
    from sbs_evaluation_tool.core.runner import run_sbs_evaluation
"""

from .base_test import BaseModelTest, TestGroupBuilder, ModelReportBuilder
from .config_validation import (
    SBSConfig,
    ColumnsConfig,
    ModelMode,
    ValidationMode,
    PerformanceConfig,
    ThresholdsConfig,
    VifThresholds,
    GiniDropThresholds,
    PsiThresholds,
    validate_config,
    ConfigValidationError,
)
from .inline_display import show_test_inline
from .strategy import BaseModelStrategy, GLMStrategy, BlackBoxStrategy, select_strategy
from .presets import (
    ValidationPreset,
    POISSON_GLM,
    GAMMA_GLM,
    POISSON_BLACKBOX,
    GAMMA_BLACKBOX,
    BINARY_BLACKBOX,
    ALL_PRESETS,
    get_preset,
)
# Note: runner is NOT imported here to avoid circular dependency
# Import it directly: from sbs_evaluation_tool.core.runner import run_sbs_evaluation
from . import styles

__all__ = [
    "BaseModelTest",
    "TestGroupBuilder",
    "ModelReportBuilder",
    "SBSConfig",
    "ColumnsConfig",
    "ModelMode",
    "ValidationMode",
    "PerformanceConfig",
    "ThresholdsConfig",
    "VifThresholds",
    "GiniDropThresholds",
    "PsiThresholds",
    "validate_config",
    "ConfigValidationError",
    "show_test_inline",
    "BaseModelStrategy",
    "GLMStrategy",
    "BlackBoxStrategy",
    "select_strategy",
    "ValidationPreset",
    "POISSON_GLM",
    "GAMMA_GLM",
    "POISSON_BLACKBOX",
    "GAMMA_BLACKBOX",
    "BINARY_BLACKBOX",
    "ALL_PRESETS",
    "get_preset",
    # "run_sbs_evaluation",  # available via direct import from .runner
    "styles",
]
