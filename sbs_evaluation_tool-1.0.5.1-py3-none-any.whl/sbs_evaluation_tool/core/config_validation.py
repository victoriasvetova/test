from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional

import pandas as pd

from .presets import ValidationPreset, get_preset

logger = logging.getLogger(__name__)

TaskType = Literal["classification", "regression"]
ModelMode = Literal["severity", "frequency", "binary", "classification"]
ValidationMode = Literal["oos", "oot"]


class ConfigValidationError(ValueError):
    def __init__(self, errors: List[str]):
        super().__init__("\n".join(errors))
        self.errors = errors


@dataclass
class ColumnsConfig:
    numeric_features: List[str] = field(default_factory=list)
    categorical_features: List[str] = field(default_factory=list)
    score_column: Optional[str] = None
    date_column: Optional[str] = None
    target_column: Optional[str] = None
    sample_column: Optional[str] = None
    id_column: Optional[str] = None
    weight_column: Optional[str] = None

    # `prediction_column` was a legacy field meant to hold the predicted
    # count (rate × exposure) alongside the score (rate). It caused real
    # bugs (M5.1 ranked observations by count instead of rate) without
    # earning its keep — `prediction = score × weight` is trivially
    # recovered when needed. We keep the attribute on the dataclass as
    # ``None`` so older code paths that touch it via ``getattr`` keep
    # working, but ``validate_config`` will emit a deprecation warning
    # when callers still pass it.
    prediction_column: Optional[str] = None


@dataclass
class VifThresholds:
    """VIF traffic-light cutoffs for M3.2 multicollinearity.

    A factor is red when ``vif > red`` and orange when ``vif > orange``.
    Defaults match the GLM methodology (Часть 99 §M3).
    """
    red: float = 5.0
    orange: float = 3.0


@dataclass
class GiniDropThresholds:
    """Gini-drop cutoffs for M5.1 ranking stability.

    A test signals red when ``absolute_drop >= red_absolute_pp`` AND
    ``relative_drop >= red_relative``; orange uses the same conjunction with
    the looser numbers; otherwise green. Defaults match the GLM methodology.
    """
    red_absolute_pp: float = 0.10
    red_relative: float = 0.20
    orange_absolute_pp: float = 0.05
    orange_relative: float = 0.15


@dataclass
class PsiThresholds:
    """PSI traffic-light cutoffs used by M5.3 (score) and M5.4 (factors).

    ``psi >= red`` is red, ``psi >= orange`` is orange, else green. Defaults
    follow the conventional 0.10 / 0.20 cutoffs.
    """
    red: float = 0.20
    orange: float = 0.10


@dataclass
class ThresholdsConfig:
    """All traffic-light cutoffs in one place.

    Defaults reproduce the historically hardcoded values, so existing pipelines
    behave identically when ``thresholds`` is omitted from the input config.
    Override any individual section to tighten or loosen a particular signal
    without touching test classes.
    """
    vif: VifThresholds = field(default_factory=VifThresholds)
    gini_drop: GiniDropThresholds = field(default_factory=GiniDropThresholds)
    psi: PsiThresholds = field(default_factory=PsiThresholds)


@dataclass
class PerformanceConfig:
    """Runtime knobs for very large in-memory datasets.

    The default is deliberately conservative: existing configs behave exactly
    as before unless users opt in with ``{"performance": {"big_data_mode": True}}``.
    """
    big_data_mode: bool = False


@dataclass
class SBSConfig:
    task: TaskType
    model_mode: ModelMode
    validation_mode: ValidationMode
    columns: ColumnsConfig
    thresholds: ThresholdsConfig = field(default_factory=ThresholdsConfig)
    performance: PerformanceConfig = field(default_factory=PerformanceConfig)
    preset: Optional[ValidationPreset] = None
    # Optional auxiliary inputs consumed by specific tests. ``shap_importance``
    # is a dict of the shape ``{"train": {feature: float}, "validation": {feature: float}}``
    # used by M3.2 BlackBox; when missing, that test self-skips with INFO.
    shap_importance: Optional[Dict[str, Dict[str, float]]] = None


def _ensure_list(value: Any, field_name: str) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value.strip()]
    if isinstance(value, (list, tuple)):
        out: List[str] = []
        for v in value:
            if not isinstance(v, str):
                raise ConfigValidationError(
                    [f"`{field_name}` должен быть списком строк; найден элемент типа {type(v)}"]
                )
            out.append(v.strip())
        return out
    raise ConfigValidationError([f"`{field_name}` должен быть списком строк или строкой"])


def _non_empty_str(value: Any, field_name: str, required: bool = True) -> Optional[str]:
    if value is None or (isinstance(value, str) and value.strip() == ""):
        if required:
            raise ConfigValidationError([f"Отсутствует или пустое поле `{field_name}`"])
        return None
    if not isinstance(value, str):
        raise ConfigValidationError([f"`{field_name}` должен быть строкой"])
    return value.strip()


def _derive_model_mode(task: Optional[str], weight_column: Optional[str]) -> ModelMode:
    if task == "classification":
        return "binary"
    if task == "regression":
        return "frequency" if weight_column else "severity"
    raise ConfigValidationError(
        ["Не удалось определить `model_mode`: задайте `model_mode` или корректный `task`"]
    )


def _derive_task(model_mode: str) -> TaskType:
    if model_mode in ("severity", "frequency"):
        return "regression"
    if model_mode in ("binary", "classification"):
        return "classification"
    raise ConfigValidationError([f"Неизвестный `model_mode`: {model_mode}"])


def validate_config(raw_config: Dict[str, Any], df: pd.DataFrame) -> SBSConfig:
    """
    Полная валидация и нормализация конфига относительно переданного df.

    Поддерживает два контракта:
      1. Preset-based (рекомендуемый):
           {"preset": POISSON_GLM, "columns": {...}, ...}
         Все методологические defaults (task, model_mode, ожидание веса)
         подкладываются из preset; их можно переопределить явно при
         необходимости.
      2. Старый контракт (без preset):
           {"task": "regression", "model_mode": "frequency", ...}
         Поведение прежнее — оставлено для совместимости.

    Если задано и preset, и task/model_mode — preset выигрывает на тех
    полях, которые в raw_config не заданы; явные значения уважаются.
    """
    errors: List[str] = []

    # ----- Step 1: resolve preset (if any) and use it to fill defaults ----
    preset: Optional[ValidationPreset] = None
    raw_preset = raw_config.get("preset")
    if raw_preset is not None:
        try:
            preset = get_preset(raw_preset)
        except (KeyError, TypeError) as e:
            errors.append(f"`preset`: {e}")

    # task / model_mode: explicit raw_config wins, otherwise preset, otherwise None
    task = raw_config.get("task")
    if task is None and preset is not None:
        task = preset.task
    model_mode = raw_config.get("model_mode") or raw_config.get("mode")
    if model_mode is None and preset is not None:
        model_mode = preset.model_mode

    validation_mode = (
        raw_config.get("validation_mode")
        or raw_config.get("validation_sample_mode")
        or raw_config.get("sample_mode")
        or "oos"
    )

    if task is not None and task not in ("classification", "regression"):
        errors.append("`task` должен быть 'classification' или 'regression'")
    if model_mode is not None and model_mode not in ("severity", "frequency", "binary", "classification"):
        errors.append(
            "`model_mode` должен быть одним из: 'severity', 'frequency', 'binary', 'classification'"
        )
    if validation_mode not in ("oos", "oot"):
        errors.append("`validation_mode` должен быть 'oos' или 'oot'")
    if task is None and model_mode is None:
        errors.append(
            "Нужно задать `preset` (например POISSON_GLM) либо одно из полей: `task` или `model_mode`"
        )

    columns = raw_config.get("columns")
    if not isinstance(columns, dict):
        errors.append("`columns` обязателен и должен быть объектом (mapping)")

    performance = PerformanceConfig()
    try:
        performance = _parse_performance(raw_config.get("performance"))
    except ConfigValidationError as e:
        errors.extend(e.errors)

    if errors:
        raise ConfigValidationError(errors)

    numeric_features: List[str] = []
    categorical_features: List[str] = []
    score_column: Optional[str] = None
    date_column: Optional[str] = None
    target_column: Optional[str] = None
    sample_column: Optional[str] = None
    id_column: Optional[str] = None
    weight_column: Optional[str] = None

    try:
        numeric_features = _ensure_list(columns.get("numeric_features"), "columns.numeric_features")
        categorical_features = _ensure_list(columns.get("categorical_features"), "columns.categorical_features")
    except ConfigValidationError as e:
        errors.extend(e.errors)

    # ``prediction_column`` is deprecated: warn loudly if the caller still
    # provides it, then ignore. For frequency models the predicted COUNT
    # is recoverable as ``score × weight``; for binary/severity it's
    # identical to ``score_column``.
    if columns.get("prediction_column"):
        logger.warning(
            "columns.prediction_column='%s' is deprecated and ignored. "
            "Use columns.score_column for the model output you rank and calibrate by; "
            "for Poisson-frequency models the predicted count is "
            "score × weight_column and computed on demand.",
            columns.get("prediction_column"),
        )

    try:
        score_column = _non_empty_str(columns.get("score_column"), "columns.score_column", required=False)
        date_column = _non_empty_str(columns.get("date_column"), "columns.date_column", required=True)
        target_column = _non_empty_str(columns.get("target_column"), "columns.target_column", required=True)
        sample_column = _non_empty_str(columns.get("sample_column"), "columns.sample_column", required=True)
        id_column = _non_empty_str(columns.get("id_column"), "columns.id_column", required=True)
        weight_column = _non_empty_str(
            columns.get("weight_column") or columns.get("weight"),
            "columns.weight_column",
            required=False,
        )
    except ConfigValidationError as e:
        errors.extend(e.errors)

    if model_mode is None:
        try:
            model_mode = _derive_model_mode(task, weight_column)
        except ConfigValidationError as e:
            errors.extend(e.errors)

    resolved_task: Optional[TaskType] = None
    if model_mode is not None:
        try:
            resolved_task = _derive_task(model_mode)
        except ConfigValidationError as e:
            errors.extend(e.errors)

    if task is not None and resolved_task is not None and task != resolved_task:
        errors.append(
            f"`task={task}` конфликтует с `model_mode={model_mode}`. "
            f"Для этого режима ожидается `task={resolved_task}`"
        )

    task = resolved_task or task

    if task == "classification":
        if not score_column:
            errors.append("Для классификационных режимов требуется `columns.score_column`")
    elif task == "regression":
        if not score_column:
            errors.append("Для регрессионных режимов требуется `columns.score_column`")
        if model_mode == "frequency" and not weight_column:
            errors.append("Для `model_mode=frequency` требуется `columns.weight_column` (экспозиция)")

    required_columns = {
        c
        for c in [
            date_column,
            target_column,
            sample_column,
            id_column,
            score_column,
            weight_column,
        ]
        if c is not None
    }
    missing_in_df = [c for c in required_columns if c not in df.columns]
    if missing_in_df:
        errors.append(f"В DataFrame отсутствуют необходимые колонки: {missing_in_df}")

    all_features = list(dict.fromkeys([*numeric_features, *categorical_features]))
    missing_features = [c for c in all_features if c not in df.columns]
    if missing_features:
        errors.append(f"Некоторые фичи отсутствуют в данных: {missing_features}")

    overlap = sorted(set(numeric_features).intersection(categorical_features))
    if overlap:
        errors.append(f"Фичи не должны дублироваться между numeric и categorical: {overlap}")

    if not numeric_features and not categorical_features:
        errors.append("Не заданы `numeric_features` и `categorical_features` — список фичей пуст")

    reserved = {
        c
        for c in [
            score_column,
            date_column,
            target_column,
            sample_column,
            id_column,
            weight_column,
        ]
        if c
    }
    bad_reserved_overlap = sorted(reserved.intersection(all_features))
    if bad_reserved_overlap:
        errors.append(f"Служебные колонки не должны входить в список фичей: {bad_reserved_overlap}")

    if date_column in df.columns:
        try:
            pd.to_datetime(_validation_series(df[date_column], performance), errors="raise")
        except Exception:
            errors.append(f"`{date_column}` не приводится к datetime; проверь формат дат")

    if model_mode == "binary" and target_column in df.columns:
        target_check = _validation_series(df[target_column], performance)
        unique_vals = pd.Series(target_check.dropna().unique())
        if unique_vals.nunique() > 10:
            errors.append(
                f"`{target_column}` выглядит не бинарным для `model_mode=binary` "
                "(найдено >10 уникальных значений). Проверьте кодировку таргета."
            )
    elif model_mode == "frequency" and target_column in df.columns:
        target_numeric = pd.to_numeric(_validation_series(df[target_column], performance), errors="coerce")
        if target_numeric.isna().all():
            errors.append(f"`{target_column}` должен быть числовым для `model_mode=frequency`")
        elif (target_numeric.dropna() < 0).any():
            errors.append(f"`{target_column}` должен быть неотрицательным для `model_mode=frequency`")
    elif model_mode == "severity" and target_column in df.columns:
        target_numeric = pd.to_numeric(_validation_series(df[target_column], performance), errors="coerce")
        if target_numeric.isna().all():
            errors.append(f"`{target_column}` должен быть числовым для `model_mode=severity`")

    if score_column and score_column in df.columns and not pd.api.types.is_numeric_dtype(df[score_column]):
        errors.append(f"`score_column` ('{score_column}') должен быть числовым")

    # Preset-driven check: required weight column must exist and be non-empty.
    if preset is not None and preset.weight_required and not weight_column:
        errors.append(
            f"`weight_column` обязателен для preset `{preset.name}` "
            f"(weight_role={preset.weight_role!r}); добавьте его в `columns`."
        )

    if errors:
        raise ConfigValidationError(errors)

    norm_cols = ColumnsConfig(
        numeric_features=numeric_features,
        categorical_features=categorical_features,
        score_column=score_column,
        date_column=date_column,
        target_column=target_column,
        sample_column=sample_column,
        id_column=id_column,
        weight_column=weight_column,
    )
    thresholds = _parse_thresholds(raw_config.get("thresholds"))
    raw_shap = raw_config.get("shap_importance")
    shap_importance = None
    if raw_shap is not None:
        if not isinstance(raw_shap, dict):
            raise ConfigValidationError(["`shap_importance` должен быть словарём"])
        # Accept both nested {"train": {...}, "validation": {...}} and the
        # alternative "test" key as a synonym for "validation".
        if "validation" not in raw_shap and "test" in raw_shap:
            raw_shap = {"train": raw_shap.get("train"), "validation": raw_shap["test"]}
        shap_importance = raw_shap
    return SBSConfig(
        task=task,
        model_mode=model_mode,
        validation_mode=validation_mode,
        columns=norm_cols,
        thresholds=thresholds,
        performance=performance,
        preset=preset,
        shap_importance=shap_importance,
    )


def _parse_performance(raw: Any) -> PerformanceConfig:
    """Build ``PerformanceConfig`` from optional user-supplied overrides."""
    if raw is None:
        return PerformanceConfig()
    if not isinstance(raw, dict):
        raise ConfigValidationError(["`performance` должен быть словарём или null"])
    big_data_mode = raw.get("big_data_mode", False)
    if not isinstance(big_data_mode, bool):
        raise ConfigValidationError(["`performance.big_data_mode` должен быть boolean"])
    return PerformanceConfig(big_data_mode=big_data_mode)


def _validation_series(series: pd.Series, performance: PerformanceConfig) -> pd.Series:
    """Return the full series normally, or a bounded sample in big-data mode."""
    if not performance.big_data_mode:
        return series
    return series.head(100_000)


def _parse_thresholds(raw: Any) -> ThresholdsConfig:
    """Build a ``ThresholdsConfig`` from optional user-supplied overrides.

    ``raw`` is either ``None`` (use defaults), or a dict that may contain any
    subset of the section names ``vif`` / ``gini_drop`` / ``psi``. Each section
    may in turn override any subset of its fields; unspecified fields keep
    their default. Unknown keys are silently ignored to keep the contract
    forgiving — explicit validation can be added later if needed.
    """
    if raw is None:
        return ThresholdsConfig()
    if not isinstance(raw, dict):
        raise ConfigValidationError(["`thresholds` должен быть словарём или null"])
    vif = VifThresholds(**_pick(raw.get("vif"), ("red", "orange")))
    gini_drop = GiniDropThresholds(**_pick(
        raw.get("gini_drop"),
        ("red_absolute_pp", "red_relative", "orange_absolute_pp", "orange_relative"),
    ))
    psi = PsiThresholds(**_pick(raw.get("psi"), ("red", "orange")))
    return ThresholdsConfig(vif=vif, gini_drop=gini_drop, psi=psi)


def _pick(section: Any, allowed: tuple) -> Dict[str, float]:
    if section is None:
        return {}
    if not isinstance(section, dict):
        raise ConfigValidationError(["вложенная секция `thresholds.*` должна быть словарём"])
    out: Dict[str, float] = {}
    for key in allowed:
        if key in section and section[key] is not None:
            try:
                out[key] = float(section[key])
            except (TypeError, ValueError):
                raise ConfigValidationError(
                    [f"`thresholds.{key}` должен быть числом, получен {section[key]!r}"]
                )
    return out
