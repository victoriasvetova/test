"""Gini coefficient primitives.

Three flavors are provided because GLM and BlackBox paths historically use
different formulas, and replacing one with the other would change validation
results:

``gini``
    Binary/classification Gini, defined as ``2 * AUC - 1``. Used by BlackBox
    PD tests (M2.1, M5.1) and any binary classification model. Supports
    ``sample_weight`` and returns ``NaN`` for degenerate inputs (single class,
    empty mask).

``gini_normalized``
    Lorenz-curve Gini normalized by the perfect-ranking Lorenz area. Used by
    GLM frequency/severity tests, where the target is continuous and standard
    AUC is not defined. For binary 0/1 targets this is equivalent in
    magnitude to ``abs(gini)`` but is semantically a different statistic.
    Returns ``0.0`` for degenerate inputs.

``gini_numba``
    JIT-compiled Lorenz Gini for hot loops (per-factor Gini, parallel feature
    scans). Same formula as ``gini_normalized`` *without* the perfect-ranking
    normalization and without ``sample_weight`` support. Use this only inside
    tight loops where the dispatch overhead of the pure-Python variant matters.

Edge cases:
- mismatched shapes -> ``ValueError``
- single-class targets -> ``NaN`` (``gini``) or ``0.0`` (``gini_normalized``)
- empty arrays -> ``NaN`` (``gini``) or ``0.0`` (``gini_normalized``)
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import numba as nb
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import label_binarize


def gini(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    sample_weight: Optional[np.ndarray] = None,
) -> float:
    """Binary/classification Gini coefficient, ``2 * AUC - 1``.

    Parameters
    ----------
    y_true : array-like
        Binary targets (0/1) or numeric labels accepted by
        :func:`sklearn.metrics.roc_auc_score`.
    y_pred : array-like
        Predicted scores. Higher should mean higher probability of the
        positive class.
    sample_weight : array-like, optional
        Per-observation weights forwarded to ``roc_auc_score``.

    Returns
    -------
    float
        Gini in ``[-1, 1]``. Returns ``NaN`` when the target has fewer than
        two unique values, when the input is empty, or when all weights are
        non-positive.
    """
    yt = np.asarray(y_true, dtype=float)
    yp = np.asarray(y_pred, dtype=float)
    if yt.shape != yp.shape:
        raise ValueError("y_true and y_pred must have the same shape")

    mask = np.isfinite(yt) & np.isfinite(yp)
    w: Optional[np.ndarray] = None
    if sample_weight is not None:
        wt = np.asarray(sample_weight, dtype=float)
        if wt.shape != yt.shape:
            raise ValueError("sample_weight must match y_true shape")
        mask &= np.isfinite(wt)
        w = wt

    yt = yt[mask]
    yp = yp[mask]
    if w is not None:
        w = w[mask]
        if w.sum() <= 0:
            w = None

    if yt.size == 0 or np.unique(yt).size < 2:
        return float("nan")

    auc = roc_auc_score(yt, yp, sample_weight=w)
    return float(2.0 * auc - 1.0)


def gini_normalized(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    sample_weight: Optional[np.ndarray] = None,
) -> float:
    """Lorenz-area Gini normalized by the perfect-ranking area.

    Used by GLM frequency/severity validation where the target is continuous.
    Computes the Lorenz area for the model-ordered sequence and divides by
    the Lorenz area of the actual-ordered sequence, yielding a value in
    roughly ``[0, 1]``.

    Returns ``0.0`` for degenerate inputs (constant target, zero total).
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    if y_true.shape != y_pred.shape:
        raise ValueError("y_true and y_pred shapes must match")

    w: Optional[np.ndarray] = None
    if sample_weight is not None:
        w = np.asarray(sample_weight, dtype=float)
        if w.shape != y_true.shape:
            w = w[: y_true.shape[0]]
        if np.sum(w) <= 0:
            w = None

    gini_den = _lorenz_gini(y_true, y_true, w)
    if gini_den == 0:
        return 0.0
    return _lorenz_gini(y_true, y_pred, w) / gini_den


def _lorenz_gini(
    actual: np.ndarray,
    pred: np.ndarray,
    weight: Optional[np.ndarray] = None,
) -> float:
    """Compute ``2 * area - 1`` of the Lorenz curve sorted by ``pred`` ascending.

    Weighting convention (per GLM-validation methodology, замечание after M 2.1):
      X-axis = cumulative share of *observations* (weighted: Σw / Σw_total).
      Y-axis = cumulative share of *actual values*       (Σy / Σy_total) —
              NOT ``y * w``: in an actuarial frequency model y already counts
              events; multiplying by exposure double-counts.

    This makes :func:`gini_normalized` numerically equal to
    :func:`tests.m2._shared.powerstat_value` for matching inputs.
    """
    order = np.argsort(pred)
    a_sorted = actual[order]
    if weight is not None:
        w_sorted = weight[order]
        total_w = w_sorted.sum()
        total_y = a_sorted.sum()
        if total_w <= 0 or total_y <= 0:
            return 0.0
        cum_w = np.cumsum(w_sorted) / total_w
        cum_y = np.cumsum(a_sorted) / total_y
        area = np.trapz(cum_y, cum_w)
        return 2.0 * area - 1.0

    n = len(a_sorted)
    total = a_sorted.sum()
    if n == 0 or total == 0:
        return 0.0
    cum_actual = np.cumsum(a_sorted)
    gini_sum = cum_actual.sum() / total - (n + 1) / 2.0
    return gini_sum / n


def gini_multiclass(
    y_true: np.ndarray,
    y_proba: np.ndarray,
) -> float:
    """Class-prior-weighted one-vs-rest Gini for multiclass classifiers.

    Each class contributes ``2 * AUC_c - 1`` weighted by its prior
    (``count_c / n``). Classes for which AUC is undefined (single-class in
    the one-vs-rest split, all-NaN scores) are skipped — their prior is
    excluded from the weight total to keep the result on the same scale.

    Parameters
    ----------
    y_true : array-like of shape (n_samples,)
        Class labels (any hashable type accepted by
        :func:`sklearn.preprocessing.label_binarize`).
    y_proba : array-like of shape (n_samples, n_classes)
        Per-class probabilities. Column order must match the natural order
        of ``np.unique(y_true)``.

    Returns
    -------
    float
        Prior-weighted average Gini. ``NaN`` when no class contributes
        (e.g. ``y_true`` empty or every class degenerate).
    """
    yt = np.asarray(y_true)
    yp = np.asarray(y_proba, dtype=float)
    if yp.ndim != 2:
        raise ValueError("y_proba must be 2-D (n_samples, n_classes)")
    if yt.shape[0] != yp.shape[0]:
        raise ValueError("y_true and y_proba must share the first dimension")
    if yt.size == 0:
        return float("nan")

    classes = np.unique(yt)
    if classes.size < 2:
        return float("nan")
    if classes.size != yp.shape[1]:
        raise ValueError(
            f"y_proba has {yp.shape[1]} columns but y_true has {classes.size} unique classes"
        )

    if classes.size == 2:
        # sklearn returns shape (n, 1) for binary; we need a per-class column matrix
        binarized = np.column_stack([
            (yt == classes[0]).astype(int),
            (yt == classes[1]).astype(int),
        ])
    else:
        binarized = label_binarize(yt, classes=classes)
    n = float(yt.shape[0])
    priors = binarized.sum(axis=0) / n  # P(class = c)

    weighted_sum = 0.0
    weight_total = 0.0
    for i in range(classes.size):
        col = yp[:, i]
        mask = np.isfinite(col)
        if mask.sum() == 0:
            continue
        yb_i = binarized[mask, i]
        if np.unique(yb_i).size < 2:
            continue
        try:
            auc = roc_auc_score(yb_i, col[mask])
        except Exception:
            continue
        weighted_sum += priors[i] * (2.0 * auc - 1.0)
        weight_total += priors[i]

    if weight_total == 0.0:
        return float("nan")
    return float(weighted_sum / weight_total)


@nb.njit(parallel=False, fastmath=True)
def gini_numba(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """JIT-compiled Lorenz Gini for tight per-factor loops.

    No ``sample_weight`` support and no degenerate-input guards beyond the
    zero-total fallback — callers must pass clean numpy arrays. Use
    :func:`gini` or :func:`gini_normalized` for the general case.
    """
    order = np.argsort(-y_pred)
    y_sorted = y_true[order]
    total = y_sorted.sum()
    n = y_sorted.size
    if total == 0:
        return 0.0
    cum_y = np.cumsum(y_sorted)
    cum_pop = np.arange(1, n + 1)
    return 2.0 * np.trapz(cum_y / total, cum_pop / n) - 1.0
