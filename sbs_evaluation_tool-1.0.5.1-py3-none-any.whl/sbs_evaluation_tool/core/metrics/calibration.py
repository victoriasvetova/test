"""Calibration-curve primitives.

A calibration curve compares predicted scores against observed target rates,
bucketed either by score band or by time. Used by:

- GLM M4.2 / M4.3 (calibration by score bins and by date)
- BlackBox M4.2 (calibration curve shape)

These functions return *data dictionaries*, not figures — the test class is
responsible for producing the chart spec that the render layer consumes.

Weight contract
---------------
``sample_weight=None`` / ``sample_weight_column=None`` mean uniform weights
of 1.0. When weights are supplied, per-bin and per-period statistics are
weighted means: ``sum(w * x) / sum(w)``.

Note: ``sklearn.calibration.calibration_curve`` does not support
``sample_weight``, so when weights are needed we run our own quantile-binned
implementation (same algorithm; equivalent to sklearn when weights are
uniform).
"""

from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import pandas as pd
from sklearn.calibration import calibration_curve as _sk_calibration_curve


def calibration_curve_by_bins(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    n_bins: int = 20,
    strategy: str = "quantile",
    *,
    sample_weight: Optional[np.ndarray] = None,
) -> Dict[str, np.ndarray]:
    """Predicted vs observed target rate per score bin.

    Parameters
    ----------
    y_true : array-like
        Binary targets (0/1) for classification or numeric targets for regression.
    y_pred : array-like
        Model predictions.
    n_bins : int
        Number of bins.
    strategy : {"quantile", "uniform"}
        Binning strategy for ``y_pred``.
    sample_weight : array-like, optional
        Per-observation weights. ``None`` is equivalent to uniform 1.0.

    Returns
    -------
    dict with keys ``bin_edges``, ``predicted_mean``, ``observed_mean``, ``count``.
    """
    yt = np.asarray(y_true, dtype=float)
    yp = np.asarray(y_pred, dtype=float)
    if yt.shape != yp.shape:
        raise ValueError("y_true and y_pred must have the same shape")

    mask = np.isfinite(yt) & np.isfinite(yp)
    w: Optional[np.ndarray] = None
    if sample_weight is not None:
        w = np.asarray(sample_weight, dtype=float)
        if w.shape != yt.shape:
            raise ValueError("sample_weight must match y_true shape")
        mask &= np.isfinite(w)
        w = w[mask]
    yt = yt[mask]
    yp = yp[mask]

    if yt.size == 0:
        return _empty_result()

    is_binary = np.unique(yt).size <= 2 and set(np.unique(yt).tolist()).issubset({0.0, 1.0})

    # sklearn fast path: binary + no weights
    if is_binary and w is None:
        observed, predicted = _sk_calibration_curve(yt, yp, n_bins=n_bins, strategy=strategy)
        if strategy == "quantile":
            edges = np.unique(np.quantile(yp, np.linspace(0.0, 1.0, n_bins + 1)))
        else:
            edges = np.linspace(yp.min(), yp.max(), n_bins + 1)
        counts, _ = np.histogram(yp, bins=edges)
        return {
            "bin_edges": edges,
            "predicted_mean": np.asarray(predicted, dtype=float),
            "observed_mean": np.asarray(observed, dtype=float),
            "count": counts.astype(int),
        }

    # Manual binned means — used for regression OR for weighted binary
    if strategy == "quantile":
        edges = np.unique(np.quantile(yp, np.linspace(0.0, 1.0, n_bins + 1)))
    else:
        edges = np.linspace(yp.min(), yp.max(), n_bins + 1)
    if edges.size < 2:
        return _empty_result(edges=edges)

    bin_idx = np.clip(np.digitize(yp, edges[1:-1]), 0, edges.size - 2)
    n_b = edges.size - 1
    pred_means = np.full(n_b, np.nan, dtype=float)
    obs_means = np.full(n_b, np.nan, dtype=float)
    counts = np.zeros(n_b, dtype=int)
    for b in range(n_b):
        sel = bin_idx == b
        n = int(sel.sum())
        counts[b] = n
        if n == 0:
            continue
        if w is not None:
            ws = w[sel]
            tw = ws.sum()
            if tw > 0:
                pred_means[b] = float(np.sum(yp[sel] * ws) / tw)
                obs_means[b] = float(np.sum(yt[sel] * ws) / tw)
                continue
        pred_means[b] = float(yp[sel].mean())
        obs_means[b] = float(yt[sel].mean())
    return {
        "bin_edges": edges,
        "predicted_mean": pred_means,
        "observed_mean": obs_means,
        "count": counts,
    }


def calibration_curve_by_dates(
    df: pd.DataFrame,
    pred_column: str,
    target_column: str,
    date_column: str,
    freq: str = "M",
    sample_weight_column: Optional[str] = None,
) -> Dict[str, np.ndarray]:
    """Predicted vs observed target rate per time bucket.

    ``freq`` follows pandas offset aliases (``"M"`` month-end, ``"Q"`` quarter).

    ``sample_weight_column=None`` means uniform weights of 1.0.

    Returns
    -------
    dict with keys ``periods``, ``predicted_mean``, ``observed_mean``, ``count``.
    """
    cols = [pred_column, target_column, date_column]
    if sample_weight_column is not None:
        cols.append(sample_weight_column)
    work = df[cols].copy()
    work[date_column] = pd.to_datetime(work[date_column], errors="coerce")
    work = work.dropna(subset=[date_column, pred_column, target_column])
    if work.empty:
        return {
            "periods": np.empty(0, dtype=object),
            "predicted_mean": np.empty(0),
            "observed_mean": np.empty(0),
            "count": np.empty(0, dtype=int),
        }

    bucket = work[date_column].dt.to_period(freq)
    if sample_weight_column is not None:
        w = work[sample_weight_column].astype(float).clip(lower=0.0)
        grouped = work.assign(_b=bucket, _w=w).groupby("_b", observed=True)
        pred_mean = grouped.apply(
            lambda g: np.average(g[pred_column], weights=g["_w"]) if g["_w"].sum() > 0
            else g[pred_column].mean()
        )
        obs_mean = grouped.apply(
            lambda g: np.average(g[target_column], weights=g["_w"]) if g["_w"].sum() > 0
            else g[target_column].mean()
        )
        counts = grouped.size()
    else:
        grouped = work.assign(_b=bucket).groupby("_b", observed=True)
        pred_mean = grouped[pred_column].mean()
        obs_mean = grouped[target_column].mean()
        counts = grouped.size()

    return {
        "periods": np.asarray(pred_mean.index.tolist(), dtype=object),
        "predicted_mean": pred_mean.to_numpy(dtype=float),
        "observed_mean": obs_mean.to_numpy(dtype=float),
        "count": counts.to_numpy(dtype=int),
    }


def _empty_result(edges: Optional[np.ndarray] = None) -> Dict[str, np.ndarray]:
    return {
        "bin_edges": edges if edges is not None else np.empty(0),
        "predicted_mean": np.empty(0),
        "observed_mean": np.empty(0),
        "count": np.empty(0, dtype=int),
    }
