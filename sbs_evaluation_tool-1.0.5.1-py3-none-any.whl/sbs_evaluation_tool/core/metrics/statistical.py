"""Simple statistical aggregates shared across tests.

Trivial helpers that get reimplemented inline in various test files today.
Collecting them here keeps the math identical across GLM and BlackBox paths.
"""

from __future__ import annotations

from typing import Optional

import numpy as np


def target_rate(
    y_true: np.ndarray,
    sample_weight: Optional[np.ndarray] = None,
) -> float:
    """Weighted or unweighted mean of the target.

    For binary targets this is the event/default rate. For continuous targets
    this is the mean response. NaN values are dropped, non-positive total
    weights fall back to the unweighted mean.

    Returns ``NaN`` for empty input.
    """
    yt = np.asarray(y_true, dtype=float)
    mask = np.isfinite(yt)
    if sample_weight is not None:
        w = np.asarray(sample_weight, dtype=float)
        if w.shape != yt.shape:
            raise ValueError("sample_weight must match y_true shape")
        mask &= np.isfinite(w)
        yt = yt[mask]
        w = w[mask]
        if yt.size == 0:
            return float("nan")
        total = w.sum()
        if total > 0:
            return float(np.sum(yt * w) / total)
        return float(yt.mean())
    yt = yt[mask]
    if yt.size == 0:
        return float("nan")
    return float(yt.mean())


def event_rate(
    y_pred: np.ndarray,
    threshold: float = 0.5,
    *,
    sample_weight: Optional[np.ndarray] = None,
) -> float:
    """Fraction of predictions strictly above ``threshold``.

    Used for sanity checks that the predicted positive rate matches the
    observed target rate at a chosen cutoff. NaN values are dropped.

    ``sample_weight=None`` is equivalent to uniform weights of 1.0; otherwise
    the returned value is ``sum(w * (yp > threshold)) / sum(w)``.

    Returns ``NaN`` for empty input or when all weights are zero/non-positive.
    """
    yp = np.asarray(y_pred, dtype=float)
    mask = np.isfinite(yp)
    if sample_weight is not None:
        w = np.asarray(sample_weight, dtype=float)
        if w.shape != yp.shape:
            raise ValueError("sample_weight must match y_pred shape")
        mask &= np.isfinite(w)
        yp = yp[mask]
        w = w[mask]
        if yp.size == 0:
            return float("nan")
        total = w.sum()
        if total > 0:
            return float(np.sum(w * (yp > threshold)) / total)
        return float((yp > threshold).mean())
    yp = yp[mask]
    if yp.size == 0:
        return float("nan")
    return float((yp > threshold).mean())
