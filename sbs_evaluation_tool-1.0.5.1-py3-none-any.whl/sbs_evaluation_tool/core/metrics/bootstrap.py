"""Bootstrap confidence-interval primitives.

A generic bootstrap helper plus thin wrappers specialized for common metrics.
Resampling is case-bootstrap: ``(y, p)`` (and ``w`` when given) are drawn
together with the same indices.

Weight contract
---------------
``sample_weight=None`` means uniform weights of 1.0. The ``None`` value is
forwarded as-is through to the inner metric so its own fast path applies;
identity ``f(y, p) == f(y, p, sample_weight=ones)`` is maintained by the
inner metric, not by allocating an ``ones`` array here.

When ``sample_weight`` is given, it is resampled with the same indices as
``y`` and ``p`` and passed to ``metric_func`` via a ``sample_weight=`` kwarg.
This means callers that pass weights MUST use a ``metric_func`` whose
signature accepts ``sample_weight``.

Exceptions raised by the metric on a single resample are caught and recorded
as NaN; NaNs are skipped during percentile summarization.

No progress bars: this is library code. If a caller needs progress, it can
wrap the loop externally.
"""

from __future__ import annotations

from typing import Callable, Optional, Tuple

import numpy as np

from .gini import gini


def bootstrap_values(
    metric_func: Callable[..., float],
    y_true: np.ndarray,
    y_pred: np.ndarray,
    *,
    sample_weight: Optional[np.ndarray] = None,
    n_iter: int = 500,
    seed: Optional[int] = None,
) -> np.ndarray:
    """Resample with replacement and apply ``metric_func`` per draw.

    Parameters
    ----------
    metric_func : callable
        Function ``(y_true_sample, y_pred_sample) -> float`` or, when
        ``sample_weight`` is provided, ``(y, p, sample_weight=...) -> float``.
    y_true, y_pred : array-like
        Targets and predictions, equal length.
    sample_weight : array-like, optional
        Per-observation weights. When provided, weights are resampled along
        with ``y`` and ``p`` and forwarded to ``metric_func`` as a kwarg.
        ``None`` (default) is equivalent to uniform weights of 1.0.
    n_iter : int
        Number of bootstrap resamples.
    seed : int, optional
        Seed for the random generator. ``None`` means non-deterministic.

    Returns
    -------
    np.ndarray of shape ``(n_iter,)``
        Metric values. Failures (exceptions inside ``metric_func``) are recorded
        as ``NaN``.
    """
    yt = np.asarray(y_true)
    yp = np.asarray(y_pred)
    if yt.shape != yp.shape:
        raise ValueError("y_true and y_pred must have the same shape")
    w_arr: Optional[np.ndarray] = None
    if sample_weight is not None:
        w_arr = np.asarray(sample_weight)
        if w_arr.shape != yt.shape:
            raise ValueError("sample_weight must match y_true shape")
    n = yt.shape[0]
    if n == 0:
        return np.empty(0, dtype=float)

    rng = np.random.default_rng(seed)
    out = np.empty(int(n_iter), dtype=float)
    for i in range(int(n_iter)):
        idx = rng.integers(0, n, n)
        try:
            if w_arr is not None:
                out[i] = float(metric_func(yt[idx], yp[idx], sample_weight=w_arr[idx]))
            else:
                out[i] = float(metric_func(yt[idx], yp[idx]))
        except Exception:
            out[i] = float("nan")
    return out


def bootstrap_ci(
    metric_func: Callable[..., float],
    y_true: np.ndarray,
    y_pred: np.ndarray,
    *,
    sample_weight: Optional[np.ndarray] = None,
    n_iter: int = 500,
    ci: float = 0.95,
    seed: Optional[int] = None,
) -> Tuple[float, float]:
    """Percentile bootstrap confidence interval for a metric.

    Equivalent to :func:`bootstrap_values` followed by ``nanpercentile`` at
    the appropriate two-sided percentiles.

    Parameters
    ----------
    ci : float
        Confidence level in ``(0, 1)``. ``0.95`` returns the 2.5%/97.5% bounds,
        ``0.90`` returns 5%/95%.

    Returns
    -------
    (lower, upper) : tuple of float
        ``(NaN, NaN)`` if every resample produced NaN.
    """
    if not 0.0 < ci < 1.0:
        raise ValueError("ci must lie in (0, 1)")
    vals = bootstrap_values(
        metric_func, y_true, y_pred,
        sample_weight=sample_weight, n_iter=n_iter, seed=seed,
    )
    if vals.size == 0:
        return float("nan"), float("nan")
    finite = vals[np.isfinite(vals)]
    if finite.size == 0:
        return float("nan"), float("nan")
    alpha = (1.0 - ci) / 2.0
    lower = float(np.percentile(finite, alpha * 100.0))
    upper = float(np.percentile(finite, (1.0 - alpha) * 100.0))
    return lower, upper


def bootstrap_gini_ci(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    *,
    sample_weight: Optional[np.ndarray] = None,
    n_iter: int = 500,
    ci: float = 0.95,
    seed: Optional[int] = None,
) -> Tuple[float, float]:
    """Bootstrap CI for :func:`gini`, optionally weighted.

    Convenience wrapper used by GLM M2.2 and BlackBox M2.2.
    """
    return bootstrap_ci(
        gini, y_true, y_pred,
        sample_weight=sample_weight, n_iter=n_iter, ci=ci, seed=seed,
    )
