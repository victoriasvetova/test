"""Shared metric primitives for SBS Evaluation Tool.

This package is the single source of truth for validation metrics used by both
GLM and BlackBox test paths. Functions here are pure: they take arrays/dataframes
and return numbers or plain dicts of numbers. They do NOT know about model types,
traffic-light thresholds, plotting, or HTML rendering — those belong to the test
classes that call them.

Public API:

    from sbs_evaluation_tool.core.metrics import (
        gini, gini_numba,
        bootstrap_ci, bootstrap_gini_ci,
        psi, psi_by_factor,
        calibration_curve_by_bins,
        target_rate, event_rate,
    )
"""

from .gini import gini, gini_normalized, gini_numba, gini_multiclass
from .bootstrap import bootstrap_values, bootstrap_ci, bootstrap_gini_ci
from .psi import psi, psi_by_factor, psi_by_date
from .calibration import calibration_curve_by_bins, calibration_curve_by_dates
from .statistical import target_rate, event_rate

__all__ = [
    "gini",
    "gini_normalized",
    "gini_numba",
    "gini_multiclass",
    "bootstrap_values",
    "bootstrap_ci",
    "bootstrap_gini_ci",
    "psi",
    "psi_by_factor",
    "psi_by_date",
    "calibration_curve_by_bins",
    "calibration_curve_by_dates",
    "target_rate",
    "event_rate",
]
