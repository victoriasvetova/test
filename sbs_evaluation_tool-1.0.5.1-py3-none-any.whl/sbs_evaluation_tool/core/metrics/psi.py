"""Population Stability Index (PSI) primitives.

Pure scalar PSI calculation. The richer ``PSICalculator`` class in
``tests/psi_calculator.py`` still owns per-bin DataFrame output, plotting,
and traffic-light logic — those are presentation/orchestration concerns
that belong outside ``core/metrics/``. This module provides the *number*.

Formula:

    PSI = sum_i (actual_i - expected_i) * ln(actual_i / expected_i)

with epsilon smoothing applied to empty bins to avoid log(0) and divide-by-zero:

- if ``expected_i == 0``: that bin contributes 0 (log term forced to ln(1) = 0)
- if ``actual_i == 0``: ``actual_i`` is clipped to a small positive constant
  before the log

Weight contract
---------------
``expected_weight=None`` / ``actual_weight=None`` mean uniform weights of 1.0.
When weights are supplied, per-bin proportions are computed as weighted sums
divided by the total weight on that side (i.e. proportions are by exposure,
not by observation count). For GLM frequency/severity this is the correct
notion of distribution stability; for BlackBox PD use ``None``.

Conventional thresholds (informational, not enforced here):

    PSI < 0.10     no significant shift
    0.10 <= PSI < 0.25  moderate shift
    PSI >= 0.25    significant shift
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd


_EPS = 1e-6


def psi(
    expected: np.ndarray,
    actual: np.ndarray,
    n_bins: int = 10,
    bin_edges: Optional[np.ndarray] = None,
    strategy: str = "quantile",
    *,
    expected_weight: Optional[np.ndarray] = None,
    actual_weight: Optional[np.ndarray] = None,
) -> float:
    """Population Stability Index between two 1-D samples.

    Parameters
    ----------
    expected : array-like
        Baseline distribution (typically the development sample).
    actual : array-like
        Comparison distribution (typically validation / monitoring sample).
    n_bins : int
        Number of bins computed from ``expected``. Ignored when ``bin_edges``
        is supplied.
    bin_edges : array-like, optional
        Explicit bin edges to reuse across multiple comparisons.
    strategy : {"quantile", "uniform"}
        Binning strategy when ``bin_edges`` is not provided.
    expected_weight, actual_weight : array-like, optional
        Per-observation weights for the corresponding sample. ``None`` is
        equivalent to uniform weights of 1.0.

    Returns
    -------
    float
        Scalar PSI. ``NaN`` when both samples are empty after dropping
        non-finite values.
    """
    e_arr, e_w = _clean_with_weight(expected, expected_weight)
    a_arr, a_w = _clean_with_weight(actual, actual_weight)
    if e_arr.size == 0 and a_arr.size == 0:
        return float("nan")
    if e_arr.size == 0 or a_arr.size == 0:
        return 0.0

    if bin_edges is None:
        edges = _compute_edges(e_arr, a_arr, n_bins=n_bins, strategy=strategy)
    else:
        edges = np.asarray(bin_edges, dtype=float)
    if edges.size < 2:
        return 0.0

    expected_pct = _weighted_proportions(e_arr, e_w, edges)
    actual_pct = _weighted_proportions(a_arr, a_w, edges)
    return _psi_from_proportions(expected_pct, actual_pct)


def psi_by_factor(
    dev_df: pd.DataFrame,
    val_df: pd.DataFrame,
    factor_column: str,
    n_bins: int = 10,
    categorical: Optional[bool] = None,
    *,
    weight_column: Optional[str] = None,
) -> float:
    """PSI for a single factor between development and validation frames.

    Numeric factors are binned via :func:`psi`; categorical factors use a
    value-by-value comparison without binning.

    Parameters
    ----------
    weight_column : str, optional
        Column name in both frames containing per-observation weights. ``None``
        means uniform weights of 1.0 on both sides.
    """
    if factor_column not in dev_df.columns or factor_column not in val_df.columns:
        raise KeyError(f"factor_column '{factor_column}' missing from one of the frames")

    e = dev_df[factor_column]
    a = val_df[factor_column]
    e_w = dev_df[weight_column].to_numpy() if weight_column is not None else None
    a_w = val_df[weight_column].to_numpy() if weight_column is not None else None

    if categorical is None:
        categorical = (e.dtype == object) or (not pd.api.types.is_numeric_dtype(e))

    if categorical:
        e_dist = _categorical_proportions(e, e_w)
        a_dist = _categorical_proportions(a, a_w).reindex(e_dist.index, fill_value=0.0)
        return _psi_from_proportions(e_dist.values, a_dist.values)

    return psi(
        e.to_numpy(), a.to_numpy(),
        n_bins=n_bins,
        expected_weight=e_w, actual_weight=a_w,
    )


def psi_by_date(
    df: pd.DataFrame,
    value_column: str,
    date_column: str,
    baseline_period: Optional[tuple] = None,
    freq: str = "M",
    n_bins: int = 10,
    *,
    weight_column: Optional[str] = None,
) -> Dict[Any, float]:
    """PSI of ``value_column`` per time bucket against a baseline window.

    Baseline edges are computed once from the baseline window (or from the
    earliest bucket if ``baseline_period`` is None) and reused for every
    bucket.

    Parameters
    ----------
    weight_column : str, optional
        Column name containing per-observation weights. ``None`` means uniform
        weights of 1.0.
    """
    cols = [value_column, date_column]
    if weight_column is not None:
        cols.append(weight_column)
    work = df[cols].copy()
    work[date_column] = pd.to_datetime(work[date_column], errors="coerce")
    work = work.dropna(subset=[date_column])

    def _w(sub: pd.DataFrame) -> Optional[np.ndarray]:
        if weight_column is None:
            return None
        return sub[weight_column].to_numpy()

    if baseline_period is not None:
        start, end = baseline_period
        baseline_mask = (work[date_column] >= pd.Timestamp(start)) & (
            work[date_column] <= pd.Timestamp(end)
        )
        baseline = work.loc[baseline_mask]
    else:
        bucket_key = work[date_column].dt.to_period(freq)
        if bucket_key.empty:
            return {}
        first_period = bucket_key.min()
        baseline = work.loc[bucket_key == first_period]

    if baseline.empty:
        return {}

    baseline_values = baseline[value_column].to_numpy()
    baseline_w = _w(baseline)
    edges = _compute_edges(baseline_values, baseline_values, n_bins=n_bins, strategy="quantile")

    out: Dict[Any, float] = {}
    for period, sub in work.groupby(work[date_column].dt.to_period(freq), observed=True):
        out[period] = psi(
            baseline_values, sub[value_column].to_numpy(),
            bin_edges=edges,
            expected_weight=baseline_w, actual_weight=_w(sub),
        )
    return out


def _clean_with_weight(
    values: np.ndarray,
    weights: Optional[np.ndarray],
) -> tuple[np.ndarray, Optional[np.ndarray]]:
    v = pd.to_numeric(pd.Series(values), errors="coerce").to_numpy(dtype=float)
    mask = np.isfinite(v)
    if weights is None:
        return v[mask], None
    w = np.asarray(weights, dtype=float)
    if w.shape != v.shape:
        raise ValueError("weights must match values shape")
    mask &= np.isfinite(w)
    return v[mask], w[mask]


def _weighted_proportions(
    values: np.ndarray,
    weights: Optional[np.ndarray],
    edges: np.ndarray,
) -> np.ndarray:
    if weights is None:
        counts, _ = np.histogram(values, bins=edges)
        total = counts.sum()
        if total == 0:
            return np.zeros(edges.size - 1, dtype=float)
        return counts.astype(float) / float(total)
    # Weighted histogram via np.histogram with `weights=` kwarg
    binned_weights, _ = np.histogram(values, bins=edges, weights=weights)
    total = binned_weights.sum()
    if total == 0:
        return np.zeros(edges.size - 1, dtype=float)
    return binned_weights.astype(float) / float(total)


def _categorical_proportions(
    series: pd.Series,
    weights: Optional[np.ndarray],
) -> pd.Series:
    if weights is None:
        return series.value_counts(normalize=True)
    df = pd.DataFrame({"val": series.values, "w": weights}).dropna(subset=["val"])
    grouped = df.groupby("val")["w"].sum()
    total = grouped.sum()
    if total > 0:
        grouped = grouped / total
    return grouped


def _psi_from_proportions(expected_pct: np.ndarray, actual_pct: np.ndarray) -> float:
    log_ratio = np.where(
        expected_pct == 0,
        0.0,
        np.log(
            np.where(actual_pct == 0, _EPS, actual_pct)
            / np.where(expected_pct == 0, 1.0, expected_pct)
        ),
    )
    return float(np.sum((actual_pct - expected_pct) * log_ratio))


def _compute_edges(
    expected: np.ndarray,
    actual: np.ndarray,
    n_bins: int,
    strategy: str,
) -> np.ndarray:
    if strategy == "quantile":
        edges = np.unique(np.percentile(expected, np.linspace(0.0, 100.0, n_bins + 1)))
        if edges.size >= 2:
            return edges
        strategy = "uniform"
    if strategy == "uniform":
        lo = float(min(expected.min(), actual.min()))
        hi = float(max(expected.max(), actual.max()))
        if lo == hi:
            lo -= _EPS
            hi += _EPS
        return np.linspace(lo, hi, n_bins + 1)
    raise ValueError(f"Unsupported binning strategy: {strategy!r}")
