"""BlackBox-specific M3 tests (Часть 100 §M3).

The GLM M3 group uses likelihood-ratio (M3.1) and VIF (M3.2). Tree-based and
neural BlackBox models don't expose regression coefficients, so the BlackBox
methodology replaces them with:

- **M3.1 — Permutation feature significance** (informational only)
- **M3.2 — SHAP drift train vs validation** (signal-carrying)

This module implements both. Per the agreed Phase 5 scope (Q7):

- M3.1 is a *placeholder* — permutation importance requires a model object,
  a runtime budget, and a sampling contract that we are not yet ready to fix.
  The placeholder returns a clear SKIP signal so the report stays consistent.
- M3.2 expects **pre-computed SHAP importance scalars** for every feature,
  one value per (feature, sample). The user computes SHAP outside the
  library (typically via the ``shap`` package on their trained model) and
  passes the two dicts through the config. We do not run SHAP ourselves
  (Q8) — the shap library is heavy and would force a hard dependency.
"""

from __future__ import annotations

import logging
from typing import Dict, Optional

import pandas as pd

from ..core.base_test import BaseModelTest


logger = logging.getLogger(__name__)


# Methodology cutoffs (Часть 100 §M3.2): share of features whose SHAP
# importance dropped by more than 50% from train to validation.
SHAP_DROP_THRESHOLD = 0.5      # |Δshap| / shap_train > 0.5 = "feature fell"
SHAP_RED_SHARE = 0.8           # > 80% fallen features -> red
SHAP_ORANGE_SHARE = 0.5        # 50-80% fallen features -> orange


class BBM31_PermutationPlaceholderTest(BaseModelTest):
    """M3.1 BlackBox — Permutation feature significance (informational).

    Placeholder: the methodology marks this test as informational anyway and
    we don't yet support model-object inputs to compute permutation drops
    safely (memory, time, framework neutrality). The test always returns the
    blue/INFO signal with a brief explanation so the report communicates the
    skip honestly instead of looking like a missing test.
    """

    def __init__(self):
        super().__init__("M 3.1", "Permutation feature significance (BlackBox, INFO)")

    def run(self, df: Optional[pd.DataFrame] = None, config: Optional[dict] = None,
            **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: skipped (placeholder)")
        self.test_signal = "blue"
        html = (
            "<h4>M3.1 — Permutation feature significance (BlackBox)</h4>"
            "<p><b>Status:</b> <span style='color:#1f77b4;font-weight:bold'>INFO / SKIPPED</span></p>"
            "<p>Permutation importance is informational per methodology (Часть 100, §M3.1) "
            "and requires a model object, framework-specific preprocessing, and an explicit "
            "runtime budget that this library does not yet capture. Skipped until that "
            "contract is added.</p>"
        )
        return {"DASHBOARD": html}


class BBM32_ShapDriftTest(BaseModelTest):
    """M3.2 BlackBox — SHAP importance drift between train and validation.

    Input contract: SHAP importance scalars must be supplied via the config:

        config = {
            ...,
            "shap_importance": {
                "train":      {"feature_a": 0.234, "feature_b": 0.156, ...},
                "validation": {"feature_a": 0.198, "feature_b": 0.087, ...},
            },
            ...,
        }

    Each scalar is the mean ``|shap_value|`` across rows for that feature on
    that sample (or any equivalent monotone summary). Missing features in
    either dict are skipped from the signal calculation.

    Signal rules (Часть 100, §M3.2):

    - A feature is *fallen* if ``|shap_val - shap_train| / shap_train > 0.5``.
    - Share = (fallen features) / (features that appear in both dicts).
    - share > 0.8  -> red
    - share > 0.5  -> orange
    - otherwise    -> green
    """

    def __init__(self):
        super().__init__("M 3.2", "SHAP importance drift (BlackBox)")

    def run(self, df: Optional[pd.DataFrame] = None, config=None,
            **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")

        # config may be the raw dict (legacy) or an already-validated SBSConfig
        # (preset-driven path). Pull the SHAP dict from whichever shape we see.
        shap_dict = None
        if config is not None:
            if hasattr(config, "shap_importance"):
                shap_dict = config.shap_importance
            elif isinstance(config, dict):
                shap_dict = config.get("shap_importance")
        if not isinstance(shap_dict, dict) or not shap_dict.get("train") or not shap_dict.get("validation"):
            self.test_signal = "blue"
            html = (
                "<h4>M3.2 — SHAP importance drift</h4>"
                "<p><b>Status:</b> <span style='color:#1f77b4;font-weight:bold'>INFO / SKIPPED</span></p>"
                "<p>No pre-computed SHAP importance supplied. Pass "
                "<code>config['shap_importance'] = {'train': {...}, 'validation': {...}}</code> "
                "to enable this test.</p>"
            )
            return {"DASHBOARD": html}

        train_shap: Dict[str, float] = dict(shap_dict["train"])
        val_shap: Dict[str, float] = dict(shap_dict["validation"])
        common = sorted(set(train_shap) & set(val_shap))
        if not common:
            self.test_signal = "red"
            html = (
                "<h4>M3.2 — SHAP importance drift</h4>"
                "<p><b>Status:</b> <span style='color:red;font-weight:bold'>RED</span></p>"
                "<p>Train and validation SHAP dicts share no feature names — cannot compare.</p>"
            )
            return {"DASHBOARD": html}

        rows = []
        fallen = 0
        for feat in common:
            tr = float(train_shap[feat])
            va = float(val_shap[feat])
            if tr <= 0:
                # cannot compute relative drop; mark as info row, do not count as fallen
                rows.append((feat, tr, va, None, False))
                continue
            rel_drop = abs(va - tr) / tr
            is_fallen = rel_drop > SHAP_DROP_THRESHOLD
            if is_fallen:
                fallen += 1
            rows.append((feat, tr, va, rel_drop, is_fallen))

        counted = sum(1 for _, _, _, drop, _ in rows if drop is not None)
        share = (fallen / counted) if counted else 0.0

        if share > SHAP_RED_SHARE:
            signal = "red"
        elif share > SHAP_ORANGE_SHARE:
            signal = "orange"
        else:
            signal = "green"
        self.test_signal = signal

        table_rows = "".join(
            f"<tr><td>{feat}</td><td>{tr:.4f}</td><td>{va:.4f}</td>"
            f"<td>{('—' if drop is None else f'{drop*100:.1f}%')}</td>"
            f"<td>{'YES' if is_fallen else 'no'}</td></tr>"
            for feat, tr, va, drop, is_fallen in rows
        )
        html = (
            "<h4>M3.2 — SHAP importance drift</h4>"
            f"<p><b>Signal:</b> <span style='color:{signal};font-weight:bold'>{signal.upper()}</span></p>"
            f"<p>Fallen features: <b>{fallen}/{counted}</b> "
            f"(share {share*100:.1f}%; cutoffs: orange > {SHAP_ORANGE_SHARE*100:.0f}%, "
            f"red > {SHAP_RED_SHARE*100:.0f}%; per-feature threshold "
            f"|Δshap|/shap_train > {SHAP_DROP_THRESHOLD*100:.0f}%).</p>"
            "<table border='1' cellspacing='0' cellpadding='6'>"
            "<tr><th>Feature</th><th>SHAP train</th><th>SHAP validation</th>"
            "<th>|Δ| / train</th><th>Fallen?</th></tr>"
            f"{table_rows}"
            "</table>"
        )
        return {"DASHBOARD": html}
