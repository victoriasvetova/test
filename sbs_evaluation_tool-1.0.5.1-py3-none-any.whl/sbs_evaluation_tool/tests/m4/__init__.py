"""Per-sub-test modules for SBS M4 calibration.

Carved out of the original monolithic ``tests/m4_model_performance.py``
(2082 lines). Public class names are re-exported here; consumers keep their
original import path via the back-compat shim in ``tests/m4_model_performance.py``.

Module layout:
    _shared.py             helpers used by every sub-test
    target_rate.py         M41_TargetRateTest                  (M 4.1)
    calibration_bins.py    M42_CalibrationCurveByPredictBinsLn (M 4.2)
    calibration_dates.py   M43_CalibrationCurveByDatesLn       (M 4.3)
    _legacy.py             non-public classes kept for import stability
"""

from .target_rate import M41_TargetRateTest
from .calibration_bins import M42_CalibrationCurveByPredictBinsLn
from .calibration_dates import M43_CalibrationCurveByDatesLn

__all__ = [
    "M41_TargetRateTest",
    "M42_CalibrationCurveByPredictBinsLn",
    "M43_CalibrationCurveByDatesLn",
]
