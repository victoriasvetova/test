# -*- coding: utf-8 -*-
"""Shared imports and module-level helpers for the m4 test classes."""

from __future__ import annotations
import base64
from io import BytesIO
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import logging

from scipy.stats import binom
from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score, r2_score, mean_squared_error
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
from sklearn.utils.multiclass import type_of_target

from ...core.base_test import BaseModelTest
from ...core.metrics import gini_normalized, bootstrap_values
from ...core.styles import COLORS, STATUS_COLORS
from ...core.config_validation import validate_config as _validate_config, ConfigValidationError
from ...core.data_utils import (
    ensure_config,
    split_frames,
    get_weight_col,
    get_col_name,
    get_vectors,
    get_features,
    get_model_mode,
    is_binary_mode,
    is_generic_classification_mode,
)
from .._visual_utils import (
    MEAN_RATE_LABEL,
    OBSERVATION_COUNT_LABEL,
    SHARE_LABEL,
    build_tabbed_sections_html,
    build_period_specs,
    build_scale_specs,
    figure_to_base64,
)

import matplotlib.dates as mdates
from math import log

def _classification_mode_na(test_name: str) -> Dict[str, str]:
    return {
        "combined": (
            f"<h4>{test_name}</h4>"
            "<p><b>Skipped:</b> generic `classification` mode is not yet mapped "
            "to a methodology-specific calibration test. Use `binary` for binomial/logistic tasks.</p>"
        )
    }

# SHAP availability at module import time (used by some tests)
SHAP_AVAILABLE = False
shap = None

# Module logger
logger = logging.getLogger(__name__)

# Replaced with core.data_utils imports



def _subset_by_sample(df: pd.DataFrame, config: dict, sample: str) -> pd.DataFrame:
    # Use split_frames logic
    cfg = ensure_config(config, df)
    df_tr, df_te, df_all = split_frames(df, cfg)
    return {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(sample, df_te)



def _safe_threshold_labels(s: pd.Series) -> pd.Series:
    if pd.api.types.is_integer_dtype(s) or (pd.Series(s).dropna().nunique() <= 2):
        return s.astype(int)
    if pd.api.types.is_float_dtype(s):
        return (s >= 0.5).astype(int)
    return pd.to_numeric(s, errors='coerce').fillna(0).astype(int)



def _to_base64(fig) -> str:
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode('utf-8')


def calibration_traffic_light(n_bins: int, n_out_95: int, n_out_99: int) -> tuple[str, dict]:
    """Traffic-light signal for M 4.2 / M 4.3 per methodology Таблица 6.20.

    Idea: under the null hypothesis that the model is well-calibrated, the
    fraction of bins whose predicted mean falls outside the 95 % CI follows a
    Binomial(n_bins, 0.05) distribution; outside the 99 % CI — Binomial(n_bins,
    0.01). We compare the observed counts against the upper-tail critical
    values at significance levels 5 % (orange boundary) and 1 % (red boundary).

    Returns ``(signal, info)`` where ``info`` is a dict of computed thresholds
    suitable for rendering in the report.
    """
    if n_bins <= 0:
        return 'gray', {}

    def _critical(p: float, alpha: float) -> int:
        # Smallest k such that P(X >= k) <= alpha where X ~ Binom(n_bins, p).
        # scipy.stats.binom.isf(alpha) returns smallest m with sf(m) = P(X > m) <= alpha,
        # which means P(X >= m+1) <= alpha → critical value k = m + 1.
        return int(binom.isf(alpha, n_bins, p)) + 1

    k95_y = _critical(0.05, 0.05)
    k99_y = _critical(0.05, 0.01)
    k95_r = _critical(0.01, 0.05)
    k99_r = _critical(0.01, 0.01)

    if n_out_95 >= k99_y or n_out_99 >= k99_r:
        signal = 'red'
    elif n_out_95 >= k95_y or n_out_99 >= k95_r:
        signal = 'orange'
    else:
        signal = 'green'

    return signal, {
        'k95_orange': k95_y, 'k99_orange': k99_y,
        'k95_red': k95_r,    'k99_red':    k99_r,
    }
