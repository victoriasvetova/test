# -*- coding: utf-8 -*-
"""Legacy M4 test classes preserved for import stability.

None of these are on the public runner path (see core/runner.py — only M41,
M42, M43 are wired in). Kept here so any historical direct import keeps
resolving while we plan their fate.
"""

from __future__ import annotations
import base64
from io import BytesIO
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import logging

from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score, r2_score, mean_squared_error
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
from sklearn.utils.multiclass import type_of_target

from ...core.base_test import BaseModelTest
from ...core.metrics import gini_normalized, bootstrap_values
from ...core.styles import COLORS, STATUS_COLORS
from ...core.config_validation import validate_config as _validate_config, ConfigValidationError
from ...core.data_utils import (
    ensure_config,
    split_frames,
    get_weight_col,
    get_col_name,
    get_vectors,
    get_features,
    get_model_mode,
    is_binary_mode,
    is_generic_classification_mode,
)
from .._visual_utils import (
    MEAN_RATE_LABEL,
    OBSERVATION_COUNT_LABEL,
    SHARE_LABEL,
    build_tabbed_sections_html,
    build_period_specs,
    build_scale_specs,
    figure_to_base64,
)

import matplotlib.dates as mdates
from math import log

from ._shared import (
    _classification_mode_na,
    _subset_by_sample,
    _safe_threshold_labels,
    _to_base64,
)

logger = logging.getLogger(__name__)
SHAP_AVAILABLE = False
shap = None


class _LegacyMetricConfidenceIntervalTest(BaseModelTest):
    def __init__(self, model_type: str = 'classification', n_iterations: int = 300):
        super().__init__('M 4.1', 'Metric Confidence Interval')
        if model_type not in ('classification', 'regression'):
            raise ValueError("model_type must be 'classification' or 'regression'")
        self.model_type = model_type
        self.n_iterations = int(n_iterations)

    def run(self, df: pd.DataFrame, config: dict, sample: str = 'test', **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        df_tr, df_te, df_all = split_frames(df, cfg)
        df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(sample, df_te)
        task = getattr(cfg, 'task', None) or self.model_type

        html_parts = [f"<h4>M4.1 Metric CI ({task})</h4>"]
        results = {}

        try:
            if str(task).lower() == 'classification':
                y, pred, score = get_vectors(df_used, cfg, for_classification=True)
                labels = _safe_threshold_labels(pred if pred is not None else score)
                f1_vals = bootstrap_values(lambda a, b: f1_score(a, b, zero_division=0), y, labels, n_iter=self.n_iterations)
                results['f1'] = {'original': float(f1_score(y, labels, zero_division=0)), 'ci_5': float(np.nanpercentile(f1_vals, 5)), 'ci_95': float(np.nanpercentile(f1_vals, 95))}
                prec_vals = bootstrap_values(lambda a, b: precision_score(a, b, zero_division=0), y, labels, n_iter=self.n_iterations)
                rec_vals = bootstrap_values(lambda a, b: recall_score(a, b, zero_division=0), y, labels, n_iter=self.n_iterations)
                results['precision'] = {'original': float(precision_score(y, labels, zero_division=0)), 'ci_5': float(np.nanpercentile(prec_vals, 5)), 'ci_95': float(np.nanpercentile(prec_vals, 95))}
                results['recall'] = {'original': float(recall_score(y, labels, zero_division=0)), 'ci_5': float(np.nanpercentile(rec_vals, 5)), 'ci_95': float(np.nanpercentile(rec_vals, 95))}
                if score is not None:
                    try:
                        auc_val = float(roc_auc_score(y, score))
                        results['roc_auc'] = {'original': auc_val}
                    except Exception:
                        pass
            else:
                y, pred, score = get_vectors(df_used, cfg, for_classification=False)
                r2_vals = bootstrap_values(lambda a, b: r2_score(a, b), y, score, n_iter=self.n_iterations)
                mse_vals = bootstrap_values(lambda a, b: mean_squared_error(a, b), y, score, n_iter=self.n_iterations)
                results['r2'] = {'original': float(r2_score(y, score)), 'ci_5': float(np.nanpercentile(r2_vals, 5)), 'ci_95': float(np.nanpercentile(r2_vals, 95))}
                results['mse'] = {'original': float(mean_squared_error(y, score)), 'ci_5': float(np.nanpercentile(mse_vals, 5)), 'ci_95': float(np.nanpercentile(mse_vals, 95))}
                # add normalized gini for regression
                try:
                    gn_vals = bootstrap_values(lambda a, b: gini_normalized(np.asarray(a), np.asarray(b)), y, score, n_iter=self.n_iterations)
                    results['gini_normalized'] = {
                        'original': float(gini_normalized(np.asarray(y), np.asarray(score))),
                        'ci_5': float(np.nanpercentile(gn_vals, 5)),
                        'ci_95': float(np.nanpercentile(gn_vals, 95))
                    }
                except Exception:
                    pass
        except ConfigValidationError as e:
            self.test_signal = self.test_signal or 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.1 skipped</h4><p>{'; '.join(e.args[0])}</p>"}
        except Exception as e:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.1 error</h4><p>{str(e)}</p>"}

        # build table
        rows = []
        for k, v in results.items():
            if 'ci_5' in v:
                rows.append({'metric': k, 'value': f"{v['original']:.4f}", 'ci_5_95': f"[{v['ci_5']:.4f}, {v['ci_95']:.4f}]"})
            else:
                rows.append({'metric': k, 'value': f"{v['original']:.4f}", 'ci_5_95': ''})
        html_parts.append(pd.DataFrame(rows).to_html(index=False))
        # Informational test
        self.test_signal = self.test_signal or 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": "\n".join(html_parts)}




class _LegacySampleSizeAdequacyTest(BaseModelTest):
    def __init__(self, model_type: str = 'classification', step: float = 0.1):
        super().__init__('M 4.2', 'Sample Size Adequacy')
        self.model_type = model_type
        self.step = float(step)

    def run(self, df: pd.DataFrame, config: dict, model=None, model_class=None, sample: str = 'train') -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        df_tr, df_te, df_all = split_frames(df, cfg)
        df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(sample, df_tr)
        task = getattr(cfg, 'task', None) or self.model_type

        feats = get_features(df, cfg, include_categorical=False)
        if not feats:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.2 skipped</h4><p>No numeric features configured (columns.numeric_features)</p>"}

        X = df_used[feats].apply(pd.to_numeric, errors='coerce').fillna(0)
        y = df_used[cfg.columns.target_column]

        sizes = np.arange(self.step, 1.01, self.step)
        scores = []
        for s in sizes:
            n = max(10, int(len(X) * s))
            if model is None and model_class is not None:
                model = model_class()
            if model is None:
                # minimal fallback
                from sklearn.dummy import DummyClassifier
                model = DummyClassifier(strategy='most_frequent') if task == 'classification' else None
            try:
                if model is not None:
                    idx = np.random.choice(len(X), n, replace=False)
                    Xs = X.iloc[idx]
                    ys = y.iloc[idx]
                    model.fit(Xs, ys)
                    preds = model.predict(Xs)
                    score = float(f1_score(ys, _safe_threshold_labels(preds), zero_division=0)) if task == 'classification' else float(r2_score(ys, preds))
                else:
                    score = float('nan')
            except Exception:
                score = float('nan')
            scores.append(score)

        fig = plt.figure(figsize=(8, 4))
        plt.plot(sizes[:len(scores)], scores, marker='o')
        plt.xlabel('Training fraction')
        plt.ylabel('Score')
        html = f"<h4>M4.2 Sample Size Adequacy ({task})</h4><img src='data:image/png;base64,{_to_base64(fig)}' />"
        self.test_signal = self.test_signal or 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": html}


# === New Calibration-focused M4 tests per request ===


class _LegacyCalibrationTest(BaseModelTest):
    def __init__(self, n_bins: int = 10):
        super().__init__('M 4.3', 'Model Calibration')
        self.n_bins = int(n_bins)

    def run(self, df: pd.DataFrame, config: dict, sample: str = 'test') -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        task = getattr(cfg, 'task', None)
        df_tr, df_te, df_all = split_frames(df, cfg)
        df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(sample, df_te)
        try:
            if task == 'classification':
                y, pred, score = get_vectors(df_used, cfg, for_classification=True)
                if score is None:
                    return {"report": "<h4>M4.3 skipped</h4><p>No score_column available for calibration plot.</p>"}
                from sklearn.calibration import calibration_curve
                frac_pos, mean_pred = calibration_curve(y, score, n_bins=self.n_bins)
                fig = plt.figure(figsize=(6, 4))
                plt.plot(mean_pred, frac_pos, marker='o')
                plt.plot([0, 1], [0, 1], '--', color='gray')
                plt.xlabel('Predicted probability')
                plt.ylabel('Fraction positive')
                html = f"<h4>M4.3 Calibration (classification)</h4><img src='data:image/png;base64,{_to_base64(fig)}' />"
                self.test_signal = self.test_signal or 'blue'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"report": html}
            else:
                # Regression calibration: bin by predicted, plot mean predicted vs mean observed
                y, pred, score = get_vectors(df_used, cfg, for_classification=False)
                s = pd.Series(score).astype(float)
                yv = pd.Series(y).astype(float)
                # quantile bins
                bins = pd.qcut(s.rank(method='first')/len(s), q=self.n_bins, duplicates='drop').astype(str)
                df_cal = pd.DataFrame({'pred': s, 'obs': yv, 'bin': bins}).groupby('bin').agg({'pred':'mean','obs':'mean'}).reset_index()
                fig = plt.figure(figsize=(6, 4))
                plt.plot(df_cal['pred'], df_cal['obs'], marker='o', color='#1f77b4')
                # draw y=x line using range of predictions
                mn, mx = float(df_cal['pred'].min()), float(df_cal['pred'].max())
                plt.plot([mn, mx], [mn, mx], '--', color='gray')
                plt.xlabel('Mean Prediction')
                plt.ylabel('Mean Observed')
                plt.title('Calibration (Regression)')
                html = f"<h4>M4.3 Calibration (regression)</h4><img src='data:image/png;base64,{_to_base64(fig)}' />"
                self.test_signal = self.test_signal or 'blue'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"report": html}
        except Exception as e:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.3 error</h4><p>{str(e)}</p>"}




class _LegacyOverfittingTest(BaseModelTest):
    def __init__(self, model_type: str = 'classification'):
        super().__init__('M 4.4', 'Overfitting Detection')
        self.model_type = model_type

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        df_tr, df_te, _ = split_frames(df, cfg)
        task = getattr(cfg, 'task', None) or self.model_type

        try:
            if str(task).lower() == 'classification':
                y_tr, pred_tr, score_tr = get_vectors(df_tr, cfg, for_classification=True)
                y_te, pred_te, score_te = get_vectors(df_te, cfg, for_classification=True)
                pred_tr_lbl = _safe_threshold_labels(pred_tr if pred_tr is not None else score_tr)
                pred_te_lbl = _safe_threshold_labels(pred_te if pred_te is not None else score_te)
                metrics = {
                    'F1': (
                        float(f1_score(y_tr, pred_tr_lbl, zero_division=0)),
                        float(f1_score(y_te, pred_te_lbl, zero_division=0))
                    )
                }
            else:
                y_tr, _, score_tr = get_vectors(df_tr, cfg, for_classification=False)
                y_te, _, score_te = get_vectors(df_te, cfg, for_classification=False)
                # Compute regression metrics
                g_tr = float(gini_normalized(np.asarray(y_tr), np.asarray(score_tr)))
                g_te = float(gini_normalized(np.asarray(y_te), np.asarray(score_te)))
                mse_tr = float(mean_squared_error(y_tr, score_tr))
                mse_te = float(mean_squared_error(y_te, score_te))
                # MAPE (handle zeros)
                eps = 1e-8
                mape_tr = float(np.mean(np.abs((np.asarray(y_tr) - np.asarray(score_tr)) / np.maximum(eps, np.abs(np.asarray(y_tr))))))
                mape_te = float(np.mean(np.abs((np.asarray(y_te) - np.asarray(score_te)) / np.maximum(eps, np.abs(np.asarray(y_te))))))
                metrics = {
                    'gini_normalized': (g_tr, g_te),
                    'mse': (mse_tr, mse_te),
                    'mape': (mape_tr, mape_te),
                }
        except ConfigValidationError as e:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.4 skipped</h4><p>{'; '.join(e.args[0])}</p>"}
        except Exception as e:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.4 error</h4><p>{str(e)}</p>"}

        # Determine signal: red if any metric shows large overfit
        sig = 'green'
        rows = []
        for name, (tr, te) in metrics.items():
            diff = abs(te - tr)
            # Heuristics: stricter for gini, relative for mse/mape
            if name == 'gini_normalized':
                if diff > 0.1:
                    sig = 'red'
                elif diff > 0.05 and sig != 'red':
                    sig = 'orange'
            elif name in ('mse', 'mape'):
                rel = (te - tr) / max(1e-8, tr)
                if rel > 0.3:
                    sig = 'red'
                elif rel > 0.15 and sig != 'red':
                    sig = 'orange'
            rows.append({'metric': name, 'train': f"{tr:.6f}", 'test': f"{te:.6f}", 'abs_diff': f"{diff:.6f}"})

        self.test_signal = sig
        df_res = pd.DataFrame(rows)
        html = f"<h4>M4.4 Overfitting ({task})</h4><p>Signal: <b style='color:{sig}'>{sig}</b></p>{df_res.to_html(index=False)}"
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": html}




class _LegacyMetricStabilityTest(BaseModelTest):
    def __init__(self):
        super().__init__('M 4.5', 'Metric Stability Over Time')

    def run(self, df: pd.DataFrame, config: dict, sample: str = 'test', freq: str = 'M', n_bins: int = 20) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        task = getattr(cfg, 'task', None)
        if task not in ('classification', 'regression'):
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.5 skipped</h4><p>Unknown task in config; expected 'classification' or 'regression'.</p>"}

        date_col = cfg.columns.date_column
        if date_col not in df.columns:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.5 skipped</h4><p>Config must provide a valid date_column for stability over time.</p>"}

        df_tr, df_te, df_all = split_frames(df, cfg)
        df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(sample, df_te)
        df_used = df_used.copy()
        df_used[date_col] = pd.to_datetime(df_used[date_col], errors='coerce')
        df_used = df_used.dropna(subset=[date_col])

        # Helper: CI via normal approx for mean of a series
        def _ci_mean(vals: np.ndarray, alpha: float):
            vals = np.asarray(vals, dtype=float)
            n = len(vals)
            if n < 2:
                return (np.nan, np.nan)
            m = float(np.nanmean(vals))
            s = float(np.nanstd(vals, ddof=1))
            z = 1.96 if alpha == 0.05 else 2.575
            se = s / max(1.0, np.sqrt(n))
            return (m - z * se, m + z * se)

        # Build metric series per period
        period_groups = df_used.groupby(pd.Grouper(key=date_col, freq=freq))

        plots = []
        metrics_to_plot = []
        if task == 'classification':
            metrics_to_plot = ['f1']
        else:
            metrics_to_plot = ['gini_normalized', 'mse', 'mape']

        for metric in metrics_to_plot:
            dates = []
            vals = []
            ci95_l, ci95_h, ci99_l, ci99_h = [], [], [], []
            obs = []
            for period, g in period_groups:
                if g is None or len(g) == 0 or pd.isna(period):
                    continue
                try:
                    if task == 'classification':
                        y, pred, score = get_vectors(g, cfg, for_classification=True)
                        labels = _safe_threshold_labels(pred if pred is not None else score)
                        v = float(f1_score(y, labels, zero_division=0))
                        # build pseudo-sample for CI: treat as mean of per-row scores (approx)
                        per_row = labels == y
                        low95, high95 = _ci_mean(np.asarray(per_row, dtype=float), 0.05)
                        low99, high99 = _ci_mean(np.asarray(per_row, dtype=float), 0.01)
                    else:
                        y, _, s = get_vectors(g, cfg, for_classification=False)
                        if metric == 'gini_normalized':
                            v = float(gini_normalized(np.asarray(y), np.asarray(s)))
                            # approximate CI like in M2.4
                            n = len(g)
                            z95, z99 = 1.96, 2.575
                            se = np.sqrt(max(1e-9, v * (1 - v)) / max(1, n))
                            low95, high95 = v - z95 * se, v + z95 * se
                            low99, high99 = v - z99 * se, v + z99 * se
                        elif metric == 'mse':
                            err = np.asarray(y) - np.asarray(s)
                            per = err**2
                            v = float(np.mean(per))
                            low95, high95 = _ci_mean(per, 0.05)
                            low99, high99 = _ci_mean(per, 0.01)
                        else:  # mape
                            eps = 1e-8
                            yv = np.asarray(y, dtype=float)
                            sv = np.asarray(s, dtype=float)
                            mask = np.abs(yv) > eps
                            per = np.abs((yv[mask] - sv[mask]) / np.maximum(eps, np.abs(yv[mask])))
                            if len(per) == 0:
                                continue
                            v = float(np.mean(per))
                            low95, high95 = _ci_mean(per, 0.05)
                            low99, high99 = _ci_mean(per, 0.01)
                    dates.append(pd.to_datetime(period))
                    vals.append(v)
                    ci95_l.append(low95)
                    ci95_h.append(high95)
                    ci99_l.append(low99)
                    ci99_h.append(high99)
                    obs.append(int(len(g)))
                except Exception:
                    continue
            if not dates:
                continue

            order = np.argsort(pd.to_datetime(dates))
            d = np.array(dates)[order]
            v = np.array(vals)[order]
            l95 = np.array(ci95_l)[order]
            h95 = np.array(ci95_h)[order]
            l99 = np.array(ci99_l)[order]
            h99 = np.array(ci99_h)[order]
            nobs = np.array(obs)[order]

            fig, ax1 = plt.subplots(figsize=(12, 4))
            ax2 = ax1.twinx()
            # Bars: observations
            ax2.bar(d, nobs, alpha=0.6, color='#2ca02c', label=OBSERVATION_COUNT_LABEL)
            # CI fills (continuous)
            ax1.fill_between(d, l99, h99, alpha=0.3, color='#ff4444', label='99% CI')
            ax1.fill_between(d, l95, h95, alpha=0.5, color='#ffcc00', label='95% CI')
            # Main line
            ax1.plot(d, v, color='black', linewidth=2, marker='o', markersize=4, label=metric)
            # Thresholds for gini
            if metric == 'gini_normalized':
                ax1.axhline(y=0.15, color='red', linestyle='--', alpha=0.7)
                ax1.axhline(y=0.35, color='orange', linestyle='--', alpha=0.7)
            ax1.set_xlabel('Period')
            ylabel = {
                'gini_normalized': 'Normalized Gini',
                'mse': 'MSE',
                'mape': 'MAPE',
                'f1': 'F1'
            }.get(metric, 'Metric')
            ax1.set_ylabel(ylabel)
            ax2.set_ylabel(OBSERVATION_COUNT_LABEL)
            ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
            ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=1))
            plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha='right')
            ax1.legend(loc='upper left')
            fig.tight_layout()
            plots.append((metric, _to_base64(fig)))

        if not plots:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.5 skipped</h4><p>No metric could be computed by periods.</p>"}

        # Assemble HTML with all plots
        parts = [f"<h4>M4.5 Metric Stability ({task})</h4>"]
        for metric, img in plots:
            title = {
                'gini_normalized': 'Normalized Gini over Time with Confidence Intervals',
                'mse': 'MSE over Time with Confidence Intervals',
                'mape': 'MAPE over Time with Confidence Intervals',
                'f1': 'F1 over Time with Confidence Intervals'
            }.get(metric, metric)
            parts.append(f"<h5>{title}</h5><img src='data:image/png;base64,{img}' />")
        self.test_signal = self.test_signal or 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": "".join(parts)}






class _LegacyShapImportanceTest(BaseModelTest):
    """
    Section 4.3.1. SHAP importance comparison between training and validation
    (Test disabled as SHAP is removed from dependencies)
    """
    def __init__(self):
        super().__init__("M 4.7", "SHAP Importance Comparison")

    def run(self, df: pd.DataFrame, config: dict, model, top_n: int = 20) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting (DISABLED)")
        self.test_signal = 'blue'
        return {"report": "<h4>SHAP Importance Comparison Test</h4><p>This test is disabled because SHAP library has been removed.</p>"}




class _LegacyFeatureContributionTest(BaseModelTest):
    """
    M4.8: Feature reduction / informativeness test.

    Цель: выявить признаки, которые не вносят вклад в улучшение метрики и могут быть удалены
    без ухудшения качества/стабильности модели. Основной метод — SHAP importance.
    В качестве валидатора используется forward selection (fallback) или backward selection.

    Поведение:
      * пытается вычислить SHAP importance; если shap недоступен — использует forward selection;
      * строит uplift-кривые (train / valid / test при наличии);
      * вычисляет бутстрэпный CI для разницы метрик между лучшей reduced-моделью и моделью на всех признаках;
      * выставляет сигнал по критериям 99%/95% CI на validation (или на train при отсутствии validation).
    """

    def __init__(self, model_type: str = 'classification', step: int = 1, n_bootstrap: int = 300):
        super().__init__("M 4.8", "Feature Contribution / Reduction Test")
        self.model_type = model_type
        self.step = int(step)
        self.n_bootstrap = int(n_bootstrap)

    def run(self, df: pd.DataFrame, config: dict, model_class=None, model=None, sample_col_name: str = None) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        # determine samples
        sample_col = getattr(cfg.columns, 'sample_column', None) if sample_col_name is None else sample_col_name
        df_tr, df_te, df_all = split_frames(df, cfg)
        # detect validation split if present
        val_split = None
        if sample_col and sample_col in df.columns:
            uniq = df[sample_col].astype(str).str.lower().unique().tolist()
            for cand in ('validation', 'valid', 'val'):
                if cand in uniq:
                    val_split = cand
                    break

        df_val = None
        if val_split:
            df_val = df[df[sample_col].astype(str).str.lower() == val_split].copy()

        # pick eval set for signal: prefer validation, else use train
        signal_set = 'validation' if df_val is not None else 'train'

        # feature list
        feats = get_features(df, cfg, include_categorical=True)
        if not feats:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.8 skipped</h4><p>No features configured (numeric/categorical).</p>"}

        # prepare data
        df_train = df_tr.copy()
        df_valid = df_val.copy() if df_val is not None else None
        df_test = df_te.copy()

        target = cfg.columns.target_column
        if target not in df.columns:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.8 skipped</h4><p>target_column missing in df.</p>"}

        y_tr = df_train[target]
        y_val = df_valid[target] if df_valid is not None else None
        y_te = df_test[target]

        # metric selection
        is_class = (str(getattr(cfg, 'task', None) or self.model_type).lower() == 'classification')
        metric_func = (lambda a, b: f1_score(a, b, zero_division=0)) if is_class else (lambda a, b: r2_score(a, b))

        # get feature importance ordering: only fallback (SHAP removed)
        SHAP_AVAILABLE = False
        importance_order: List[str] = []

        # fallback: forward selection (validator)
        if not importance_order:
            # simple forward selection based on improvement on validation (or train)
            base_pool = feats.copy()
            chosen = []
            eval_df = df_valid if df_valid is not None else df_train
            X_eval_base = eval_df
            y_eval_base = y_val if df_valid is not None else y_tr
            while base_pool:
                best_feat = None
                best_score = -np.inf
                for f in tqdm(base_pool, desc='Forward selection: перебор кандидатов', leave=True):
                    cand = chosen + [f]
                    try:
                        m = model_class() if model_class is not None else (model if model is not None else None)
                        if m is None:
                            continue
                        Xc = df_train[cand]
                        m.fit(Xc, y_tr)
                        preds = m.predict(X_eval_base[cand])
                        if is_class:
                            preds = _safe_threshold_labels(preds)
                        sc = metric_func(y_eval_base, preds)
                    except Exception:
                        sc = -np.inf
                    if sc > best_score:
                        best_score = sc
                        best_feat = f
                if best_feat is None:
                    break
                chosen.append(best_feat)
                base_pool.remove(best_feat)
            importance_order = chosen if chosen else feats

        # ensure order contains only available feats
        importance_order = [f for f in importance_order if f in feats]

        # build uplift curves: train / valid / test
        results = []  # tuples (k, score_train, score_val, score_test)
        full_model = model_class() if model_class is not None else (model if model is not None else None)
        if full_model is None:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.8 skipped</h4><p>Provide model_class or prefit model.</p>"}

        # fit full model
        try:
            full_model.fit(df_train[importance_order], y_tr)
            preds_full_val = full_model.predict(df_valid[importance_order]) if df_valid is not None else None
            preds_full_tr = full_model.predict(df_train[importance_order])
            preds_full_te = full_model.predict(df_test[importance_order])
            if is_class:
                if preds_full_val is not None:
                    preds_full_val = _safe_threshold_labels(preds_full_val)
                preds_full_tr = _safe_threshold_labels(preds_full_tr)
                preds_full_te = _safe_threshold_labels(preds_full_te)
        except Exception as e:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.8 error</h4><p>Failed to fit full model: {e}</p>"}

        # baseline metrics
        base_val_score = metric_func(y_val, preds_full_val) if df_valid is not None else None
        base_tr_score = metric_func(y_tr, preds_full_tr)
        base_te_score = metric_func(y_te, preds_full_te)

        for k in tqdm(range(self.step, len(importance_order) + 1, self.step), desc='Оценка reduced-моделей по k признакам', leave=True):
            use_feats = importance_order[:k]
            try:
                m = model_class()
                m.fit(df_train[use_feats], y_tr)
                p_tr = m.predict(df_train[use_feats])
                p_te = m.predict(df_test[use_feats])
                p_val = m.predict(df_valid[use_feats]) if df_valid is not None else None
                if is_class:
                    p_tr = _safe_threshold_labels(p_tr)
                    p_te = _safe_threshold_labels(p_te)
                    if p_val is not None:
                        p_val = _safe_threshold_labels(p_val)
                s_tr = metric_func(y_tr, p_tr)
                s_te = metric_func(y_te, p_te)
                s_val = metric_func(y_val, p_val) if df_valid is not None else None
            except Exception:
                s_tr = float('nan'); s_val = float('nan'); s_te = float('nan')
            results.append((k, s_tr, s_val, s_te))

        res_df = pd.DataFrame(results, columns=['#Features', 'Train', 'Valid', 'Test'])

        # find best reduced model on validation (or train)
        if df_valid is not None and not res_df['Valid'].isna().all():
            best_idx = int(res_df['Valid'].idxmax())
            best_row = res_df.iloc[best_idx]
            best_k = int(best_row['#Features'])
            best_score = float(best_row['Valid'])
            baseline_score = base_val_score
            y_eval = y_val
            preds_full_eval = preds_full_val
            # get preds for best reduced
            try:
                m_best = model_class(); m_best.fit(df_train[importance_order[:best_k]], y_tr)
                preds_best_eval = m_best.predict(df_valid[importance_order[:best_k]])
                if is_class: preds_best_eval = _safe_threshold_labels(preds_best_eval)
            except Exception:
                preds_best_eval = None
        else:
            # no validation -> use train
            best_idx = int(res_df['Train'].idxmax())
            best_row = res_df.iloc[best_idx]
            best_k = int(best_row['#Features'])
            best_score = float(best_row['Train'])
            baseline_score = base_tr_score
            y_eval = y_tr
            preds_full_eval = preds_full_tr
            try:
                m_best = model_class(); m_best.fit(df_train[importance_order[:best_k]], y_tr)
                preds_best_eval = m_best.predict(df_train[importance_order[:best_k]])
                if is_class: preds_best_eval = _safe_threshold_labels(preds_best_eval)
            except Exception:
                preds_best_eval = None

        # if best_k equals full features -> no insignificant features
        if best_k >= len(importance_order):
            self.test_signal = 'green'
            html = f"<h4>M4.8 No insignificant features found</h4><p>Best model uses full set of features (k={best_k}).</p>" + res_df.to_html(index=False)
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": html}

        # bootstrap difference distribution
        if preds_best_eval is None or preds_full_eval is None:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.8 error</h4><p>Could not obtain predictions for comparison.</p>"}

        diffs = []
        rng = np.random.RandomState(42)
        n = len(y_eval)
        for _ in tqdm(range(self.n_bootstrap), desc='Бутстрэп разницы метрик', leave=True):
            idx = rng.randint(0, n, n)
            y_s = y_eval.iloc[idx].values
            full_s = np.array(preds_full_eval)[idx]
            best_s = np.array(preds_best_eval)[idx]
            try:
                diffs.append(metric_func(y_s, best_s) - metric_func(y_s, full_s))
            except Exception:
                diffs.append(float('nan'))

        diffs = np.array(diffs)
        lo99, hi99 = np.nanpercentile(diffs, [0.5, 99.5])
        lo95, hi95 = np.nanpercentile(diffs, [2.5, 97.5])

        # determine signal per spec
        if lo99 > 0:
            signal = 'green'
            reason = '99% CI of metric difference > 0 (improvement)'
        elif lo95 > 0:
            signal = 'orange'
            reason = '95% CI of metric difference > 0 (improvement)'
        else:
            signal = 'red'
            reason = '0 in 95% CI of metric difference or no significant improvement'

        self.test_signal = signal

        # build plots: uplift curves
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.plot(res_df['#Features'], res_df['Train'], marker='o', label='Train')
        if 'Valid' in res_df.columns and not res_df['Valid'].isna().all():
            ax.plot(res_df['#Features'], res_df['Valid'], marker='o', label='Valid')
        if 'Test' in res_df.columns and not res_df['Test'].isna().all():
            ax.plot(res_df['#Features'], res_df['Test'], marker='o', label='Test')
        ax.set_xlabel('# Features')
        ax.set_ylabel('Metric')
        ax.set_title('Feature Uplift Curves')
        ax.legend()
        plt.tight_layout()
        plot_b64 = _to_base64(fig)

        html = f"<h4>M4.8 Feature Reduction Test (best_k={best_k})</h4>"
        html += f"<p><b>Signal:</b> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span> — {reason}</p>"
        html += f"<p>Best k = {best_k}, improvement = {best_score - baseline_score:.4f} (95% CI [{lo95:.4f}, {hi95:.4f}], 99% CI [{lo99:.4f}, {hi99:.4f}])</p>"
        html += f"<img src=\"data:image/png;base64,{plot_b64}\"/>"
        html += "<h5>Uplift table</h5>" + res_df.to_html(index=False, float_format='%.4f')

        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": html}



class _LegacyUpliftTest(BaseModelTest):
    def __init__(self, model_type: str = 'classification', step: int = 1):
        super().__init__("M 4.9", "Feature Uplift Test")
        self.model_type = model_type
        self.step = step

    def run(self,
            df: pd.DataFrame = None,
            config: dict = None,
            model_class=None,
            feature_importance: pd.Series | None = None,
            X_train: pd.DataFrame | None = None, y_train: pd.Series | None = None,
            X_test: pd.DataFrame | None = None, y_test: pd.Series | None = None
            ) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")

        # --- Backward compatibility ---
        if df is None and all(v is not None for v in [X_train, y_train, X_test, y_test, model_class]) and config is None:
            feats_order = list(feature_importance.index) if isinstance(feature_importance, pd.Series) else list(X_train.columns)
        else:
            if df is None or config is None or model_class is None:
                raise ValueError("Please provide df, config and model_class.")
            
            cfg = ensure_config(config, df)
            sample_col = get_col_name(cfg, "sample_column")
            target_col = get_col_name(cfg, "target_column")

            df_tr = _subset_by_sample(df, config, "train")
            df_te = _subset_by_sample(df, config, "test")
            feats = get_features(df, cfg, include_categorical=True)
            X_train = df_tr[feats].copy()
            X_test  = df_te[feats].copy()
            y_train = df_tr[target_col]
            y_test  = df_te[target_col]

            # порядок признаков: если передали — используем, иначе — учим модель и берём feature_importances_
            if isinstance(feature_importance, pd.Series):
                feats_order = [f for f in feature_importance.sort_values(ascending=False).index if f in X_train.columns]
            else:
                base_model = model_class()
                base_model.fit(X_train, y_train)
                if hasattr(base_model, "feature_importances_"):
                    importances = pd.Series(base_model.feature_importances_, index=X_train.columns).sort_values(ascending=False)
                    feats_order = list(importances.index)
                else:
                    # fallback: как пришли
                    feats_order = list(X_train.columns)

        # основной цикл добавления признаков
        results = []
        best_test = -np.inf
        optimal_features = 0

        for k in tqdm(range(self.step, len(feats_order) + 1, self.step), desc='Uplift: добавление признаков', leave=True):
            use_feats = feats_order[:k]
            model = model_class()
            model.fit(X_train[use_feats], y_train)

            if self.model_type == "classification":
                y_pred = model.predict(X_test[use_feats])
                score = f1_score(y_test, y_pred)
            else:
                y_pred = model.predict(X_test[use_feats])
                score = r2_score(y_test, y_pred)

            results.append((k, score))
            if score > best_test:
                best_test = score
                optimal_features = k

        res_df = pd.DataFrame(results, columns=["#Features", "TestScore"])
        max_test_score = res_df["TestScore"].max()

        # светофор
        if len(res_df) >= 3 and res_df["TestScore"].iloc[-1] < max_test_score * 0.98:
            signal = "red"      # явное ухудшение к концу — лишние фичи
        elif len(res_df) >= 3 and res_df["TestScore"].iloc[-1] < max_test_score * 0.995:
            signal = "orange"   # лёгкое ухудшение
        else:
            signal = "green"

        # график
        plt.figure(figsize=(12, 8))
        plt.plot(res_df["#Features"], res_df["TestScore"], marker="o")
        plt.axvline(optimal_features, linestyle="--")
        plt.xlabel("#Features")
        plt.ylabel("Score")
        plt.title("Feature Uplift Curve")
        buf = BytesIO()
        plt.savefig(buf, format="png", bbox_inches="tight")
        plt.close()
        plot_img = base64.b64encode(buf.getvalue()).decode("utf-8")

        self.test_signal = signal
        html_content = f"""
        <h4>Feature Uplift Test</h4>
        <p><strong>Signal:</strong> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span></p>
        <p><strong>Optimal number of features:</strong> {optimal_features}</p>
        <p><strong>Max test score:</strong> {max_test_score:.4f}</p>
        <img src="data:image/png;base64,{plot_img}" />
        <p><strong>Интерпретация:</strong> Если кривая test выходит на плато или начинает снижаться, 
        это может указывать на наличие избыточных признаков.</p>
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": html_content}




class _LegacyMissingValuesImpactTest(BaseModelTest):
    """
    Тест 4.10. Определение признаков с большим количеством пропущенных значений
    """
    def __init__(self, threshold=0.8):
        super().__init__('M 4.10', 'Features with High Missing Value Ratio')
        self.threshold = threshold

    def run(self,
            df: pd.DataFrame = None,
            config: dict = None,
            X: pd.DataFrame = None,              # legacy-режим (обратная совместимость)
            time_column: str | None = None       # legacy-режим
            ) -> Dict[str, str]:
        """
        Новый контракт: передавайте df + config.
        Legacy: X + time_column продолжает работать.
        """
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        import io, base64
        import numpy as np
        import pandas as pd
        import matplotlib.pyplot as plt

        # --- Новый путь: df + config ---
        if df is not None and config is not None:
            # поддержка вложенного вида config["columns"]
            cols = config["columns"] if isinstance(config, dict) and "columns" in config else config

            # соберём список фич из конфига
            num = cols.get("numeric_features", []) or []
            cat = cols.get("categorical_features", []) or []
            features = list(dict.fromkeys([*num, *cat]))  # порядок + без дублей

            # исключим служебные колонки
            reserved = {
                cols.get("date_column"),
                cols.get("target_column"),
                cols.get("sample_column"),
                cols.get("id_column"),
                cols.get("score_column"),
            }
            features = [f for f in features if f and f not in reserved]

            if not features:
                raise ValueError("Пустой список признаков: задайте numeric_features и/или categorical_features в config.columns")

            missing = [c for c in features if c not in df.columns]
            if missing:
                raise KeyError(f"В DataFrame отсутствуют колонки из списка фич: {missing}")

            X_use = df[features].copy()
            time_col = cols.get("date_column", None)

            # приведём дату к datetime для временных графиков
            if time_col and time_col in df.columns:
                try:
                    df = df.copy()
                    df[time_col] = pd.to_datetime(df[time_col], errors="coerce")
                except Exception:
                    pass

        # --- Legacy путь: X + time_column ---
        elif X is not None:
            X_use = X.copy()
            time_col = time_column
            # в legacy режиме у нас может не быть df; временная динамика будет недоступна, если time_col не в X_use
            if time_col is not None and time_col not in X_use.columns:
                # ок, просто игнорируем динамику
                time_col = None
        else:
            raise ValueError("Передайте либо (df, config), либо (X, time_column)")

        # ===== 1) Доля пропусков по признакам =====
        feature_columns = [c for c in X_use.columns if c != time_col]  # не анализируем саму колонку времени
        X_features = X_use[feature_columns]

        missing_ratios = X_features.isnull().mean().sort_values(ascending=False)
        high_missing = missing_ratios[missing_ratios > self.threshold]

        # ===== 2) Визуализация: топ-30 признаков по доле пропусков (barh) =====
        plots_html = []
        if len(missing_ratios) > 0:
            top = missing_ratios.head(30)[::-1]  # для горизонтального барчарта снизу вверх
            fig, ax = plt.subplots(figsize=(12, 8))
            ax.barh(top.index, top.values)
            ax.set_xlim(0, 1)
            ax.set_xlabel("Missing ratio")
            ax.set_title("Missing values ratio by feature (top 30)")
            ax.grid(True, linestyle="--", linewidth=0.5, axis="x")
            plt.tight_layout()

            buf = io.BytesIO()
            plt.savefig(buf, format="png", dpi=120, bbox_inches="tight")
            plt.close(fig)
            img_bar = base64.b64encode(buf.getvalue()).decode("utf-8")
            plots_html.append(f'<h5>Top-30 missing ratios</h5><img src="data:image/png;base64,{img_bar}">')

        # ===== 3) Таблица признаков с высокой долей пропусков =====
        table_html = "<p><i>Нет признаков с долей пропусков выше порога.</i></p>"
        if len(high_missing) > 0:
            tbl = high_missing.to_frame(name="MissingRatio").reset_index().rename(columns={"index": "Feature"})
            tbl["MissingRatio"] = (tbl["MissingRatio"] * 100).round(2)
            table_html = tbl.to_html(index=False)

        # ===== 4) Динамика пропусков по времени (heatmap для high_missing) =====
        heatmap_html = ""
        if time_col is not None and time_col in getattr(df, "columns", []) and len(high_missing) > 0:
            # соберём фрейм: время + интересующие признаки
            tmp = pd.concat([df[[time_col]].reset_index(drop=True),
                            X_use[high_missing.index].reset_index(drop=True)], axis=1)
            tmp = tmp.dropna(subset=[time_col])
            if len(tmp) > 0:
                # месячная агрегация по умолчанию
                tmp[time_col] = pd.to_datetime(tmp[time_col], errors="coerce")
                tmp = tmp.dropna(subset=[time_col])
                grouped = tmp.groupby(pd.Grouper(key=time_col, freq="M"))
                # матрица: периоды x признаки (доля пропусков)
                periods = []
                rows = []
                for period, g in grouped:
                    if period is pd.NaT:
                        continue
                    periods.append(period)
                    rows.append(g[high_missing.index].isnull().mean().values)
                if len(rows) > 0:
                    M = np.vstack(rows)  # shape: (#periods, #features)
                    # строим heatmap (features x periods)
                    fig2, ax2 = plt.subplots(figsize=(max(10, len(periods) * 0.4),
                                                    max(4, len(high_missing) * 0.5)))
                    im = ax2.imshow(M.T, aspect="auto", origin="lower", vmin=0, vmax=1)
                    ax2.set_yticks(np.arange(len(high_missing.index)))
                    ax2.set_yticklabels(high_missing.index)
                    ax2.set_xticks(np.arange(len(periods)))
                    ax2.set_xticklabels([p.strftime("%Y-%m") for p in periods],
                                        rotation=45, ha="right")
                    ax2.set_title("Missing ratio over time (features with high missing)")
                    ax2.grid(False)
                    cbar = fig2.colorbar(im, ax=ax2, fraction=0.025, pad=0.02)
                    cbar.set_label("Missing ratio")
                    plt.tight_layout()

                    buf2 = io.BytesIO()
                    plt.savefig(buf2, format="png", dpi=120, bbox_inches="tight")
                    plt.close(fig2)
                    img_heat = base64.b64encode(buf2.getvalue()).decode("utf-8")
                    heatmap_html = f'<h5>Dynamics heatmap (monthly)</h5><img src="data:image/png;base64,{img_heat}">'

        # ===== 5) Сигнал по доле «плохих» признаков =====
        share_high = (len(high_missing) / max(len(feature_columns), 1)) if len(feature_columns) else 0.0
        if share_high == 0:
            signal = "green"
        elif share_high <= 0.10:
            signal = "orange"
        else:
            signal = "red"
        self.test_signal = signal

        # ===== 6) Сборка HTML =====
        header = f"""
        <h4>Features with High Missing Value Ratio (threshold = {int(self.threshold*100)}%)</h4>
        <p><b>Signal:</b> <span style="color:{signal}; font-weight:bold">{signal.upper()}</span></p>
        <p>Всего фич (без time): <b>{len(feature_columns)}</b>. 
        Фич с пропусками &gt; {int(self.threshold*100)}%: <b>{len(high_missing)}</b> 
        ({round(share_high*100, 2)}%).</p>
        """

        html = header + "".join(plots_html) + "<h5>Features above threshold</h5>" + table_html + heatmap_html
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"DASHBOARD": html}




class _LegacyTwoForestSelectionTest(BaseModelTest):
    """
    M4.11 Двухлесовой отбор (Two-Forest Selection)

    Для каждого признака вычисляется распределение разниц важности между честной
    моделью и моделью с перемешанным признаком, при обучении на первой половине
    и проверке на второй, и наоборот. p-value строится по эмпирическому распределению
    согласно описанию пользователя.
    """
    def __init__(self, model_type: str = 'classification', n_repeat: int = 300, test_size: float = 0.5, random_state: int = 42):
        super().__init__('M 4.11', 'Two-Forest Selection')
        self.model_type = model_type
        self.n_repeat = int(n_repeat)
        self.test_size = float(test_size)
        self.random_state = int(random_state)

    def run(self, df: pd.DataFrame, config: dict, sample: str = 'train') -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        # features
        feats = list(getattr(cfg.columns, 'numeric_features', []) or []) + list(getattr(cfg.columns, 'categorical_features', []) or [])
        feats = [f for f in feats if f in df.columns]
        if not feats:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.11 skipped</h4><p>No features configured.</p>"}

        # pick sample subset
        df_tr = _subset_by_sample(df, config if isinstance(config, dict) else {'columns': cfg.columns}, sample)
        if df_tr is None or len(df_tr) < 4:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.11 skipped</h4><p>Not enough rows in selected sample.</p>"}

        target = get_col_name(cfg, 'target_column')
        if target not in df_tr.columns:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.11 skipped</h4><p>target_column missing in df.</p>"}

        X = df_tr[feats].copy()
        y = df_tr[target].copy()

        # choose model class
        is_class = (str(getattr(cfg, 'task', None) or self.model_type).lower() == 'classification')
        Model = RandomForestClassifier if is_class else RandomForestRegressor

        rng = np.random.RandomState(self.random_state)

        # store diffs per feature for both directions
        diffs_A = {f: [] for f in feats}  # train on A, test on B
        diffs_B = {f: [] for f in feats}  # train on B, test on A

        # helper: compute importance score as mean agreement with target on holdout
        def importance_score(model, X_hold, y_hold, feature):
            try:
                preds = model.predict(X_hold)
                # for classification we compare predicted label to y_hold
                if is_class:
                    return float((preds == y_hold).mean())
                else:
                    # regression: use negative MSE as higher-is-better proxy
                    from sklearn.metrics import mean_squared_error
                    return -float(mean_squared_error(y_hold, preds))
            except Exception:
                return float('nan')

        n = len(X)
        idx_all = np.arange(n)
        for direction in (0, 1):
            # direction 0: train on split A -> test on B; direction 1: train on B -> test on A
            for rep in range(self.n_repeat):
                # random split into two halves
                i_tr, i_te = train_test_split(idx_all, test_size=self.test_size, random_state=rng.randint(0, 2**31-1))

                X_A, X_B = X.iloc[i_tr].reset_index(drop=True), X.iloc[i_te].reset_index(drop=True)
                y_A, y_B = y.iloc[i_tr].reset_index(drop=True), y.iloc[i_te].reset_index(drop=True)

                if direction == 0:
                    X_train, y_train, X_test, y_test = X_A, y_A, X_B, y_B
                else:
                    X_train, y_train, X_test, y_test = X_B, y_B, X_A, y_A

                # fit honest model on X_train
                try:
                    m = Model(random_state=rng.randint(0, 2**31-1))
                    m.fit(X_train, y_train)
                except Exception:
                    # skip this repetition
                    continue

                # compute importance per feature as score when predicting on X_test
                base_scores = {}
                for f in tqdm(feats, desc='Вычисление базовых скорoв (по фиче)', leave=True):
                    base_scores[f] = importance_score(m, X_test, y_test, f)

                # now permute each feature on train and refit
                for f in tqdm(feats, desc='Перестановки и переобучение (по фиче)', leave=True):
                    X_perm = X_train.copy()
                    X_perm[f] = X_perm[f].sample(frac=1.0, random_state=rng.randint(0, 2**31-1)).reset_index(drop=True)
                    try:
                        m2 = Model(random_state=rng.randint(0, 2**31-1))
                        m2.fit(X_perm, y_train)
                    except Exception:
                        continue
                    perm_score = importance_score(m2, X_test, y_test, f)
                    diff = base_scores.get(f, float('nan')) - perm_score
                    if direction == 0:
                        diffs_A[f].append(diff)
                    else:
                        diffs_B[f].append(diff)

        # compute p-values per feature: follow user's spec
        import scipy.stats as st
        results = []
        x_vals = []
        y_vals = []
        for f in feats:
            dA = np.array(diffs_A.get(f, []) or [0.0])
            dB = np.array(diffs_B.get(f, []) or [0.0])

            # build null distribution from negative and zero scores as described
            negA = -dA[dA <= 0]
            negB = -dB[dB <= 0]
            posA = dA[dA > 0]
            posB = dB[dB > 0]

            # empirical CDF: p = 1 - CDF( observed_positive ) over flipped negative set
            # handle empty sets
            def emp_pval(observed, null_set):
                if len(null_set) == 0:
                    return 1.0
                return 1.0 - (np.searchsorted(np.sort(null_set), observed, side='right') / len(null_set))

            # combine positive diffs from both directions appropriately
            obsA = posA.mean() if len(posA) > 0 else 0.0
            obsB = posB.mean() if len(posB) > 0 else 0.0

            pA = emp_pval(obsA, negA) if len(negA) > 0 else 1.0
            pB = emp_pval(obsB, negB) if len(negB) > 0 else 1.0

            # aggregate p-values conservatively (max)
            pval = max(pA, pB)

            results.append({'feature': f, 'p_value': float(pval), 'mean_diff_A': float(np.nanmean(dA)), 'mean_diff_B': float(np.nanmean(dB)), 'nA': int(len(dA)), 'nB': int(len(dB))})
            x_vals.append(np.nanmean(dA))
            y_vals.append(np.nanmean(dB))

        res_df = pd.DataFrame(results).sort_values('p_value')

        # scatter plot mean diffs
        fig = plt.figure(figsize=(6, 6))
        plt.scatter(x_vals, y_vals)
        plt.axhline(0, color='gray', linestyle='--')
        plt.axvline(0, color='gray', linestyle='--')
        plt.xlabel('Mean diff (train A -> test B)')
        plt.ylabel('Mean diff (train B -> test A)')
        plt.title('Two-Forest mean importance diffs')
        for i, f in enumerate(feats):
            plt.text(x_vals[i], y_vals[i], f, fontsize=8)
        plt.tight_layout()
        plot_b64 = _to_base64(fig)

        html = f"<h4>M4.11 Two-Forest Selection</h4><p>n_repeat={self.n_repeat}, sample fraction test_size={self.test_size}</p>"
        html += f"<img src='data:image/png;base64,{plot_b64}' />"
        html += "<h5>Feature p-values (sorted)</h5>" + res_df.to_html(index=False, float_format='%.4g')

        # signal: features with p < 0.05 are considered stable important
        sig_count = (res_df['p_value'] < 0.05).sum()
        self.test_signal = 'green' if sig_count > 0 else 'red'

        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": html}

