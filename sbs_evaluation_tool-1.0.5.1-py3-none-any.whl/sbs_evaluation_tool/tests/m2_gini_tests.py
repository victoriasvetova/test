"""Back-compat shim — the real implementation now lives in the ``tests.m2`` subpackage.

Kept so existing imports of the form

    from sbs_evaluation_tool.tests.m2_gini_tests import M21_GiniTest, M22_GiniFactorsTest, ...

continue to work without changes.
"""

from .m2 import (
    M21_GiniTest,
    M22_GiniFactorsTest,
    M23_GiniDynamicsTest,
    M24_GiniUpliftTest,
)
# Module-level helpers exported for callers that historically imported them directly.
from .m2._shared import (
    powerstat_value,
    gini_one_feature,
    gini_for_features_fast,
    gini_one_categorical_feature,
    gini_for_categorical_features,
    powerstat_one_feature,
    powerstat_for_features_fast,
    powerstat_one_categorical_feature,
    powerstat_for_categorical_features,
    determine_optimal_freq,
)

__all__ = [
    "M21_GiniTest",
    "M22_GiniFactorsTest",
    "M23_GiniDynamicsTest",
    "M24_GiniUpliftTest",
    "powerstat_value",
    "gini_one_feature",
    "gini_for_features_fast",
    "gini_one_categorical_feature",
    "gini_for_categorical_features",
    "powerstat_one_feature",
    "powerstat_for_features_fast",
    "powerstat_one_categorical_feature",
    "powerstat_for_categorical_features",
    "determine_optimal_freq",
]
