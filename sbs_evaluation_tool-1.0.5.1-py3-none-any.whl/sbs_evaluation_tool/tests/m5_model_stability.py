# tests_m5_stability.py
from ..core.base_test import BaseModelTest
import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.utils.multiclass import type_of_target
from io import BytesIO
import base64
from tqdm import tqdm
import matplotlib.pyplot as plt
from typing import List, Dict, Optional
from .psi_calculator import PSICalculatorExtended
from .psi_calculator import PSICalculator
from ..core.metrics import gini_normalized
from ..core.styles import COLORS, figure
from ..core.config_validation import validate_config as _validate_config, ConfigValidationError
from ..core.data_utils import (
    ensure_config,
    split_frames,
    split_sample_masks,
    get_col_name,
    get_score_col,
    get_weight_col,
    get_features,
    get_vectors,
    is_binary_mode,
    is_big_data_mode,
    is_generic_classification_mode,
    is_glm_preset,
    resolve_feature_columns,
    sample_frame_for_big_data,
)
from ._visual_utils import apply_standard_axis_style, figure_to_base64
from joblib import Parallel, delayed
import logging

logger = logging.getLogger(__name__)


def _classification_mode_na(test_name: str) -> Dict[str, str]:
    return {
        "combined": (
            f"<h4>{test_name}</h4>"
            "<p><b>Skipped:</b> generic `classification` mode is not yet mapped "
            "to a methodology-specific stability test. Use `binary` for binomial/logistic tasks.</p>"
        )
    }


# ---------------------------------------------------------------------------
# Methodology-aligned helpers for M 5.3 (Score-distribution PSI)
# ---------------------------------------------------------------------------
# Источник: «Методика валидации моделей GLM-регрессии», §7.10 + Приложение 4
# §4.11 (правило Скотта с объединением «хвостовых» бинов <2.5 %).
# ---------------------------------------------------------------------------

# Минимальная доля наблюдений в крайних бинах: если меньше — объединяем.
_M53_TAIL_THRESHOLD = 0.025
# Светофор PSI: red ≥ 0.20, orange ≥ 0.10 (Таблица 6.23).
_M53_PSI_RED = 0.20
_M53_PSI_ORANGE = 0.10


def _scott_bin_edges(values: np.ndarray,
                     percentile_clip: float = 0.5) -> np.ndarray:
    """Compute Scott's-rule bin edges with robust outer bookends.

    Step rule (per методология §4.11 with a practical robustification):

      h = max(h_min*, h_Scott)
      h_Scott = 3.49 · σ · n^(-1/3)
      h_min*  = max gap between consecutive sorted *interior* values
                (interior = within ``percentile_clip`` … ``100 - percentile_clip``)

    The methodology's exact ``h_min = sup of all consecutive gaps`` is
    fatally sensitive to a single outlier — for an actuarial Poisson
    score with a long right tail it produces just 1-2 bins. Restricting
    ``h_min`` to the dense interior keeps the bin width sensible while
    preserving the methodology's intent (don't bin finer than the
    natural granularity of the data).

    The grid extends from ``-inf`` to ``+inf`` via outer bookends so the
    tail-merging step can fold edge bins into ``(-inf, x]`` and
    ``(y, +inf]`` labels — matching the reference upstream rendering.
    """
    v = values[np.isfinite(values)]
    if v.size == 0:
        return np.array([-np.inf, np.inf])
    v_sorted = np.sort(v)
    uniq = np.unique(v_sorted)
    if uniq.size < 2:
        return np.array([-np.inf, np.inf])

    sd = float(np.std(v, ddof=1)) if v.size > 1 else 0.0
    h_scott = 3.49 * sd * (v.size ** (-1.0 / 3.0)) if sd > 0 else 0.0

    # h_min on the dense interior only (drops outlier-induced fat gaps).
    lo_pct = np.percentile(v, percentile_clip)
    hi_pct = np.percentile(v, 100.0 - percentile_clip)
    interior_mask = (uniq >= lo_pct) & (uniq <= hi_pct)
    if interior_mask.sum() >= 2:
        h_min = float(np.max(np.diff(uniq[interior_mask])))
    else:
        h_min = float(np.max(np.diff(uniq)))

    h = max(h_min, h_scott)
    if h <= 0:
        return np.array([-np.inf, np.inf])

    # Fine-binning grid covers [lo_pct, hi_pct]; outliers fall into the
    # two implicit ±inf bookends.
    edges = np.arange(lo_pct, hi_pct + h, h)
    if edges[-1] < hi_pct:
        edges = np.append(edges, hi_pct + 1e-12)
    return np.concatenate([[-np.inf], edges, [np.inf]])


def _merge_tail_bins(edges: np.ndarray, weights_per_bin: np.ndarray,
                     threshold: float = _M53_TAIL_THRESHOLD) -> np.ndarray:
    """Merge leftmost / rightmost bins until their share crosses ``threshold``.

    Methodology Приложение 4 §4.11: «если в крайние бины попадает <2.5 %
    наблюдений, ``τ`` крайних интервалов объединяются в один. При этом
    количество объединяемых интервалов τ определяется таким образом, чтобы
    доля наблюдений, попавших в объединённый интервал, была как можно
    ближе к 2.5 %, но не превышала эту величину».

    The returned grid keeps the merged-left tail (if any) as a single
    bin, then the untouched interior bins, then the merged-right tail
    (if any) as a single bin.
    """
    total = float(weights_per_bin.sum())
    if total <= 0 or len(edges) <= 2:
        return edges
    shares = weights_per_bin / total
    n = len(shares)

    # ``L`` — number of leftmost bins folded into a single tail bin.
    L = 0
    cum = 0.0
    while L < n - 1 and cum + shares[L] < threshold:
        cum += shares[L]
        L += 1
    # ``R`` — number of rightmost bins folded into a single tail bin.
    R = 0
    cum = 0.0
    while R < n - L - 1 and cum + shares[n - 1 - R] < threshold:
        cum += shares[n - 1 - R]
        R += 1

    # Construct the merged grid.
    keep: list[float] = [float(edges[0])]
    if L > 0:
        keep.append(float(edges[L]))                  # boundary: left-tail | first kept bin
    keep.extend(float(e) for e in edges[L + 1 : n - R])  # interior edges of kept range
    if R > 0:
        keep.append(float(edges[n - R]))              # boundary: last kept bin | right-tail
    keep.append(float(edges[-1]))

    # Deduplicate identical (within fp noise) edges and sort.
    unique = sorted(set(np.round(keep, 12)))
    if len(unique) < 2:
        return np.array([edges[0], edges[-1]])
    return np.array(unique, dtype=float)


def _weighted_counts(values: np.ndarray, weights: Optional[np.ndarray],
                     edges: np.ndarray) -> np.ndarray:
    """Sum of weights per bin defined by ``edges``. Returns array of length ``len(edges)-1``."""
    mask = np.isfinite(values)
    v = values[mask]
    w = (weights[mask] if weights is not None else np.ones_like(v))
    # ``np.digitize`` with ``right=False``: edges are left-inclusive; we
    # adjust the rightmost bin to include the max value.
    idx = np.digitize(v, edges, right=False) - 1
    idx = np.clip(idx, 0, len(edges) - 2)
    out = np.zeros(len(edges) - 1, dtype=float)
    np.add.at(out, idx, w)
    return out


def compute_methodology_score_psi(
    score_train: np.ndarray,
    score_test: np.ndarray,
    weight_train: Optional[np.ndarray] = None,
    weight_test: Optional[np.ndarray] = None,
) -> pd.DataFrame:
    """PSI table for score distribution per methodology §7.10 + §4.11.

    Steps:

    1. Bin edges from train scores via Scott's rule
       (:func:`_scott_bin_edges`).
    2. Compute train weighted shares; merge tail bins with <2.5 % share
       (:func:`_merge_tail_bins`).
    3. Re-count train and test on the merged grid.
    4. Drop buckets where the test share is 0 (methodology замечание):
       those rows must also drop from the train distribution, so we
       renormalise train shares on the surviving buckets.
    5. ``psi_i = (test_pct − train_pct) · ln(test_pct / train_pct)`` per
       bucket; sum is the total PSI.

    Returns a DataFrame with columns ``bin``, ``train_pct``,
    ``test_pct``, ``psi`` (per-bucket contribution). The total PSI is
    ``df['psi'].sum()``.
    """
    s_tr = np.asarray(score_train, dtype=float)
    s_te = np.asarray(score_test, dtype=float)
    w_tr = (np.asarray(weight_train, dtype=float)
            if weight_train is not None else np.ones_like(s_tr))
    w_te = (np.asarray(weight_test, dtype=float)
            if weight_test is not None else np.ones_like(s_te))

    raw_edges = _scott_bin_edges(s_tr)
    train_counts = _weighted_counts(s_tr, w_tr, raw_edges)
    merged_edges = _merge_tail_bins(raw_edges, train_counts)
    train_counts = _weighted_counts(s_tr, w_tr, merged_edges)
    test_counts  = _weighted_counts(s_te, w_te, merged_edges)

    # Drop buckets where the validation sample has zero share; per
    # methodology this also drops the matching train obs, which we
    # implement by ignoring those bins and renormalising train shares.
    keep_mask = test_counts > 0
    if not np.any(keep_mask):
        return pd.DataFrame(columns=["bin", "train_pct", "test_pct", "psi"])
    edges_kept_left  = merged_edges[:-1][keep_mask]
    edges_kept_right = merged_edges[1:][keep_mask]
    train_kept = train_counts[keep_mask]
    test_kept  = test_counts[keep_mask]

    tr_total = float(train_kept.sum())
    te_total = float(test_kept.sum())
    train_pct = train_kept / tr_total if tr_total > 0 else np.zeros_like(train_kept)
    test_pct  = test_kept  / te_total if te_total > 0 else np.zeros_like(test_kept)

    # PSI contribution per bucket. When train_pct is zero (rare — implies
    # validation sees a region the training never did) the methodology
    # leaves the bucket in but the log diverges; we substitute a small
    # floor so the sum remains finite and the bucket gets flagged via
    # its share difference.
    eps = 1e-12
    train_safe = np.where(train_pct > 0, train_pct, eps)
    test_safe  = np.where(test_pct  > 0, test_pct,  eps)
    psi_contrib = (test_pct - train_pct) * np.log(test_safe / train_safe)

    left_labels  = edges_kept_left
    right_labels = edges_kept_right

    def _fmt(l: float, r: float) -> str:
        def _one(x: float) -> str:
            if not np.isfinite(x):
                return "-inf" if x < 0 else "inf"
            scale = max(abs(x), 1e-12)
            decimals = max(0, int(np.ceil(-np.log10(scale))) + 3)
            decimals = min(decimals, 6)
            return f"{x:.{decimals}f}"
        return f"({_one(l)}, {_one(r)}]"

    return pd.DataFrame({
        "bin": [_fmt(l, r) for l, r in zip(left_labels, right_labels)],
        "train_pct": train_pct,
        "test_pct":  test_pct,
        "psi":       psi_contrib,
    })


def m53_psi_signal(total_psi: float) -> str:
    """Traffic light per Таблица 6.23."""
    if not np.isfinite(total_psi):
        return 'red'
    if total_psi >= _M53_PSI_RED:
        return 'red'
    if total_psi >= _M53_PSI_ORANGE:
        return 'orange'
    return 'green'


# Moved _split_frames_from_cfg, _cfg_col, _weight_from_config to core.data_utils



class M51_ModelGiniStabilityTest(BaseModelTest):
    def __init__(self):
        super().__init__("M 5.1", "Model Gini Stability")

    def run(self, df: pd.DataFrame = None, config: dict = None,
                  score_train: pd.Series = None, target_train: pd.Series = None,
                  score_test: pd.Series = None, target_test: pd.Series = None,
                  sample: str = None, **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = None
        w_tr = w_te = w_all = None
        score_all = target_all = None
        # Config-driven invocation
        if df is not None and config is not None and (score_train is None or target_train is None or score_test is None or target_test is None):
            try:
                cfg = ensure_config(config, df)
                if is_generic_classification_mode(cfg):
                    self.test_signal = "blue"
                    return _classification_mode_na(self.test_name)
                # Single source of truth — same column M2.1 ranks by.
                scol = get_score_col(cfg)
                tcol = get_col_name(cfg, 'target_column')
                wcol = getattr(cfg.columns, 'weight_column', None)
                if is_big_data_mode(cfg):
                    train_mask, test_mask = split_sample_masks(df, cfg)
                    needed_cols = [scol, tcol, wcol]
                    needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
                    df_small = df.loc[:, needed_cols]
                    df_tr = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=200_000, random_state=511).copy()
                    df_te = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=200_000, random_state=512).copy()
                    df_all = sample_frame_for_big_data(df_small, cfg, max_rows=300_000, random_state=513).copy()
                else:
                    df_tr, df_te, df_all = split_frames(df, cfg)
                score_train, target_train = df_tr[scol], df_tr[tcol]
                score_test, target_test = df_te[scol], df_te[tcol]
                score_all, target_all = df_all[scol], df_all[tcol]
                if wcol and wcol in df_tr.columns:
                    w_tr = df_tr[wcol]
                if wcol and wcol in df_te.columns:
                    w_te = df_te[wcol]
                w_all = df_all[wcol] if wcol and wcol in df_all.columns else None
            except Exception as e:
                return {"combined": f"<h4>Model Gini Stability</h4><p>Config error: {str(e)}</p>"}
        # Align and drop NaNs
        mask_tr = (~pd.Series(target_train).isna()) & (~pd.Series(score_train).isna())
        mask_te = (~pd.Series(target_test).isna()) & (~pd.Series(score_test).isna())
        y_tr = pd.Series(target_train)[mask_tr]
        s_tr = pd.Series(score_train)[mask_tr]
        y_te = pd.Series(target_test)[mask_te]
        s_te = pd.Series(score_test)[mask_te]
        w_tr_arr = pd.Series(w_tr)[mask_tr].to_numpy(dtype=float) if w_tr is not None else None
        w_te_arr = pd.Series(w_te)[mask_te].to_numpy(dtype=float) if w_te is not None else None

        # `score_all` / `target_all` / `w_all` are populated only on the
        # config-driven path. For the legacy manual-invocation path
        # (callers pass score_train/test directly) we fall back to
        # concatenating the train and test splits as a synthetic "all".
        if score_all is None or target_all is None:
            y_all = pd.concat([y_tr, y_te], ignore_index=True)
            s_all = pd.concat([s_tr, s_te], ignore_index=True)
            w_all_arr = (np.concatenate([w_tr_arr, w_te_arr])
                         if w_tr_arr is not None and w_te_arr is not None else None)
        else:
            mask_all = (~pd.Series(target_all).isna()) & (~pd.Series(score_all).isna())
            y_all = pd.Series(target_all)[mask_all]
            s_all = pd.Series(score_all)[mask_all]
            w_all_arr = pd.Series(w_all)[mask_all].to_numpy(dtype=float) if w_all is not None else None

        is_binary_tr = is_binary_mode(cfg) if cfg is not None else type_of_target(y_tr) == 'binary'
        is_binary_te = is_binary_mode(cfg) if cfg is not None else type_of_target(y_te) == 'binary'

        # --- Gini ---
        if is_binary_tr and is_binary_te:
            auc_train = roc_auc_score(y_tr, s_tr, sample_weight=w_tr_arr)
            auc_test  = roc_auc_score(y_te, s_te, sample_weight=w_te_arr)
            auc_all   = roc_auc_score(y_all, s_all, sample_weight=w_all_arr)
            gini_train = 2 * auc_train - 1
            gini_test  = 2 * auc_test - 1
            gini_all   = 2 * auc_all - 1
        else:
            gini_train = gini_normalized(y_tr.values,  s_tr.values,  sample_weight=w_tr_arr)
            gini_test  = gini_normalized(y_te.values,  s_te.values,  sample_weight=w_te_arr)
            gini_all   = gini_normalized(y_all.values, s_all.values, sample_weight=w_all_arr)

        # --- PowerStat (общий weighted-aware helper) ---
        from .m2._shared import powerstat_value
        w_tr_for_ps  = pd.Series(w_tr_arr)  if w_tr_arr  is not None else None
        w_te_for_ps  = pd.Series(w_te_arr)  if w_te_arr  is not None else None
        w_all_for_ps = pd.Series(w_all_arr) if w_all_arr is not None else None
        ps_train = float(powerstat_value(y_tr,  s_tr,  weight=w_tr_for_ps))
        ps_test  = float(powerstat_value(y_te,  s_te,  weight=w_te_for_ps))
        ps_all   = float(powerstat_value(y_all, s_all, weight=w_all_for_ps))

        def _row(label: str, al: float, tr: float, te: float) -> tuple:
            delta = tr - te          # signed: +ve means test fell, -ve means test improved
            abs_drop = abs(delta)    # absolute magnitude of change
            rel_drop = abs_drop / abs(tr) if abs(tr) > 1e-12 else 0.0
            return (label, al, tr, te, delta, abs_drop, rel_drop)

        rows = [
            _row("Gini",      gini_all, gini_train, gini_test),
            _row("PowerStat", ps_all,   ps_train,   ps_test),
        ]

        # Сигнал — по тому из двух, у кого хуже стабильность (max relative drop).
        # Стабильность измеряется именно по разрыву Train→Test (что и есть «уход» модели).
        gd = cfg.thresholds.gini_drop if cfg is not None else None
        red_abs = gd.red_absolute_pp if gd else 0.10
        red_rel = gd.red_relative if gd else 0.20
        yel_abs = gd.orange_absolute_pp if gd else 0.05
        yel_rel = gd.orange_relative if gd else 0.15
        worst_abs = max(r[5] for r in rows)   # abs_drop index shifted by +1 after adding All
        worst_rel = max(r[6] for r in rows)
        if worst_abs >= red_abs and worst_rel >= red_rel:
            signal = "red"
        elif worst_abs >= yel_abs and worst_rel >= yel_rel:
            signal = "orange"
        else:
            signal = "green"
        self.test_signal = signal

        body = "".join(
            f"<tr><td><b>{label}</b></td>"
            f"<td>{al:.4f}</td><td>{tr:.4f}</td><td>{te:.4f}</td>"
            f"<td>{delta:+.4f}</td><td>{abs_drop:.4f}</td><td>{rel_drop:.2%}</td></tr>"
            for (label, al, tr, te, delta, abs_drop, rel_drop) in rows
        )

        html = f"""
        <h4>Model Stability</h4>
        <p><b>Signal:</b> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span>
        &nbsp;&nbsp;<i>(based on Train→Test drop)</i></p>
        <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse">
            <thead>
                <tr>
                    <th>Metric</th><th>All</th><th>Train</th><th>Test</th>
                    <th>Δ (Train − Test)</th><th>Absolute drop</th><th>Relative drop</th>
                </tr>
            </thead>
            <tbody>{body}</tbody>
        </table>
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


class M52_FactorGiniStabilityTest(BaseModelTest):
    def __init__(self):
        super().__init__("M 5.2", "Factor PowerStat Stability")

    def compute_gini(self, feature: pd.Series, target: pd.Series, weight: Optional[pd.Series] = None) -> float:
        # Pairwise drop NaNs
        mask = (~pd.Series(feature).isna()) & (~pd.Series(target).isna())
        if weight is not None:
            mask = mask & (~pd.Series(weight).isna())
        x = pd.Series(feature)[mask]
        y = pd.Series(target)[mask]
        w_arr = pd.Series(weight)[mask].to_numpy(dtype=float) if weight is not None else None
        # Decide metric based on target type
        if type_of_target(y) == 'binary':
            try:
                auc = roc_auc_score(y, x, sample_weight=w_arr)
                return 2 * auc - 1
            except Exception:
                return 0.0
        else:
            try:
                return float(gini_normalized(y.values, x.values, sample_weight=w_arr))
            except Exception:
                return 0.0

    def run(self, df: pd.DataFrame = None, config: dict = None,
                  df_train: pd.DataFrame = None, df_test: pd.DataFrame = None,
                  target_column: str = None, features: List[str] = None,
                  **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = None
        weight_column = None
        cat_features = []
        df_all = None
        # Config-driven invocation
        if df is not None and config is not None and (df_train is None or df_test is None or target_column is None or features is None):
            try:
                cfg = ensure_config(config, df)
                if is_generic_classification_mode(cfg):
                    self.test_signal = "blue"
                    return _classification_mode_na(self.test_name)
                # Methodology M 5.2 covers *all* model factors. Include categoricals,
                # encode them with target mean (matching M 2.2 / M 3.x conventions).
                feats = get_features(df, cfg, include_categorical=True)
                target_column = get_col_name(cfg, 'target_column')
                features = list(feats)
                weight_column = getattr(cfg.columns, 'weight_column', None)
                cat_features = list(getattr(cfg.columns, 'categorical_features', []) or [])
                # GLM-пресет: per-factor стабильность считаем по multiplicative _SCORING.
                # Категориальные после scoring — числовые, target-encoding не нужен.
                if is_glm_preset(cfg):
                    features = resolve_feature_columns(
                        df, features, kind="scoring", cfg=cfg, test_code=self.test_code,
                    )
                    cat_features = []
                if is_big_data_mode(cfg):
                    train_mask, test_mask = split_sample_masks(df, cfg)
                    needed_cols = features + [target_column, weight_column]
                    needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
                    df_small = df.loc[:, needed_cols]
                    df_train = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=200_000, random_state=521).copy()
                    df_test = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=200_000, random_state=522).copy()
                    df_all = sample_frame_for_big_data(df_small, cfg, max_rows=300_000, random_state=523).copy()
                else:
                    df_tr, df_te, df_full = split_frames(df, cfg)
                    df_train, df_test, df_all = df_tr, df_te, df_full
            except Exception as e:
                return {"combined": f"<h4>Factor PowerStat Stability</h4><p>Config error: {str(e)}</p>"}

        # Weighted PowerStat helper (uses shared methodology-aligned implementation)
        from .m2._shared import powerstat_value as _powerstat_value

        # Fall back to concatenated train+test when called via the legacy
        # manual-invocation path (no `df_all` provided).
        if df_all is None:
            df_all = pd.concat([df_train, df_test], ignore_index=False)

        w_tr  = df_train[weight_column] if weight_column and weight_column in df_train.columns else None
        w_te  = df_test[weight_column]  if weight_column and weight_column in df_test.columns  else None
        w_all = df_all[weight_column]   if weight_column and weight_column in df_all.columns   else None

        # Mean-target encoding for categorical features (computed on train, applied to both splits).
        cat_set = set(cat_features)
        global_mean = float(pd.to_numeric(df_train[target_column], errors='coerce').mean()) if target_column in df_train.columns else 0.0
        cat_encoding = {}
        for f in features:
            if f in cat_set:
                series = df_train[[f, target_column]].copy()
                series[target_column] = pd.to_numeric(series[target_column], errors='coerce')
                mapping = series.groupby(f)[target_column].mean().to_dict()
                cat_encoding[f] = mapping

        def _encoded(frame: pd.DataFrame, f: str) -> pd.Series:
            if f in cat_set:
                mp = cat_encoding.get(f, {})
                return frame[f].map(mp).fillna(global_mean)
            return frame[f]

        # Per-factor PowerStat (weighted by exposure; categoricals target-encoded above).
        # ``All`` uses the same train-fitted encoding so the three numbers
        # share the same numeric representation per factor.
        def _process_feature(f):
            x_tr  = _encoded(df_train, f)
            x_te  = _encoded(df_test,  f)
            x_all = _encoded(df_all,   f)
            ps_tr  = float(_powerstat_value(df_train[target_column], x_tr,  weight=w_tr))
            ps_te  = float(_powerstat_value(df_test[target_column],  x_te,  weight=w_te))
            ps_all = float(_powerstat_value(df_all[target_column],   x_all, weight=w_all))
            return f, ps_all, ps_tr, ps_te

        results = Parallel(n_jobs=-1, backend="threading")(
            delayed(_process_feature)(f)
            for f in tqdm(features, desc="M 5.2 - Processing Features")
        )

        # Per-factor flag rules (methodology M 5.2 = same thresholds as M 5.1):
        # RED if abs decrease ≥ red_abs_pp AND rel decrease ≥ red_rel;
        # ORANGE if abs decrease ≥ yel_abs_pp AND rel decrease ≥ yel_rel;
        # GREEN otherwise. Decrease counts only when test < train.
        try:
            gd = cfg.thresholds.gini_drop
            red_abs, red_rel = gd.red_absolute_pp, gd.red_relative
            yel_abs, yel_rel = gd.orange_absolute_pp, gd.orange_relative
        except Exception:
            red_abs, red_rel, yel_abs, yel_rel = 0.10, 0.20, 0.05, 0.15

        def factor_flag(tr: float, te: float) -> str:
            decrease = max(0.0, tr - te)
            rel_decrease = decrease / abs(tr) if abs(tr) > 1e-12 else 0.0
            if decrease >= red_abs and rel_decrease >= red_rel:
                return 'red'
            if decrease >= yel_abs and rel_decrease >= yel_rel:
                return 'orange'
            return 'green'

        rows = []
        for f, ps_all, ps_tr, ps_te in results:
            delta = ps_tr - ps_te  # signed
            abs_drop = abs(delta)
            rel_drop = abs_drop / abs(ps_tr) if abs(ps_tr) > 1e-12 else 0.0
            rows.append({
                'Feature': f,
                'PowerStat All':   ps_all,
                'PowerStat Train': ps_tr,
                'PowerStat Test':  ps_te,
                'Δ (Train − Test)': delta,
                'Absolute drop': abs_drop,
                'Relative drop': rel_drop,
                'Flag': factor_flag(ps_tr, ps_te),
            })
        df_factors = pd.DataFrame(rows).sort_values('PowerStat All', ascending=False)

        # Methodology M5.2 overall signal (out-of-sample case): red if ≥1 red factor;
        # orange if >10% orange factors; green otherwise.
        n_total = max(1, len(df_factors))
        n_red = int((df_factors['Flag'] == 'red').sum())
        n_orange = int((df_factors['Flag'] == 'orange').sum())
        if n_red > 0:
            signal = 'red'
        elif n_orange / n_total > 0.10:
            signal = 'orange'
        else:
            signal = 'green'
        self.test_signal = signal

        # Chart: per-factor PowerStat All / Train / Test (methodology Рис. 6.16).
        try:
            df_chart = df_factors.sort_values('PowerStat All', ascending=False)
            fig_w = max(8.0, min(2.5 + 0.65 * len(df_chart), 28.0))
            fig, ax = figure(size=(fig_w, 5.6))
            x = np.arange(len(df_chart))
            width = 0.28
            ax.bar(x - width, df_chart["PowerStat All"],   width=width, color=COLORS['GRAY_DARK'], alpha=0.85, label='All')
            ax.bar(x,         df_chart["PowerStat Train"], width=width, color=COLORS['BLUE'],     alpha=0.85, label='Train')
            ax.bar(x + width, df_chart["PowerStat Test"],  width=width, color=COLORS['EMERALD'],  alpha=0.85, label='Test')
            short_labels = [(f[:22] + "...") if len(f) > 25 else f for f in df_chart["Feature"]]
            ax.set_xticks(x)
            ax.set_xticklabels(short_labels, rotation=45, ha='right', fontsize=8)
            y_max = float(df_chart[["PowerStat All", "PowerStat Train", "PowerStat Test"]].max().max()) * 1.1
            y_min = min(0.0, float(df_chart[["PowerStat All", "PowerStat Train", "PowerStat Test"]].min().min()) * 1.1)
            ax.set_ylim(y_min, max(1.0, y_max))
            ax.axhline(0, color=COLORS['GRAY'], linewidth=0.8)
            apply_standard_axis_style(
                ax, title='PowerStat by Factor — All / Train / Test',
                ylabel='PowerStat', legend_loc=None, title_size=12,
            )
            ax.grid(True, axis='y', linestyle='--', alpha=0.3)
            ax.legend(loc='upper right', fontsize=8, frameon=False)
            fig.tight_layout(pad=1.3)
            ps_img_b64 = figure_to_base64(fig)
            plt.close(fig)
            chart_html = (
                f'<img src="data:image/png;base64,{ps_img_b64}" '
                f'style="display:block; width:100%; max-width:1100px; height:auto;">'
            )
        except Exception:
            chart_html = "<p>Failed to render PowerStat chart.</p>"

        # Table with red-row highlighting (helper from _visual_utils).
        from ._visual_utils import render_flag_table
        display_df = df_factors.copy()
        # Format Relative drop as percentage for the rendered cell.
        display_df['Relative drop'] = display_df['Relative drop'].apply(lambda v: f"{v:.2%}")

        html = f"""
        <h4>Factor PowerStat Stability</h4>
        <p><b>Signal:</b> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span>
        &nbsp;&nbsp;<i>(based on Train→Test drop; All shown for direct comparison with M2.2)</i></p>
        <p><i>Factors: {n_total} · Red: {n_red} · Orange: {n_orange} · Green: {n_total - n_red - n_orange}</i></p>
        {chart_html}
        <br>
        {render_flag_table(display_df, flag_col='Flag', float_format='%.4f')}
        """
        _log_text = {'red':'red','orange':'orange','green':'green','orange':'orange','blue':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


class M53_ScorePSITest(BaseModelTest):
    """Test M 5.3 — Score-distribution PSI between train and validation.

    Implements the methodology spec end-to-end (§7.10 + Приложение 4
    §4.11):

    * Scott's-rule binning on train scores
      (:func:`_scott_bin_edges`).
    * Tail merging when the leftmost / rightmost bins each hold <2.5 %
      of the train sample (:func:`_merge_tail_bins`).
    * Drop validation buckets with zero share; those train rows are
      excluded and train shares re-normalised on the surviving bins.
    * Traffic light per Таблица 6.23: ``PSI ≥ 0.20`` red,
      ``0.10 ≤ PSI < 0.20`` orange (called «жёлтый» in the doc),
      otherwise green.

    ``psi_calc`` is accepted for backwards compatibility with the
    constructor signature but no longer used inside the test — the
    methodology binning differs from the generic ``PSICalculator``
    quantile path, so we compute PSI ourselves.
    """

    def __init__(self, psi_calc: Optional["PSICalculatorExtended"] = None):
        super().__init__("M 5.3", "Score PSI Stability")
        self.psi_calc = psi_calc  # kept for ctor compatibility; unused

    def _plot_distribution(self, table: pd.DataFrame, x_label: str = "Predicted") -> str:
        if table.empty:
            return ""
        try:
            fig, ax = figure(size="wide")
            x = np.arange(len(table))
            width = 0.4
            # Green palette matching the reference: TRAIN light green, VAL darker green.
            light_green = COLORS['GREEN_LIGHT']
            dark_green  = COLORS['GREEN']
            train_pct_pct = (table["train_pct"] * 100.0).to_numpy()
            test_pct_pct  = (table["test_pct"]  * 100.0).to_numpy()
            ax.bar(x - width/2, train_pct_pct, width=width, color=light_green, label='TRAIN')
            ax.bar(x + width/2, test_pct_pct,  width=width, color=dark_green,  label='VAL')
            ax.set_xticks(x)
            ax.set_xticklabels(table["bin"].tolist(), rotation=45, ha='right', fontsize=7)
            ax.set_xlabel(x_label)
            ax.set_ylabel('Observation share, %')
            ax.grid(True, axis='y', linestyle='--', alpha=0.3)
            ax.legend(loc='upper center', ncol=2, frameon=False)
            fig.tight_layout(pad=1.0)
            img_b64 = figure_to_base64(fig)
            plt.close(fig)
            return f'<img src="data:image/png;base64,{img_b64}" style="display:block; width:100%; max-width:1100px; height:auto;">'
        except Exception:
            return "<p>Failed to render score-distribution chart.</p>"

    def run(self, df: pd.DataFrame = None, config: dict = None,
                  train_df: pd.DataFrame = None, oot_df: pd.DataFrame = None,
                  score_column: str = None, target_column: str = None,
                  **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = None
        w_train = w_oot = None
        # Config-driven invocation
        if df is not None and config is not None and (train_df is None or oot_df is None or score_column is None):
            try:
                cfg = ensure_config(config, df)
                if is_generic_classification_mode(cfg):
                    self.test_signal = "blue"
                    return _classification_mode_na(self.test_name)
                score_column = get_score_col(cfg)
                target_column = get_col_name(cfg, 'target_column')
                weight_column = getattr(cfg.columns, 'weight_column', None)
                if is_big_data_mode(cfg):
                    train_mask, test_mask = split_sample_masks(df, cfg)
                    needed_cols = [score_column, target_column, weight_column]
                    needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
                    df_small = df.loc[:, needed_cols]
                    train_df = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=200_000, random_state=531).copy()
                    oot_df = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=200_000, random_state=532).copy()
                else:
                    df_tr, df_te, _ = split_frames(df, cfg)
                    train_df, oot_df = df_tr, df_te
                w_train = get_weight_col(train_df, cfg)
                w_oot = get_weight_col(oot_df, cfg)
            except Exception as e:
                return {"score": f"<h4>Score PSI Stability</h4><p>Config error: {str(e)}</p>"}

        if score_column is None or score_column not in train_df.columns or score_column not in oot_df.columns:
            self.test_signal = 'red'
            return {"score": "<h4>Score PSI Stability</h4><p>score_column is missing.</p>"}

        s_train = pd.to_numeric(train_df[score_column], errors='coerce').to_numpy(dtype=float)
        s_test  = pd.to_numeric(oot_df[score_column], errors='coerce').to_numpy(dtype=float)
        w_train_arr = (pd.to_numeric(w_train, errors='coerce').to_numpy(dtype=float)
                       if w_train is not None else None)
        w_test_arr  = (pd.to_numeric(w_oot, errors='coerce').to_numpy(dtype=float)
                       if w_oot is not None else None)

        # Methodology bins the *predicted output* distribution. For Poisson
        # frequency the predicted output is the count = rate × exposure,
        # which is what the reference upstream tool plots (PREDICT_FREQ on
        # the x-axis). Without exposure (binary / severity) the score
        # itself is the predicted output.
        if w_train_arr is not None and w_test_arr is not None:
            pred_train = s_train * w_train_arr
            pred_test  = s_test  * w_test_arr
            x_label = f"{score_column} × {getattr(cfg.columns, 'weight_column', 'weight') if cfg else 'weight'}"
        else:
            pred_train = s_train
            pred_test  = s_test
            x_label = score_column

        table = compute_methodology_score_psi(
            pred_train, pred_test,
            weight_train=w_train_arr, weight_test=w_test_arr,
        )

        if table.empty:
            total_psi = float('nan')
            signal = 'red'
            self.test_signal = signal
            html = (
                "<h4>Score PSI Stability</h4>"
                "<p>Не удалось построить распределение score: либо валидационная "
                "выборка не пересекается с train по бакетам, либо данных слишком мало.</p>"
            )
            return {"score": html, "DASHBOARD": html}

        total_psi = float(table['psi'].sum())
        signal = m53_psi_signal(total_psi)
        self.test_signal = signal

        chart_html = self._plot_distribution(table, x_label=x_label)
        display = table.copy()
        display['train_pct'] = display['train_pct'].map(lambda v: f"{v:.4f}")
        display['test_pct']  = display['test_pct'].map(lambda v: f"{v:.4f}")
        display['psi']       = display['psi'].map(lambda v: f"{v:+.4f}")

        signal_label = signal.upper()
        signal_color = signal
        html = f"""
        <h4>Score PSI Stability</h4>
        <p><b>Signal:</b> <span style='color:{signal_color}; font-weight:bold'>{signal_label}</span>
        &nbsp;&nbsp;<i>(методология §7.10, биннинг по Скотту + drop-zero)</i></p>
        <p><b>Total PSI:</b> {total_psi:.4f}
        &nbsp;|&nbsp; thresholds: <span style='color:orange'>≥ {_M53_PSI_ORANGE:.2f} ORANGE</span>,
        <span style='color:red'>≥ {_M53_PSI_RED:.2f} RED</span></p>
        <p><i>Bins after tail-merge / drop-zero: {len(table)}.</i></p>
        {chart_html}
        <br>
        <h5>Per-bucket PSI</h5>
        {display.to_html(index=False)}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"score": html, "DASHBOARD": html}


class M54_FactorPSITest(BaseModelTest):
    def __init__(self, psi_calc: PSICalculatorExtended):
        super().__init__("M 5.4", "Factors PSI Stability")
        self.psi_calc = psi_calc

    def run(self, df: pd.DataFrame = None, config: dict = None,
                  train_df: pd.DataFrame = None, oot_df: pd.DataFrame = None,
                  target_column: str = None, features: List[str] = None,
                  categorical_features: List[str] = None, **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # Config-driven invocation
        if df is not None and config is not None and (train_df is None or oot_df is None or target_column is None or features is None):
            try:
                cfg = ensure_config(config, df)
                target_column = get_col_name(cfg, 'target_column')
                features = list(getattr(cfg.columns, 'numeric_features', []) or [])
                categorical_features = list(getattr(cfg.columns, 'categorical_features', []) or [])
                # GLM-пресет: PSI по фактору считаем на multiplicative _SCORING-колонках;
                # категориальные после scoring уже числовые.
                if is_glm_preset(cfg):
                    features = resolve_feature_columns(
                        df, features + categorical_features,
                        kind="scoring", cfg=cfg, test_code=self.test_code,
                    )
                    categorical_features = []
                weight_column = getattr(cfg.columns, 'weight_column', None)
                if is_big_data_mode(cfg):
                    train_mask, test_mask = split_sample_masks(df, cfg)
                    needed_cols = features + [target_column, weight_column]
                    needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
                    df_small = df.loc[:, needed_cols]
                    train_df = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=200_000, random_state=541).copy()
                    oot_df = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=200_000, random_state=542).copy()
                else:
                    df_tr, df_te, _ = split_frames(df, cfg)
                    train_df, oot_df = df_tr, df_te
                w_train = get_weight_col(train_df, cfg)
                w_oot = get_weight_col(oot_df, cfg)
            except Exception as e:
                return {"combined": f"<h4>Factors PSI Stability</h4><p>Config error: {str(e)}</p>"}
        else:
            w_train = w_oot = None
        psi_results = {}
        all_psi_tables = {}
        cats = categorical_features or []

        for feature in tqdm(features, desc="M 5.4 - Processing Features"):
            result = self.psi_calc.calculate(
                expected=train_df[feature],
                actual=oot_df[feature],
                target_expected=train_df[target_column],
                target_actual=oot_df[target_column],
                is_categorical=feature in cats,
                weight_expected=w_train,
                weight_actual=w_oot,
            )
            psi_results[feature] = self.psi_calc.generate_html_block(result, feature)
            all_psi_tables[feature] = result

        # Group signal per new rules:
        # Red — if any "red" factor; Orange — if >10% "orange" factors; Green — otherwise.
        # Per-feature color uses cfg.thresholds.psi cutoffs (defaults: 0.10 / 0.20).
        psi_thr = cfg.thresholds.psi if cfg is not None else None
        red_cut = psi_thr.red if psi_thr else 0.2
        yel_cut = psi_thr.orange if psi_thr else 0.1

        def feature_color(total_psi: float) -> str:
            if total_psi >= red_cut:
                return 'red'
            elif total_psi >= yel_cut:
                return 'orange'
            else:
                return 'green'

        colors = []
        for feat, res in all_psi_tables.items():
            try:
                total_psi = float(res['all']['psi'].sum())
            except Exception:
                total_psi = float('inf')
            colors.append(feature_color(total_psi))
        total = max(1, len(colors))
        red_any = any(c == 'red' for c in colors)
        orange_share = sum(1 for c in colors if c == 'orange') / total
        if red_any:
            self.test_signal = 'red'
        elif orange_share > 0.10:
            self.test_signal = 'orange'
        else:
            self.test_signal = 'green'

        dashboard_html = self.psi_calc.generate_dashboard_table(all_psi_tables)
        psi_results["DASHBOARD"] = dashboard_html
        _log_text = {'red':'red','orange':'orange','green':'green','orange':'orange','blue':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return psi_results
