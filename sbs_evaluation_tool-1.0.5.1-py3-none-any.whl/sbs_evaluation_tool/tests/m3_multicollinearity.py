# core import
from ..core.base_test import BaseModelTest
from ..core.styles import COLORS, STATUS_COLORS, figure
from ..core.data_utils import ensure_config,  split_frames, split_sample_masks, get_features, get_model_mode, is_big_data_mode, is_generic_classification_mode, is_glm_preset, resolve_feature_columns, get_validation_label, sample_frame_for_big_data
# default imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from io import BytesIO
import base64
# stat imports
from tqdm import tqdm
from statsmodels.stats.outliers_influence import variance_inflation_factor
import statsmodels.api as sm
from typing import Optional, List, Dict
import itertools
import concurrent.futures
from joblib import Parallel, delayed
from scipy.stats import chi2, contingency
from matplotlib.patches import Patch
from ._visual_utils import apply_standard_axis_style, figure_to_base64, render_flag_table, worst_flag
import logging
logger = logging.getLogger(__name__)


def _aggregate_lr_test_signal(red_share: float, yel_share: float) -> str:
    """Aggregate per-factor LR-test results into a final traffic-light signal.

    Red: at least 10% of factors are red.
    Orange: some red factors below 10%, or at least 10% of factors are orange.
    Green: no red factors and fewer than 10% orange factors.
    """
    if red_share >= 0.10:
        return 'red'
    if (0.0 < red_share < 0.10) or (yel_share >= 0.10):
        return 'orange'
    return 'green'


def _aggregate_lr_distribution_signals(signals: list[str]) -> str:
    """Aggregate family-level LR signals into one final test signal."""
    considered = [signal for signal in signals if signal in {"green", "orange", "red"}]
    if not considered:
        return "blue"
    if any(signal == "orange" for signal in considered):
        return "orange"
    if any(signal == "green" for signal in considered):
        return "green"
    return "red"


def _classification_mode_na(test_name: str) -> Dict[str, str]:
    return {
        "combined": (
            f"<h4>{test_name}</h4>"
            "<p><b>Skipped:</b> generic <code>classification</code> mode is not yet mapped "
            "to the GLM multicollinearity methodology.</p>"
        )
    }


# NEW
from ..core.config_validation import validate_config as _validate_config, ConfigValidationError
from ..core.data_utils import ensure_config

# === helpers for M3 ===
# _frames_from_cfg, _numeric_features_from_cfg, _categorical_features_from_cfg removed
# Use split_frames from core.data_utils and getattr(model_config.columns, ...) instead

def _vif_numpy(X_values: np.ndarray, i: int) -> float:
    """Быстрый расчёт VIF через numpy lstsq (без вызова statsmodels OLS на каждый признак)."""
    y = X_values[:, i]
    X_rest = np.delete(X_values, i, axis=1)
    try:
        coeffs, _, _, _ = np.linalg.lstsq(X_rest, y, rcond=None)
        y_hat = X_rest @ coeffs
        ss_res = float(np.sum((y - y_hat) ** 2))
        ss_tot = float(np.sum((y - y.mean()) ** 2))
        if ss_tot <= 0:
            return 1.0
        r2 = 1.0 - ss_res / ss_tot
        return 1.0 / (1.0 - r2) if r2 < 1.0 else np.inf
    except Exception:
        return np.inf


def cramers_v(x: pd.Series, y: pd.Series) -> float:
    """
    Вычисляет коэффициент Крамера V для двух категориальных переменных.
    
    Параметры:
        x, y: категориальные Series
    
    Возвращает:
        float: значение Cramer's V (0..1)
    """
    confusion_matrix = pd.crosstab(x, y)
    chi2_stat = contingency.chi2_contingency(confusion_matrix)[0]
    n = confusion_matrix.sum().sum()
    min_dim = min(confusion_matrix.shape[0], confusion_matrix.shape[1]) - 1
    if min_dim == 0 or n == 0:
        return 0.0
    return np.sqrt(chi2_stat / (n * min_dim))

def correlation_ratio(categories: pd.Series, values: pd.Series) -> float:
    """
    Вычисляет correlation ratio (eta) между категориальной и численной переменной.
    
    Параметры:
        categories: категориальная переменная
        values: численная переменная
    
    Возвращает:
        float: correlation ratio (0..1)
    """
    categories = pd.Categorical(categories)
    values = pd.to_numeric(values, errors='coerce')
    
    # Удаляем NaN
    valid_mask = ~values.isna()
    categories = categories[valid_mask]
    values = values[valid_mask]
    
    if len(values) < 2:
        return 0.0
    
    # Общая вариация
    overall_mean = values.mean()
    ss_total = ((values - overall_mean) ** 2).sum()
    
    if ss_total == 0:
        return 0.0
    
    # Вариация между группами
    ss_between = 0.0
    for cat in categories.categories:
        cat_values = values[categories == cat]
        if len(cat_values) > 0:
            cat_mean = cat_values.mean()
            ss_between += len(cat_values) * ((cat_mean - overall_mean) ** 2)
    
    eta_squared = ss_between / ss_total
    return np.sqrt(max(0.0, min(1.0, eta_squared)))

def target_encode_categorical(
    df_train: pd.DataFrame,
    df_test: pd.DataFrame,
    cat_features: list,
    target_col: str,
    smoothing: float = 10.0
) -> tuple:
    """
    Применяет target encoding с smoothing к категориальным признакам.
    
    Параметры:
        df_train: обучающая выборка
        df_test: тестовая выборка
        cat_features: список категориальных признаков
        target_col: название целевой переменной
        smoothing: сила регуляризации (m в формуле smoothing)
    
    Возвращает:
        tuple: (df_train_encoded, df_test_encoded, feature_map)
               feature_map: dict {encoded_name: original_name}
    """
    if not cat_features:
        return df_train.copy(), df_test.copy(), {}
    
    df_train_enc = df_train.copy()
    df_test_enc = df_test.copy()
    feature_map = {}
    
    # Глобальное среднее таргета
    global_mean = df_train[target_col].mean()
    
    for cat_feat in cat_features:
        # Вычисляем статистику по каждой категории
        stats = df_train.groupby(cat_feat)[target_col].agg(['mean', 'count'])
        
        # Применяем smoothing: (count * mean + m * global) / (count + m)
        stats['smoothed_mean'] = (
            (stats['count'] * stats['mean'] + smoothing * global_mean) / 
            (stats['count'] + smoothing)
        )
        
        # Создаем маппинг
        encoding_map = stats['smoothed_mean'].to_dict()
        
        # Применяем к train и test
        encoded_name = f"{cat_feat}_encoded"
        df_train_enc[encoded_name] = df_train_enc[cat_feat].map(encoding_map).fillna(global_mean)
        df_test_enc[encoded_name] = df_test_enc[cat_feat].map(encoding_map).fillna(global_mean)
        
        # Удаляем исходную категориальную колонку
        df_train_enc = df_train_enc.drop(columns=[cat_feat])
        df_test_enc = df_test_enc.drop(columns=[cat_feat])
        
        feature_map[encoded_name] = cat_feat
    
    return df_train_enc, df_test_enc, feature_map


def _corr_heatmap_buf(corr_df: pd.DataFrame) -> str:
    """Return base64 PNG of a correlation heatmap for given correlation DataFrame."""
    fig, ax = figure(size=(max(6, len(corr_df) * 0.4), max(4, len(corr_df) * 0.4)))
    im = ax.imshow(corr_df.values, cmap='RdBu_r', vmin=-1, vmax=1)
    ax.set_xticks(np.arange(len(corr_df.columns)))
    ax.set_yticks(np.arange(len(corr_df.index)))
    ax.set_xticklabels(corr_df.columns, rotation=45, ha='right')
    ax.set_yticklabels(corr_df.index)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    plt.tight_layout()
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


class M31_LikelihoodRatioTest(BaseModelTest):
    """Likelihood-ratio test by factor under multiple GLM families."""

    def __init__(self, features: Optional[list] = None, smoothing: float = 10.0, gamma_dispersion: float = 0.72):
        super().__init__('M 3.1', 'Likelihood-ratio tests (per factor)')
        self.features = features
        self.smoothing = smoothing
        self.gamma_dispersion = gamma_dispersion

    def _collect_feature_list(self, cfg):
        if self.features:
            return list(dict.fromkeys([f for f in self.features if f]))
        feats = []
        if getattr(cfg.columns, 'numeric_features', None):
            feats.extend(list(cfg.columns.numeric_features))
        if getattr(cfg.columns, 'categorical_features', None):
            feats.extend(list(cfg.columns.categorical_features))
        return list(dict.fromkeys([f for f in feats if f]))

    @staticmethod
    def _p_to_flag(p_value: float) -> str:
        if p_value is None or not np.isfinite(p_value):
            return 'gray'
        if p_value > 0.10:
            return 'red'
        if p_value > 0.05:
            return 'orange'
        return 'green'

    def _family_specs(self, model_mode: str):
        family_map = {
            'binary': [
                {
                    'key': 'binomial',
                    'label': 'Binomial',
                    'family': sm.families.Binomial(),
                    'description': 'Binomial GLM for binary target models.',
                }
            ],
            'frequency': [
                {
                    'key': 'poisson',
                    'label': 'Poisson',
                    'family': sm.families.Poisson(),
                    'description': 'Poisson GLM for count-frequency targets.',
                }
            ],
            'severity': [
                {
                    'key': 'gamma',
                    'label': 'Gamma',
                    'family': sm.families.Gamma(link=sm.families.links.Log()),
                    'description': 'Gamma GLM with log link for positive severity targets.',
                }
            ],
        }
        return family_map.get(model_mode, [
            {
                'key': 'gaussian',
                'label': 'Gaussian',
                'family': sm.families.Gaussian(),
                'description': 'Gaussian GLM with identity link.',
            },
            {
                'key': 'poisson',
                'label': 'Poisson',
                'family': sm.families.Poisson(),
                'description': 'Poisson GLM for non-negative targets.',
            },
            {
                'key': 'gamma',
                'label': 'Gamma',
                'family': sm.families.Gamma(link=sm.families.links.Log()),
                'description': 'Gamma GLM with log link for strictly positive targets.',
            },
        ])

    def _valid_mask_for_family(self, y: pd.Series, family_key: str) -> pd.Series:
        y_num = pd.to_numeric(y, errors='coerce')
        if family_key == 'binomial':
            return y_num.notna() & np.isfinite(y_num) & y_num.isin([0, 1])
        if family_key == 'poisson':
            return y_num.notna() & np.isfinite(y_num) & (y_num >= 0)
        if family_key == 'gamma':
            return y_num.notna() & np.isfinite(y_num) & (y_num > 0)
        return y_num.notna() & np.isfinite(y_num)

    def _build_histogram_html(self, res_df: pd.DataFrame, family_label: str, split_name: str) -> str:
        p_col = f"p_{split_name}"
        flag_col = f"flag_{split_name}"
        split_label = split_name.capitalize()
        plot_df = res_df.copy()
        plot_df[flag_col] = plot_df[p_col].apply(self._p_to_flag)
        plot_df = plot_df[plot_df[flag_col].isin(['orange', 'red'])]
        if plot_df.empty:
            return f'<p>No orange or red factor-level results are available for {split_label}.</p>'

        top_n = min(50, len(plot_df))
        plot_df = plot_df.head(top_n)
        sample_p = plot_df[p_col].fillna(1.0).clip(0, 1)

        color_map = {
            'green': STATUS_COLORS['green'],
            'orange': STATUS_COLORS['orange'],
            'red': STATUS_COLORS['red'],
            'gray': STATUS_COLORS['gray'],
        }
        fig_w = max(8.0, min(4.0 + 0.55 * len(plot_df), 28.0))
        fig, ax = figure(size=(fig_w, 5.4))
        x = np.arange(len(plot_df))
        ax.bar(x, sample_p, width=0.62, label=f'{split_label} (p)', color=[color_map.get(flag, STATUS_COLORS['gray']) for flag in plot_df[flag_col]])
        ax.axhline(0.10, color=STATUS_COLORS['orange'], linestyle='--', linewidth=1.2, label='Orange threshold = 0.10')
        ax.axhline(0.05, color=STATUS_COLORS['green'], linestyle='--', linewidth=1.2, label='Green threshold = 0.05')
        ax.set_xticks(x)
        ax.set_xticklabels(plot_df['feature'], rotation=55, ha='right')
        ax.set_ylim(0, 1)
        apply_standard_axis_style(
            ax,
            title=f'{family_label}: LR test by factor - {split_label} (orange/red only)',
            ylabel='p-value',
            legend_loc=None,
        )
        legend_patches = [
            Patch(facecolor=color_map['green'], label=f'{split_label}: GREEN (<= 0.05)'),
            Patch(facecolor=color_map['orange'], label=f'{split_label}: ORANGE (0.05-0.10)'),
            Patch(facecolor=color_map['red'], label=f'{split_label}: RED (> 0.10)'),
        ]
        ax.legend(handles=legend_patches, loc='upper right', frameon=False)
        fig.tight_layout(pad=1.1)
        encoded = figure_to_base64(fig)
        return f'<img src="data:image/png;base64,{encoded}" style="display:block; width:100%; max-width:1100px; height:auto;">'

    def _build_family_summary(self, signal: str, total: int, green_cnt: int, orange_cnt: int, red_cnt: int, sample_label: str = "Family") -> str:
        label = {'green': 'GREEN', 'orange': 'ORANGE', 'red': 'RED', 'blue': 'INFO'}.get(signal, signal.upper())
        return f"""
        <div style="margin:12px 0 16px 0;">
            <p><b>{sample_label} signal:</b> <span style="color:{signal}; font-weight:bold;">{label}</span></p>
            <table border="1" cellpadding="5" cellspacing="0">
                <tr><th>Status</th><th>Count</th><th>Share</th></tr>
                <tr><td style="color:green; font-weight:bold;">GREEN</td><td>{green_cnt}</td><td>{green_cnt}/{total if total > 0 else 1}</td></tr>
                <tr><td style="color:orange; font-weight:bold;">ORANGE</td><td>{orange_cnt}</td><td>{orange_cnt}/{total if total > 0 else 1}</td></tr>
                <tr><td style="color:red; font-weight:bold;">RED</td><td>{red_cnt}</td><td>{red_cnt}/{total if total > 0 else 1}</td></tr>
            </table>
        </div>
        """

    def _run_family_lr(
        self,
        family_spec: dict,
        df_train: pd.DataFrame,
        df_test: pd.DataFrame,
        encoded_features: list[str],
        target_col: str,
        exposure_col: Optional[str] = None,
        df_all: Optional[pd.DataFrame] = None,
    ) -> dict:
        """Drop-one likelihood-ratio test per factor under a given GLM family.

        For each feature ``j``:

        * Fit the **full** model with all features
          (Poisson + ``offset=log(exposure)`` when applicable).
        * Fit the **reduced** model with feature ``j`` dropped.
        * ``LR = 2·(LL_full − LL_reduced)`` is the classical Wilks
          likelihood-ratio statistic, distributed as ``χ²(df=1)`` under
          the null hypothesis ``β_j = 0``.

        This replaces the prior Wald-style ``(coef/SE)²`` proxy; the two
        agree asymptotically but Wald undershoots LR by 4–10× for strong
        factors, which is what the upstream validation team flagged.
        """
        split_frames = {'all': df_all if df_all is not None else pd.concat([df_train, df_test], ignore_index=True),
                        'train': df_train,
                        'test': df_test}
        split_results = {}

        use_offset = bool(exposure_col) and family_spec['key'] == 'poisson'

        for split_name, frame in split_frames.items():
            if frame.empty:
                split_results[split_name] = {'present': False}
                continue

            X_raw = frame[encoded_features].apply(pd.to_numeric, errors='coerce')
            y_raw = pd.to_numeric(frame[target_col], errors='coerce')
            valid_mask = self._valid_mask_for_family(y_raw, family_spec['key']) & np.isfinite(X_raw).all(axis=1)

            if use_offset and exposure_col in frame.columns:
                exp_raw = pd.to_numeric(frame[exposure_col], errors='coerce')
                valid_mask = valid_mask & np.isfinite(exp_raw) & (exp_raw > 0)

            if valid_mask.sum() < 8:
                split_results[split_name] = {'present': False}
                continue

            X_valid = X_raw.loc[valid_mask].copy()
            y_valid = y_raw.loc[valid_mask].copy()
            offset_arr = (np.log(pd.to_numeric(frame.loc[valid_mask, exposure_col], errors='coerce').to_numpy(dtype=float))
                          if use_offset and exposure_col in frame.columns else None)

            # --- Full model: all features ---
            try:
                X_full = sm.add_constant(X_valid, has_constant='add')
                glm_kwargs = {'family': family_spec['family']}
                if offset_arr is not None:
                    glm_kwargs['offset'] = offset_arr
                fit_full = sm.GLM(y_valid, X_full, **glm_kwargs).fit(disp=0, maxiter=100)
                ll_full = float(fit_full.llf)
            except Exception:
                split_results[split_name] = {'present': False}
                continue

            # --- Per-feature reduced models ---
            per_feat: dict[str, dict] = {}
            for j in encoded_features:
                try:
                    X_red = sm.add_constant(X_valid.drop(columns=[j]), has_constant='add')
                    fit_red = sm.GLM(y_valid, X_red, **glm_kwargs).fit(disp=0, maxiter=100)
                    lr = 2.0 * (ll_full - float(fit_red.llf))
                    # Guard against tiny negatives from numerical noise.
                    lr_clean = max(lr, 0.0)
                    p_value = float(chi2.sf(lr_clean, 1)) if np.isfinite(lr_clean) else float('nan')
                    per_feat[j] = {'lr': float(lr_clean), 'p': p_value}
                except Exception:
                    per_feat[j] = {'lr': float('nan'), 'p': float('nan')}

            split_results[split_name] = {
                'present': True,
                'per_feat': per_feat,
                'n_obs': int(len(y_valid)),
            }

        rows = []
        for feature in encoded_features:
            row = {
                'feature': feature,
                'distribution': family_spec['label'],
                'df': 1,
                'LR_all': float('nan'),
                'p_all': float('nan'),
                'LR_train': float('nan'),
                'p_train': float('nan'),
                'LR_test': float('nan'),
                'p_test': float('nan'),
            }
            for split_name in ('all', 'train', 'test'):
                info = split_results.get(split_name, {})
                if not info.get('present'):
                    continue
                stat = info['per_feat'].get(feature, {}).get('lr', float('nan'))
                p_value = info['per_feat'].get(feature, {}).get('p', float('nan'))
                row[f'LR_{split_name}'] = float(stat)
                row[f'p_{split_name}'] = float(p_value)
            rows.append(row)

        split_stats = {k: {'n_obs': v.get('n_obs', 0)} for k, v in split_results.items()}

        res_df = pd.DataFrame(rows)
        if res_df.empty:
            return {
                'signal': 'blue',
                'panel_html': f"""
                <p><b>Distribution:</b> {family_spec['label']}</p>
                <p><i>{family_spec['description']}</i></p>
                <p>No valid observations were available for this distribution.</p>
                """,
            }

        res_df['flag_all']   = res_df['p_all'].apply(self._p_to_flag)
        res_df['flag_train'] = res_df['p_train'].apply(self._p_to_flag)
        res_df['flag_test']  = res_df['p_test'].apply(self._p_to_flag)

        split_summaries = {}
        for split_name in ('all', 'train', 'test'):
            flag_col = f'flag_{split_name}'
            valid_flags = res_df[flag_col].isin(['green', 'orange', 'red'])
            total = int(valid_flags.sum())
            red_cnt = int((res_df.loc[valid_flags, flag_col] == 'red').sum())
            orange_cnt = int((res_df.loc[valid_flags, flag_col] == 'orange').sum())
            green_cnt = int((res_df.loc[valid_flags, flag_col] == 'green').sum())
            red_share = (red_cnt / total) if total > 0 else 0.0
            orange_share = (orange_cnt / total) if total > 0 else 0.0
            signal = _aggregate_lr_test_signal(red_share, orange_share) if total > 0 else 'blue'
            split_summaries[split_name] = {
                'signal': signal,
                'total': total,
                'green_cnt': green_cnt,
                'orange_cnt': orange_cnt,
                'red_cnt': red_cnt,
            }

        # Family signal is driven by the All view (canonical reference).
        family_signal = split_summaries['all']['signal']

        all_hist_html   = self._build_histogram_html(res_df, family_spec['label'], 'all')
        train_hist_html = self._build_histogram_html(res_df, family_spec['label'], 'train')
        test_hist_html  = self._build_histogram_html(res_df, family_spec['label'], 'test')
        # Red rows highlighted by the All flag (reference matches the All view).
        table_html = render_flag_table(res_df, flag_col='flag_all', float_format='%.3f')
        summary_all_html = self._build_family_summary(
            split_summaries['all']['signal'],
            split_summaries['all']['total'],
            split_summaries['all']['green_cnt'],
            split_summaries['all']['orange_cnt'],
            split_summaries['all']['red_cnt'],
            sample_label='All',
        )
        summary_train_html = self._build_family_summary(
            split_summaries['train']['signal'],
            split_summaries['train']['total'],
            split_summaries['train']['green_cnt'],
            split_summaries['train']['orange_cnt'],
            split_summaries['train']['red_cnt'],
            sample_label='Train',
        )
        summary_test_html = self._build_family_summary(
            split_summaries['test']['signal'],
            split_summaries['test']['total'],
            split_summaries['test']['green_cnt'],
            split_summaries['test']['orange_cnt'],
            split_summaries['test']['red_cnt'],
            sample_label='Test',
        )

        all_n = split_stats.get('all', {}).get('n_obs', 0)
        train_n = split_stats.get('train', {}).get('n_obs', 0)
        test_n = split_stats.get('test', {}).get('n_obs', 0)
        panel_html = f"""
        <div>
            <p><b>Distribution:</b> {family_spec['label']}</p>
            <p><i>{family_spec['description']}</i></p>
            <p><i>All observations used: {all_n}. Train: {train_n}. Test: {test_n}.</i></p>
            {summary_all_html}
            {summary_train_html}
            {summary_test_html}
            <h4>All factor-level chart</h4>
            {all_hist_html}
            <h4>Train factor-level chart</h4>
            {train_hist_html}
            <h4>Test factor-level chart</h4>
            {test_hist_html}
            <h4>LR Parameter Table</h4>
            {table_html}
        </div>
        """
        return {'signal': family_signal, 'panel_html': panel_html}

    def _build_tabs_html(self, panels: list[dict]) -> str:
        root_id = f"m32-tabs-{id(self)}"
        button_html = []
        panel_html = []
        for idx, panel in enumerate(panels):
            active = 'true' if idx == 0 else 'false'
            display = 'block' if idx == 0 else 'none'
            signal_color = STATUS_COLORS.get(panel['signal'], panel['signal'])
            button_html.append(
                f"""
                <button type="button"
                        data-tab-target="{root_id}-panel-{idx}"
                        data-root-id="{root_id}"
                        aria-selected="{active}"
                        style="padding:8px 14px; border:1px solid #d9dee8; background:#fff; cursor:pointer; border-radius:8px; color:{signal_color}; font-weight:600;">
                    {panel['label']}
                </button>
                """
            )
            panel_html.append(
                f"""
                <div id="{root_id}-panel-{idx}" data-tab-panel="{root_id}" style="display:{display}; margin-top:16px;">
                    {panel['html']}
                </div>
                """
            )

        script = f"""
        <script>
        (function() {{
            var root = document.getElementById('{root_id}');
            if (!root) return;
            var buttons = root.querySelectorAll('button[data-tab-target]');
            var panels = root.querySelectorAll('div[data-tab-panel="{root_id}"]');
            buttons.forEach(function(btn) {{
                btn.addEventListener('click', function() {{
                    var targetId = btn.getAttribute('data-tab-target');
                    buttons.forEach(function(other) {{ other.setAttribute('aria-selected', 'false'); }});
                    panels.forEach(function(panel) {{ panel.style.display = 'none'; }});
                    btn.setAttribute('aria-selected', 'true');
                    var target = document.getElementById(targetId);
                    if (target) target.style.display = 'block';
                }});
            }});
        }})();
        </script>
        """
        return f"""
        <div id="{root_id}">
            <div style="display:flex; gap:8px; flex-wrap:wrap; margin:14px 0 8px 0;">
                {''.join(button_html)}
            </div>
            {''.join(panel_html)}
        </div>
        {script}
        """

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        if is_generic_classification_mode(cfg):
            self.test_signal = "blue"
            logger.info(f"Test {self.test_code} {self.test_name}: skipped for generic classification mode")
            return _classification_mode_na(self.test_name)

        sample_col = getattr(cfg.columns, 'sample_column', None)
        target_col = getattr(cfg.columns, 'target_column', None)
        if sample_col is None or sample_col not in df.columns:
            return {'error': 'sample_column missing in config or dataframe'}
        if target_col is None or target_col not in df.columns:
            return {'error': 'target_column missing in config or dataframe'}

        all_features = self._collect_feature_list(cfg)
        cat_feats_cfg = set(getattr(cfg.columns, 'categorical_features', []) or [])
        numeric_features = [f for f in all_features if f in df.columns and f not in cat_feats_cfg]
        categorical_features = [f for f in all_features if f in df.columns and f in cat_feats_cfg]

        # GLM-пресет: тест работает на linear-predictor-вкладах _VALUE,
        # категориальные кодировать не нужно — они уже превращены в числовые
        # ln(SCORING)-колонки через apply_glm_scoring().
        if is_glm_preset(cfg):
            resolved = resolve_feature_columns(
                df, numeric_features + categorical_features,
                kind="value", cfg=cfg, test_code=self.test_code,
            )
            numeric_features = resolved
            categorical_features = []

        if not numeric_features and not categorical_features:
            return {'error': 'No numeric or categorical features available for the LR test.'}

        # Готовим train/test, сохраняя и численные, и категориальные фичи + экспозицию (если есть).
        exposure_col = getattr(cfg.columns, 'weight_column', None)
        carry_exposure = bool(exposure_col) and exposure_col in df.columns
        extra_cols = [exposure_col] if carry_exposure else []
        work_cols = numeric_features + categorical_features + extra_cols + [target_col, sample_col]
        df_work = df[work_cols].copy()
        df_train, df_test, df_all = split_frames(df_work, cfg)
        keep = numeric_features + categorical_features + extra_cols + [target_col]
        df_train = df_train[keep].copy()
        df_test = df_test[keep].copy()
        df_all = df_all[keep].copy()
        if is_big_data_mode(cfg):
            df_train = sample_frame_for_big_data(df_train, cfg, max_rows=80_000, random_state=311)
            df_test = sample_frame_for_big_data(df_test, cfg, max_rows=80_000, random_state=312)
            df_all = sample_frame_for_big_data(df_all, cfg, max_rows=120_000, random_state=313)

        # Категориальные фичи кодируем target encoding со смуссингом — тот же подход,
        # что в M 3.2, чтобы сравнения по таблице были непротиворечивы.
        if categorical_features:
            df_train_enc, df_test_enc, enc_map = target_encode_categorical(
                df_train, df_test, categorical_features, target_col, smoothing=self.smoothing,
            )
            # Apply the same train-fitted encoding to df_all so the All sample uses
            # the same numeric representation as Train/Test.
            df_all_enc = df_all.copy()
            for raw_col, enc_col in enc_map.items():
                tr_mean = df_train[target_col].mean()
                mapping = df_train.groupby(raw_col)[target_col].mean().to_dict()
                df_all_enc[enc_col] = df_all_enc[raw_col].map(mapping).fillna(tr_mean)
            encoded_categorical = [name for name in df_train_enc.columns if name in enc_map]
            keep_cols = numeric_features + encoded_categorical + extra_cols + [target_col]
            df_train_lr = df_train_enc[[c for c in keep_cols if c in df_train_enc.columns]].copy()
            df_test_lr  = df_test_enc[[c for c in keep_cols if c in df_test_enc.columns]].copy()
            df_all_lr   = df_all_enc[[c for c in keep_cols if c in df_all_enc.columns]].copy()
            encoded_features = numeric_features + encoded_categorical
            reverse_map = {**{f: f for f in numeric_features}, **enc_map}
            feature_type_map = {
                **{f: 'numeric' for f in numeric_features},
                **{enc: 'categorical' for enc in encoded_categorical},
            }
        else:
            df_train_lr = df_train.copy()
            df_test_lr = df_test.copy()
            df_all_lr = df_all.copy()
            encoded_features = numeric_features
            reverse_map = {f: f for f in numeric_features}
            feature_type_map = {f: 'numeric' for f in numeric_features}

        family_panels = []
        family_signals = []
        model_mode = get_model_mode(cfg)
        for family_spec in self._family_specs(model_mode):
            family_result = self._run_family_lr(
                family_spec=family_spec,
                df_train=df_train_lr,
                df_test=df_test_lr,
                encoded_features=encoded_features,
                target_col=target_col,
                exposure_col=exposure_col if carry_exposure else None,
                df_all=df_all_lr,
            )
            family_panels.append({
                'label': family_spec['label'],
                'signal': family_result['signal'],
                'html': family_result['panel_html'],
                'reverse_map': reverse_map,
                'feature_type_map': feature_type_map,
            })
            family_signals.append(family_result['signal'])

        self.test_signal = _aggregate_lr_distribution_signals(family_signals)
        signal_label = {'green': 'GREEN', 'orange': 'ORANGE', 'red': 'RED', 'blue': 'INFO'}.get(self.test_signal, self.test_signal.upper())

        offset_note = ''
        if carry_exposure and model_mode == 'frequency':
            offset_note = f' Poisson GLM is fit with <code>offset=log({exposure_col})</code> per actuarial standard.'
        combined_html = f"""
        <h4>Likelihood-ratio test by distribution</h4>
        <p><b>Final Signal:</b> <span style="color:{self.test_signal}; font-weight:bold;">{signal_label}</span></p>
        <p><i>Mode: {model_mode}. Validation sample: {get_validation_label(cfg)}. Numeric features: {len(numeric_features)}, categorical (target-encoded): {len(categorical_features)}.{offset_note}</i></p>
        {self._build_tabs_html(family_panels)}
        """

        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {'combined': combined_html}


class M32_MulticollinearityTest(BaseModelTest):
    """
    VIF test с поддержкой численных и категориальных признаков.
    Категориальные признаки кодируются через target encoding с smoothing вместо one-hot.
    """
    def __init__(self, test_num='M 3.2', test_name='Multicollinearity Test', smoothing: float = 10.0):
        super().__init__(test_num, test_name)
        self.smoothing = smoothing

    def compute_vif(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Вычисляет VIF для каждого признака.
        Использует numpy lstsq (быстрее statsmodels) и joblib для параллелизма.
        При N > 50 000 строк автоматически сэмплирует данные (VIF — свойство
        структуры признаков, не зависит от числа строк при достаточном объёме).
        """
        MAX_ROWS = 50_000
        X_samp = df
        if len(df) > MAX_ROWS:
            X_samp = df.sample(n=MAX_ROWS, random_state=42)
            logger.info(f"VIF: используется выборка {MAX_ROWS} строк из {len(df)}")

        X_np = sm.add_constant(X_samp).values.astype(float)
        feature_names = list(df.columns)
        indices = list(range(1, X_np.shape[1]))  # skip const at index 0

        vif_values = Parallel(n_jobs=-1, backend="threading")(
            delayed(_vif_numpy)(X_np, i)
            for i in tqdm(indices, desc="Calculating VIF")
        )
        return pd.DataFrame({"Feature": feature_names, "VIF": vif_values})

    def assign_flag(self, vif: float) -> str:
        """Map a VIF value to a traffic-light flag using thresholds stashed on self.

        ``self._vif_thresholds`` is set by :meth:`run` from the validated
        SBSConfig. When the test is invoked without going through ``run`` we
        fall back to methodology defaults.
        """
        thresholds = getattr(self, "_vif_thresholds", None)
        red = thresholds.red if thresholds is not None else 5.0
        orange = thresholds.orange if thresholds is not None else 3.0
        if vif > red:
            return "red"
        elif vif > orange:
            return "orange"
        else:
            return "green"

    def compute_signal(self, flags: List[str]) -> str:
        if "red" in flags:
            return "red"
        orange_count = flags.count("orange")
        total = len(flags)
        if orange_count / total > 0.2:
            return "orange"
        return "green"

    def plot_vif_comparison(self, merged: pd.DataFrame) -> str:
        x = np.arange(len(merged))
        fig, ax = figure(size="large")
        bar_width = 0.4
        ax.bar(x - bar_width / 2, merged["VIF_train"], width=bar_width, label="Train", color=COLORS['BLUE'])
        ax.bar(x + bar_width / 2, merged["VIF_test"], width=bar_width, label="Test", color=COLORS['EMERALD'])
        ax.set_xticks(x)
        ax.set_xticklabels(merged["Feature"], rotation=45, ha="right")
        apply_standard_axis_style(ax, title="VIF Comparison (Train vs Test)", ylabel="VIF")
        ax.grid(True, linestyle='--', linewidth=0.5)
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode()

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # валидируем конфиг и режем выборки
        cfg = ensure_config(config, df)
        self._vif_thresholds = cfg.thresholds.vif
        target_col = cfg.columns.target_column
        
        # Получаем численные и категориальные признаки
        num_features = getattr(cfg.columns, 'numeric_features', []) or []
        cat_features = getattr(cfg.columns, 'categorical_features', []) or []
        # ensure lists
        if isinstance(num_features, str): num_features = [num_features]
        if isinstance(cat_features, str): cat_features = [cat_features]
        # unique
        num_features = list(dict.fromkeys(num_features))
        cat_features = list(dict.fromkeys(cat_features))

        # GLM-пресет: VIF/корреляции считаем на _VALUE-колонках (линейные вклады),
        # категориальный target-encoding не нужен — _VALUE уже числовой.
        if is_glm_preset(cfg):
            resolved = resolve_feature_columns(
                df, num_features + cat_features,
                kind="value", cfg=cfg, test_code=self.test_code,
            )
            num_features = resolved
            cat_features = []

        all_features = num_features + cat_features

        if not all_features:
            raise ValueError("Не указаны признаки в конфиге (numeric_features или categorical_features)")

        # формируем X_train / X_test
        if is_big_data_mode(cfg):
            train_mask, test_mask = split_sample_masks(df, cfg)
            needed_cols = all_features + [target_col]
            needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
            df_small = df.loc[:, needed_cols]
            df_train = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=80_000, random_state=321).copy()
            df_test = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=80_000, random_state=322).copy()
        else:
            df_train, df_test, _ = split_frames(df, cfg)

        missing_tr = [c for c in all_features if c not in df_train.columns]
        missing_te = [c for c in all_features if c not in df_test.columns]
        if missing_tr or missing_te:
            raise ValueError(f"Отсутствуют фичи в train/test: train_missing={missing_tr}, test_missing={missing_te}")

        # Добавляем target в датафреймы для кодирования
        df_train_with_target = df_train[all_features + [target_col]].copy()
        df_test_with_target = df_test[all_features + [target_col]].copy()

        # Приводим численные к numeric и проверяем NaN
        for X, name in [(df_train_with_target, "train"), (df_test_with_target, "test")]:
            for col in num_features:
                if not pd.api.types.is_numeric_dtype(X[col]):
                    try:
                        X[col] = pd.to_numeric(X[col], errors='raise')
                    except Exception:
                        raise ValueError(f"Колонка {col} в {name} не числовая и не конвертируется в numeric.")
            # Проверяем NaN во всех признаках
            if X[all_features].isnull().any().any():
                bad = X[all_features].columns[X[all_features].isnull().any()].tolist()
                raise ValueError(f"В {name} обнаружены пропуски в колонках {bad}. "
                                f"Очистите/импутируйте данные для расчёта VIF.")

        # Применяем target encoding к категориальным признакам
        df_train_enc, df_test_enc, feature_map = target_encode_categorical(
            df_train_with_target,
            df_test_with_target,
            cat_features,
            target_col,
            smoothing=self.smoothing
        )
        
        # Убираем target из закодированных датафреймов
        X_train = df_train_enc.drop(columns=[target_col])
        X_test = df_test_enc.drop(columns=[target_col])
        
        # Создаем обратный маппинг для отображения
        reverse_feature_map = {v: v for v in num_features}  # numeric features map to themselves
        reverse_feature_map.update(feature_map)  # add categorical mappings

        # считаем VIF
        vif_train = self.compute_vif(X_train)
        vif_test  = self.compute_vif(X_test) if len(X_test) > 0 else None

        # Добавляем колонку типа признака
        def get_feature_type(feat_name):
            original = reverse_feature_map.get(feat_name, feat_name)
            if original in num_features:
                return 'numeric'
            elif original in cat_features:
                return 'categorical'
            else:
                return 'unknown'
        
        vif_train['Type'] = vif_train['Feature'].apply(get_feature_type)
        vif_train['Original_Feature'] = vif_train['Feature'].apply(lambda x: reverse_feature_map.get(x, x))

        if vif_test is not None:
            vif_test['Type'] = vif_test['Feature'].apply(get_feature_type)
            vif_test['Original_Feature'] = vif_test['Feature'].apply(lambda x: reverse_feature_map.get(x, x))
            
            merged = pd.merge(
                vif_train[['Feature', 'Original_Feature', 'Type', 'VIF']], 
                vif_test[['Feature', 'VIF']], 
                on="Feature", 
                how="inner", 
                suffixes=("_train", "_test")
            )
            if merged.empty:
                merged = pd.merge(
                    vif_train[['Feature', 'Original_Feature', 'Type', 'VIF']], 
                    vif_test[['Feature', 'VIF']], 
                    on="Feature", 
                    how="outer", 
                    suffixes=("_train", "_test")
                )
            
            # нормализуем бесконечности/NaN
            merged["VIF_train"] = merged["VIF_train"].replace([np.inf, -np.inf], np.nan)
            merged["VIF_test"]  = merged["VIF_test"].replace([np.inf, -np.inf], np.nan)
            merged["VIF_train"] = merged["VIF_train"].fillna(1e6)
            merged["VIF_test"]  = merged["VIF_test"].fillna(1e6)
            merged["Delta"] = (merged["VIF_train"] - merged["VIF_test"]).abs()
            
            merged["Flag_Train"] = merged["VIF_train"].apply(self.assign_flag)
            merged["Flag_Test"]  = merged["VIF_test"].apply(self.assign_flag)
            merged["Flag_Final"] = [
                worst_flag(flag_train, flag_test)
                for flag_train, flag_test in zip(merged["Flag_Train"], merged["Flag_Test"])
            ]

            # флаг-сводка
            def count_flags(flag_series):
                return {"green": (flag_series == "green").sum(),
                        "orange": (flag_series == "orange").sum(),
                        "red": (flag_series == "red").sum()}
            train_flags = count_flags(merged["Flag_Train"])
            test_flags  = count_flags(merged["Flag_Test"])
            signal_train = self.compute_signal(merged["Flag_Train"].tolist())
            signal_test  = self.compute_signal(merged["Flag_Test"].tolist())
            self.test_signal = "red" if "red" in [signal_train, signal_test] else \
                            ("orange" if "orange" in [signal_train, signal_test] else "green")

            # листы фич по зонам (по train)
            def features_by_flag(df, flag_series, flag):
                return df[flag_series == flag]["Original_Feature"].unique().tolist()
            features_green  = features_by_flag(merged, merged["Flag_Train"], "green")
            features_orange = features_by_flag(merged, merged["Flag_Train"], "orange")
            features_red    = features_by_flag(merged, merged["Flag_Train"], "red")

            # HTML
            features_by_zone_html = f"""
            <h4>Feature Flags (Train)</h4>
            <p><b style='color:green'>Green Zone Features:</b> {', '.join(features_green) if features_green else 'None'}</p>
            <p><b style='color:orange'>Orange Zone Features:</b> {', '.join(features_orange) if features_orange else 'None'}</p>
            <p><b style='color:red'>Red Zone Features:</b> {', '.join(features_red) if features_red else 'None'}</p>
            """

            summary_table = f"""
            <h4>VIF Zones Summary</h4>
            <table border="1" cellpadding="5" cellspacing="0">
                <tr><th>Dataset</th><th style='color:green'>Green</th><th style='color:orange'>Orange</th><th style='color:red'>Red</th></tr>
                <tr><td>Train</td><td style='color:green'><b>{train_flags["green"]}</b></td>
                <td style='color:orange'><b>{train_flags["orange"]}</b></td>
                <td style='color:red'><b>{train_flags["red"]}</b></td></tr>
                <tr><td>Test</td><td style='color:green'><b>{test_flags["green"]}</b></td>
                <td style='color:orange'><b>{test_flags["orange"]}</b></td>
                <td style='color:red'><b>{test_flags["red"]}</b></td></tr>
            </table>
            """

            signal_html = f"""
            <p><b>Final Signal (Train):</b> <span style='color:{signal_train}; font-weight:bold'>{signal_train.upper()}</span></p>
            <p><b>Final Signal (Test):</b> <span style='color:{signal_test}; font-weight:bold'>{signal_test.upper()}</span></p>
            <p><i>Численных признаков: {len(num_features)}, Категориальных признаков: {len(cat_features)}</i></p>
            <p><i>Примечание: категориальные признаки закодированы через target encoding с smoothing={self.smoothing}</i></p>
            """

            # Для графика используем Original_Feature
            signal_html = f"""
            <p><b>Final Signal (Train):</b> <span style='color:{signal_train}; font-weight:bold'>{signal_train.upper()}</span></p>
            <p><b>Final Signal (Test):</b> <span style='color:{signal_test}; font-weight:bold'>{signal_test.upper()}</span></p>
            <p><i>Numeric features: {len(num_features)}, categorical features: {len(cat_features)}</i></p>
            <p><i>Note: categorical features are encoded with target encoding, smoothing={self.smoothing}.</i></p>
            """
            plot_df = merged[['Original_Feature', 'VIF_train', 'VIF_test']].drop_duplicates('Original_Feature')
            vif_plot = self.plot_vif_comparison(plot_df.rename(columns={'Original_Feature': 'Feature'}))
            
            table_html = render_flag_table(
                merged[
                    [
                        "Original_Feature",
                        "Type",
                        "VIF_train",
                        "VIF_test",
                        "Delta",
                        "Flag_Train",
                        "Flag_Test",
                        "Flag_Final",
                    ]
                ],
                flag_col="Flag_Final",
                float_format="%.2f",
            )

            html = f"""
            <h4>Multicollinearity Test</h4>
            {signal_html}
            {summary_table}
            <br>
            {features_by_zone_html}
            <br>
            <h5>VIF Comparison Chart</h5>
            <img src="data:image/png;base64,{vif_plot}" style="display:block; width:100%; max-width:1000px; height:auto;">
            <h5>VIF Table</h5>
            {table_html}
            """
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"combined": html}

        else:
            # кейс, когда тест-сэмпла нет → считаем только train
            vif_train["VIF"] = vif_train["VIF"].replace([np.inf, -np.inf], np.nan).fillna(1e6)
            vif_train["Flag_Train"] = vif_train["VIF"].apply(self.assign_flag)
            signal_train = self.compute_signal(vif_train["Flag_Train"].tolist())
            self.test_signal = signal_train

            table_html = render_flag_table(
                vif_train[['Original_Feature', 'Type', 'VIF', 'Flag_Train']].rename(columns={"VIF": "VIF_train"}),
                flag_col="Flag_Train",
                float_format="%.2f",
            )
            signal_html = f"""
            <p><b>Final Signal (Train):</b> <span style='color:{signal_train}; font-weight:bold'>{signal_train.upper()}</span></p>
            <p><i>Test выборка не обнаружена (sample='test'). Показаны только метрики Train.</i></p>
            <p><i>Численных признаков: {len(num_features)}, Категориальных признаков: {len(cat_features)}</i></p>
            <p><i>Примечание: категориальные признаки закодированы через target encoding с smoothing={self.smoothing}</i></p>
            """

            signal_html = f"""
            <p><b>Final Signal (Train):</b> <span style='color:{signal_train}; font-weight:bold'>{signal_train.upper()}</span></p>
            <p><i>Test sample was not found (sample='test'). Only train metrics are shown.</i></p>
            <p><i>Numeric features: {len(num_features)}, categorical features: {len(cat_features)}</i></p>
            <p><i>Note: categorical features are encoded with target encoding, smoothing={self.smoothing}.</i></p>
            """

            html = f"""
            <h4>Multicollinearity Test (Train only)</h4>
            {signal_html}
            <h5>VIF Table</h5>
            {table_html}
            """
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"combined": html}
