# core import
from ...core.base_test import BaseModelTest
# default imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from io import BytesIO
import base64
# stat imports
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, roc_curve, auc
from scipy.stats import norm
from scipy import sparse
from scipy.special import expit 
# module imports
import itertools
from typing import List, Dict, Union, Any, Optional

from joblib import Parallel, delayed, parallel_backend

# NEW
from ...core.config_validation import validate_config as _validate_config, ConfigValidationError
from ...core.data_utils import (
    ensure_config,
    split_frames,
    split_sample_masks,
    get_weight_col,
    get_score_col,
    get_features,
    is_binary_mode,
    is_big_data_mode,
    is_generic_classification_mode,
    get_validation_label,
    sample_frame_for_big_data,
)
from ...core.styles import COLORS, STATUS_COLORS, figure
from ...core.metrics import gini, gini_normalized, gini_numba
from .._visual_utils import OBSERVATION_COUNT_LABEL, apply_standard_axis_style, figure_to_base64, render_flag_table
import logging
from tqdm import tqdm
logger = logging.getLogger(__name__)

from ._shared import (
    _classification_mode_na,
    powerstat_value,
    gini_one_feature,
    gini_for_features_fast,
    gini_one_categorical_feature,
    gini_for_categorical_features,
    powerstat_one_feature,
    powerstat_for_features_fast,
    powerstat_one_categorical_feature,
    powerstat_for_categorical_features,
    determine_optimal_freq,
    is_glm_preset,
    resolve_feature_columns,
)


class M22_GiniFactorsTest(BaseModelTest):
    """
    Класс для теста M 2.2: Gini by Factors.

    Проверяет информативность признаков на обучающей и тестовой выборках с помощью коэффициента Джини.
    Строит графики, расставляет флаги (зеленый/жёлтый/красный) по уровням значимости признаков 
    и определяет общий сигнал качества. Используется для оценки стабильности и значимости отдельных факторов.

    Общая логика:
        1. Для каждого признака считаются значения Gini по train и test (на основе кривой Лоренца).
        2. Вычисляется разница между Gini на train и test.
        3. Каждому признаку присваивается флаг: 
            - "green" — Gini > 5%,
            - "orange" — 0% < Gini ≤ 5%,
            - "red" — Gini ≤ 0%.
        4. Выводится сигнал:
            - "red" — если есть хотя бы один красный флаг,
            - "orange" — если более 20% признаков жёлтые,
            - "green" — в остальных случаях.
        5. Генерируется HTML-отчет с графиками и таблицами.

    Атрибуты:
        * test_signal (str): Итоговый сигнал для всего теста ("green", "orange", "red").
        * individual_features_gini (pd.DataFrame): Таблица со значениями Gini и флагами по каждому признаку.

    Методы:
        * assign_flag(gini): Возвращает флаг на основе значения Gini.
        * compute_signal(flags): Определяет итоговый сигнал по списку флагов.
        * plot_gini_bar(df, column, title): Строит горизонтальную гистограмму Gini для признаков.
        * run(df_train, df_test, target_column, features, n_jobs): Запускает тест и возвращает HTML-отчет.
    """
    def __init__(self):
        super().__init__("M 2.2", "PowerStat by Factors")
        self.individual_features_gini = pd.DataFrame()
        self.individual_features_powerstat = pd.DataFrame()

    def assign_flag(self, gini):
        """
        Присваивает цветовой флаг на основе значения Gini:
            - "red": Gini ≤ 0
            - "orange": Gini ≤ 5
            - "green": Gini > 5

        Параметры:
            * gini (float): Значение Gini (%).

        Возвращает:
            * str: Цвет флага.
        """
        if gini <= 0:
            return "red"
        elif gini <= 5:
            return "orange"
        else:
            return "green"

    def compute_signal(self, flags: List[str]) -> str:
        """
        Рассчитывает итоговый сигнал по списку флагов:
            - "red": если есть хотя бы один красный.
            - "orange": если жёлтых более 20%.
            - "green": в остальных случаях.

        Параметры:
            * flags (List[str]): Список цветовых флагов по признакам.

        Возвращает:
            * str: Цвет итогового сигнала ("red", "orange", "green").
        """
        if "red" in flags:
            return "red"
        orange_count = flags.count("orange")
        total = len(flags)
        if orange_count / total > 0.2:
            return "orange"
        return "green"

    def plot_gini_bar(self, gini_df: pd.DataFrame, column: str, title: str) -> str:
        """
        Строит горизонтальную гистограмму значений Gini по признакам и кодирует её в base64.

        Параметры:
            * gini_df (pd.DataFrame): Таблица с Gini и флагами.
            * column (str): Название колонки для построения ("Gini_Train" или "Gini_Test").
            * title (str): Заголовок графика.

        Возвращает:
            * str: Base64-кодированное изображение графика.
        """
        # ~0.5 inch на признак, но не меньше 3" (иначе подписи слипаются на маленьких списках)
        # и не больше 60" (400+ фич выглядит вменяемо при чтении сверху вниз).
        n_feats = max(1, len(gini_df))
        height = max(3.0, min(0.5 * n_feats + 1.5, 60))
        fig, ax = figure(size=(10, height))

        bars = ax.barh(gini_df["Feature"], gini_df[column], color=COLORS['GRAY'])
        for i, flag in enumerate(gini_df[f"{column}_flag"]):
            bars[i].set_color(flag)

        ax.set_xlabel("PowerStat %")
        ax.set_title(title)
        ax.grid(True, axis="x", linestyle='--', linewidth=0.5)
        
        # Уменьшаем шрифт, чтобы длинные имена влезли
        ax.tick_params(labelsize=8)
        
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png", dpi=150)
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode()

    def run(self, df: pd.DataFrame, config: dict, n_jobs=3) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        if is_generic_classification_mode(cfg):
            self.test_signal = "blue"
            return _classification_mode_na(self.test_name)
        target_column = cfg.columns.target_column
        
        # Получаем и численные, и категориальные признаки
        num_features = cfg.columns.numeric_features or []
        cat_features = cfg.columns.categorical_features or []

        # GLM-пресет: ранжируем по multiplicative _SCORING-колонкам
        # (Методика: M2.2 оценивает фактор по его GLM-вкладу, не сырому уровню).
        # Категориальные после scoring становятся числовыми и попадают в numeric-путь.
        if is_glm_preset(cfg):
            resolved = resolve_feature_columns(
                df, num_features + cat_features,
                kind="scoring", cfg=cfg, test_code=self.test_code,
            )
            num_features = resolved
            cat_features = []

        all_features = num_features + cat_features
        if not all_features:
            raise ConfigValidationError(["Для M 2.2 требуется непустой список columns.numeric_features или columns.categorical_features"])

        # Проверяем наличие колонок
        weight_col = getattr(cfg.columns, 'weight_column', None)
        if is_big_data_mode(cfg):
            train_mask, test_mask = split_sample_masks(df, cfg)
            needed_cols = all_features + [target_column, weight_col]
            needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
            df_small = df.loc[:, needed_cols]
            df_train = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=200_000, random_state=221).copy()
            df_test = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=200_000, random_state=222).copy()
            df_all = sample_frame_for_big_data(df_small, cfg, max_rows=300_000, random_state=223).copy()
        else:
            df_train, df_test, df_all = split_frames(df, cfg)

        missing_cols = [col for col in all_features + [target_column] 
                       if col not in df_train.columns or col not in df_test.columns]
        if missing_cols:
            raise ValueError(f"Следующие колонки отсутствуют в данных: {missing_cols}")
        
        # Валидация численных признаков и таргета
        for col_name in tqdm(num_features + [target_column], desc="M 2.2 - Validate numeric columns"):
            if not pd.api.types.is_numeric_dtype(df_train[col_name]):
                try:
                    df_train[col_name] = pd.to_numeric(df_train[col_name], errors='raise')
                except ValueError:
                    raise ValueError(f"Column {col_name} is not numeric.")
            if not pd.api.types.is_numeric_dtype(df_test[col_name]):
                try:
                    df_test[col_name] = pd.to_numeric(df_test[col_name], errors='raise')
                except ValueError:
                    raise ValueError(f"Column {col_name} is not numeric.")
            if df_train[col_name].isnull().any():
                raise ValueError(f"Column {col_name} contains missing values.")
            if df_test[col_name].isnull().any():
                raise ValueError(f"Column {col_name} contains missing values.")

        # Валидация категориальных признаков (просто проверяем на NaN)
        for col_name in tqdm(cat_features, desc="M 2.2 - Validate categorical columns"):
            if df_train[col_name].isnull().any():
                raise ValueError(f"Categorical column {col_name} contains missing values in train.")
            if df_test[col_name].isnull().any():
                raise ValueError(f"Categorical column {col_name} contains missing values in test.")

        # Экспозиция (если задана) учитывается в PowerStat по методике
        # «Замечание после M2.1»: кумулятивные доли наблюдений и фактических значений
        # строятся с учётом весов наблюдений.
        weight_col = getattr(cfg.columns, 'weight_column', None)

        # Расчет PowerStat для численных признаков
        records_numeric = []
        if num_features:
            records_numeric = powerstat_for_features_fast(
                df_tr=df_train,
                df_te=df_test,
                target=target_column,
                features=num_features,
                n_jobs=n_jobs,
                weight=weight_col,
            )

        # Расчет PowerStat для категориальных признаков
        records_categorical = []
        if cat_features:
            records_categorical = powerstat_for_categorical_features(
                df_tr=df_train,
                df_te=df_test,
                target=target_column,
                features=cat_features,
                n_jobs=n_jobs,
                weight=weight_col,
            )

        # Объединяем результаты
        all_records = records_numeric + records_categorical

        self.individual_features_gini = pd.DataFrame(
            all_records,
            columns=["Feature", "PowerStat_Train", "PowerStat_Test", "Delta"]
        ).sort_values(by='PowerStat_Train')

        # PowerStat на всей выборке (genpop) — эталонная цифра, с которой коллеги
        # обычно сверяются. Train/Test остаются как стабильностная диагностика.
        y_all = df_all[target_column].to_numpy(dtype=float)
        w_all = df_all[weight_col].to_numpy(dtype=float) if weight_col and weight_col in df_all.columns else None
        ps_all_map: Dict[str, float] = {}
        for feat in num_features:
            x_all = df_all[feat].to_numpy(dtype=float)
            ps_all_map[feat] = powerstat_value(y_all, x_all, weight=w_all) * 100.0
        for feat in cat_features:
            # Same train-fitted target encoding as in powerstat_one_categorical_feature.
            enc = df_train.groupby(feat)[target_column].mean().to_dict()
            global_mean = float(pd.to_numeric(df_train[target_column], errors='coerce').mean())
            x_all = df_all[feat].map(enc).fillna(global_mean).to_numpy(dtype=float)
            ps_all_map[feat] = powerstat_value(y_all, x_all, weight=w_all) * 100.0
        self.individual_features_gini['PowerStat_All'] = self.individual_features_gini['Feature'].map(ps_all_map)
        self.individual_features_powerstat = self.individual_features_gini
        
        # Добавляем колонку с типом признака для информативности
        feature_types = {}
        for f in num_features:
            feature_types[f] = 'numeric'
        for f in cat_features:
            feature_types[f] = 'categorical'
        self.individual_features_gini['Type'] = self.individual_features_gini['Feature'].map(feature_types)
        
        self.individual_features_gini["PowerStat_All_flag"] = self.individual_features_gini["PowerStat_All"].apply(self.assign_flag)
        self.individual_features_gini["PowerStat_Train_flag"] = self.individual_features_gini["PowerStat_Train"].apply(self.assign_flag)
        self.individual_features_gini["PowerStat_Test_flag"] = self.individual_features_gini["PowerStat_Test"].apply(self.assign_flag)

        img_all = self.plot_gini_bar(self.individual_features_gini.sort_values(by='PowerStat_All'), "PowerStat_All", "PowerStat by Factor (All)")
        img_train = self.plot_gini_bar(self.individual_features_gini.sort_values(by='PowerStat_Train'), "PowerStat_Train", "PowerStat by Factor (Train)")
        img_test = self.plot_gini_bar(self.individual_features_gini.sort_values(by='PowerStat_Test'), "PowerStat_Test", "PowerStat by Factor (Test)")

        def count_flags(flag_series):
            return {
                "green": (flag_series == "green").sum(),
                "orange": (flag_series == "orange").sum(),
                "red": (flag_series == "red").sum()
            }

        all_flags = count_flags(self.individual_features_gini["PowerStat_All_flag"])
        train_flags = count_flags(self.individual_features_gini["PowerStat_Train_flag"])
        test_flags = count_flags(self.individual_features_gini["PowerStat_Test_flag"])

        signal_all = self.compute_signal(self.individual_features_gini["PowerStat_All_flag"].tolist())
        signal_train = self.compute_signal(self.individual_features_gini["PowerStat_Train_flag"].tolist())
        signal_test = self.compute_signal(self.individual_features_gini["PowerStat_Test_flag"].tolist())

        self.test_signal = signal_all

        signal_html = f"""
        <p><b>Signal (All):</b> <span style='color:{signal_all}; font-weight:bold'>{signal_all.upper()}</span></p>
        <p><b>Signal (Train):</b> <span style='color:{signal_train}; font-weight:bold'>{signal_train.upper()}</span></p>
        <p><b>Signal (Test):</b> <span style='color:{signal_test}; font-weight:bold'>{signal_test.upper()}</span></p>
        <p><b>Overall Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal.upper()}</span> <i>(based on All)</i></p>
        <p><i>Численных признаков: {len(num_features)}, Категориальных признаков: {len(cat_features)}</i></p>
        """

        summary_table = f"""
        <table border="1" cellpadding="5" cellspacing="0">
            <tr><th>Dataset</th><th style='color:green'>Green</th><th style='color:orange'>Orange</th><th style='color:red'>Red</th></tr>
            <tr><td>All</td><td style='color:green'><b>{all_flags["green"]}</b></td><td style='color:orange'><b>{all_flags["orange"]}</b></td><td style='color:red'><b>{all_flags["red"]}</b></td></tr>
            <tr><td>Train</td><td style='color:green'><b>{train_flags["green"]}</b></td><td style='color:orange'><b>{train_flags["orange"]}</b></td><td style='color:red'><b>{train_flags["red"]}</b></td></tr>
            <tr><td>Test</td><td style='color:green'><b>{test_flags["green"]}</b></td><td style='color:orange'><b>{test_flags["orange"]}</b></td><td style='color:red'><b>{test_flags["red"]}</b></td></tr>
        </table>
        """

        full_html = f"""
        <h4>PowerStat by Factors</h4>
        {signal_html}
        {summary_table}
        <br>
        <h5>PowerStat on All</h5>
        <img src="data:image/png;base64,{img_all}">
        <h5>PowerStat on Train</h5>
        <img src="data:image/png;base64,{img_train}">
        <h5>PowerStat on Test</h5>
        <img src="data:image/png;base64,{img_test}">
        <br>
        <h5>PowerStat Table</h5>
        {render_flag_table(
            self.individual_features_gini.sort_values(by='PowerStat_All', ascending=False)[
                ['Feature', 'Type', 'PowerStat_All', 'PowerStat_Train', 'PowerStat_Test', 'Delta',
                 'PowerStat_All_flag', 'PowerStat_Train_flag', 'PowerStat_Test_flag']
            ],
            flag_col='PowerStat_All_flag',
            float_format='%.2f',
        )}
        """
        _log_text = {'red':'red','orange':'orange','green':'green','orange':'orange','blue':'info','gray':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"DASHBOARD": full_html}
