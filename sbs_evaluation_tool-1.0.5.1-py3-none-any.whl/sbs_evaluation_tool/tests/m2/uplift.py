# core import
from ...core.base_test import BaseModelTest
# default imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from io import BytesIO
import base64
# stat imports
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, roc_curve, auc
from scipy.stats import norm
from scipy import sparse
from scipy.special import expit 
# module imports
import itertools
from typing import List, Dict, Union, Any, Optional

from joblib import Parallel, delayed, parallel_backend

# NEW
from ...core.config_validation import validate_config as _validate_config, ConfigValidationError
from ...core.data_utils import (
    ensure_config,
    split_frames,
    split_sample_masks,
    get_weight_col,
    get_score_col,
    get_features,
    is_binary_mode,
    is_big_data_mode,
    is_generic_classification_mode,
    get_validation_label,
    sample_frame_for_big_data,
)
from ...core.styles import COLORS, STATUS_COLORS, figure
from ...core.metrics import gini, gini_normalized, gini_numba
from .._visual_utils import OBSERVATION_COUNT_LABEL, apply_standard_axis_style, figure_to_base64
import logging
from tqdm import tqdm
logger = logging.getLogger(__name__)

from ._shared import (
    _classification_mode_na,
    powerstat_value,
    gini_one_feature,
    gini_for_features_fast,
    gini_one_categorical_feature,
    gini_for_categorical_features,
    powerstat_one_feature,
    powerstat_for_features_fast,
    powerstat_one_categorical_feature,
    powerstat_for_categorical_features,
    determine_optimal_freq,
    is_glm_preset,
    resolve_feature_columns,
)


class M24_GiniUpliftTest(BaseModelTest):
    """
    Класс для теста M 2.5: Gini Uplift.

    Оценивает инкрементальный прирост Gini при пошаговом добавлении признаков в логистическую регрессию.
    Используется для определения важности факторов в контексте всей модели.

    Общая логика:
        1. Вычисляется индивидуальный Gini каждого признака (или используется из M22).
        2. Строится логистическая модель с признаками, добавляемыми по одному в заданном порядке.
        3. На каждом шаге оценивается прирост Gini на train относительно предыдущего шага.
        4. Признаку присваивается флаг:
            - "green" — если прирост > 0.1%,
            - "orange" — если прирост > 0,
            - "red" — если прирост ≤ 0.
        5. Выводится общий сигнал:
            - "red" — если есть хотя бы один "red" или ≥ 40% признаков "orange",
            - "orange" — если ≥ 20% признаков "orange",
            - "green" — в остальных случаях.
        6. Формируется диаграмма и таблица результатов.

    Атрибуты:
        * test_signal (str): Итоговый сигнал ("green", "orange", "red").

    Методы:
        * compute_uplift_flag(uplift_val): Присваивает флаг признаку по значению прироста Gini.
        * _plot_uplift_bar(df): Строит график прироста Gini (столбики + линии).
        * run(df_train, df_test, target_column, feature_order, n_jobs, m22_test_object): Запускает тест, возвращает HTML-отчёт.
    """
    def __init__(self):
        super().__init__("M 2.4", "PowerStat Uplift")

    def compute_uplift_flag(self, uplift_val:float) -> str:
        """
        Присваивает цветовой флаг в зависимости от величины прироста Gini:
            - "green": прирост > 0.1%
            - "orange": 0% < прирост ≤ 0.1%
            - "red": прирост ≤ 0%

        Параметры:
            * uplift_val (float): Прирост Gini.

        Возвращает:
            * str: Цвет флага.
        """
        if uplift_val > 0.001:
            return "green"
        elif uplift_val > 0:
            return "orange"
        else:
            return 'red'

    @staticmethod
    def _prepare_uplift_plot_frame(df: pd.DataFrame) -> pd.DataFrame:
        plot_df = df.copy()
        if "Single PowerStat" in plot_df.columns:
            plot_df["Single PowerStat Display"] = plot_df["Single PowerStat"].abs()
        if "Single Gini" in plot_df.columns:
            plot_df["Single Gini Display"] = plot_df["Single Gini"].abs()
        return plot_df
         
    def _plot_uplift_bar(self, df: pd.DataFrame) -> str:
        """
        Строит график в стиле PowerStat:
            • Столбики: накопленный Gini Test по модели нарастающим итогом;
              светло-зелёная база = предыдущий уровень, тёмно-зелёная "шапка" = инкрементальный прирост.
            • Линия: Gini одиночного признака (серые точки со ссылкой).

        Параметры:
            * df (pd.DataFrame): Таблица с рассчитанными приростами Gini.

        Возвращает:
            * str: Base64-строка с изображением графика.
        """
        plot_df = self._prepare_uplift_plot_frame(df)
        n = len(plot_df)
        fig_w = max(8.0, min(2.5 + 0.6 * n, 28.0))
        fig, ax = figure(size=(fig_w, 5.8))

        x = np.arange(n)
        model_test_col = "Model Test PowerStat" if "Model Test PowerStat" in plot_df.columns else "Model Test Gini"
        uplift_col = "PowerStat Uplift" if "PowerStat Uplift" in plot_df.columns else "Gini Uplift"
        single_display_col = (
            "Single PowerStat Display"
            if "Single PowerStat Display" in plot_df.columns
            else "Single Gini Display"
        )
        # Накопленные значения Gini Test по шагах (в df уже в %)
        cum_test = plot_df[model_test_col].to_numpy()
        prev_test = np.concatenate([[0.0], cum_test[:-1]])
        uplift = plot_df[uplift_col].to_numpy()

        # База (предыдущий уровень)
        ax.bar(x, prev_test, color=COLORS['EMERALD'], alpha=0.26, width=0.8)
        # Шапка (инкремент)
        ax.bar(x, uplift, bottom=prev_test, color=COLORS['GREEN'], width=0.8, label="Increment")

        # Линия одиночного Gini (точки серые)
        ax.plot(
            x,
            plot_df[single_display_col],
            color=COLORS['BLUE'],
            marker="o",
            markersize=5.5,
            linewidth=1.8,
            label="Single PowerStat",
        )

        # Оси/подписи
        short_labels = [(f[:22] + "…") if len(f) > 25 else f for f in df["Feature"]]
        short_labels = [(f[:22] + "...") if len(f) > 25 else f for f in plot_df["Feature"]]
        ax.set_xticks(x)
        ax.set_xticklabels(short_labels, rotation=45, ha="right", fontsize=8)
        apply_standard_axis_style(
            ax,
            title="Incremental PowerStat Gain by Sequential Feature Addition",
            ylabel="PowerStat, %",
            legend_loc="upper left",
            title_size=12,
        )
        fig.tight_layout(pad=1.2)

        # ----- экспорт --------------------------------------------------------
        buf = BytesIO()
        plt.savefig(buf, format="png", dpi=150)
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode()

    def _run_glm_uplift(self, df_all: pd.DataFrame, features: List[str],
                         target_column: str, cfg) -> Dict[str, str]:
        """GLM-preset PowerStat uplift on the whole dataset (genpop).

        Methodology M 2.4 for multiplicative Poisson GLMs (log link):

        * Rank factors by individual PowerStat (descending).
        * At each step ``k = 1..n`` refit a Poisson GLM with
          ``offset = log(EXP)`` on the design matrix
          ``log(SCORING_1..k)``. The fitted ``β_j`` differ from the
          original tariff's coefficients because here we deliberately drop
          some factors and let MLE re-balance the rest.
        * The model score at step ``k`` is the predicted **rate**
          ``exp(X β)`` (offset removed), and PowerStat is computed against
          ``y = CLAIM_COUNT`` weighted by ``EXP``.
        * Incremental uplift at step ``k`` is
          ``model_PS_k − model_PS_{k-1}``.

        This matches the reference uplift table the upstream validation
        system ships (within ~0.03 pp ``np.trapz`` precision noise).
        """
        import statsmodels.api as sm

        weight_col = getattr(cfg.columns, 'weight_column', None)
        y = pd.to_numeric(df_all[target_column], errors='raise').to_numpy(dtype=float)
        if not (weight_col and weight_col in df_all.columns):
            raise ConfigValidationError(
                ["M 2.4 GLM uplift needs an exposure column (weight_column) for the Poisson offset."]
            )
        w = pd.to_numeric(df_all[weight_col], errors='raise').to_numpy(dtype=float)
        # Guard against zero/negative exposure rows leaking into log().
        valid = (w > 0) & np.isfinite(w) & np.isfinite(y)
        for f in features:
            if f in df_all.columns:
                valid &= np.isfinite(pd.to_numeric(df_all[f], errors='raise').to_numpy(dtype=float))
                valid &= pd.to_numeric(df_all[f], errors='raise').to_numpy(dtype=float) > 0
        y = y[valid]
        w = w[valid]
        offset = np.log(w)
        scoring_arrays = {
            f: pd.to_numeric(df_all[f], errors='raise').to_numpy(dtype=float)[valid]
            for f in features if f in df_all.columns
        }

        # Individual PowerStat per feature on the full dataset (raw SCORING).
        ind_ps = {f: powerstat_value(y, scoring_arrays[f], weight=w) * 100.0
                  for f in scoring_arrays}

        # Order by individual PS desc.
        ordered_feats = [f for f, _ in sorted(ind_ps.items(), key=lambda kv: kv[1], reverse=True)]

        # Step 0 — intercept only (constant ⇒ ranking is undefined ⇒ PS = 0).
        records = [{
            "Step": 0,
            "Factor": "intercept",
            "Individual PowerStat": 0.0,
            "Model PowerStat": 0.0,
            "Uplift": np.nan,
        }]

        prev_model_ps = 0.0
        for step, feat in enumerate(ordered_feats, start=1):
            cols_so_far = ordered_feats[:step]
            log_X = np.column_stack([np.log(scoring_arrays[c]) for c in cols_so_far])
            X = sm.add_constant(log_X)
            try:
                glm_fit = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset).fit(maxiter=100, disp=0)
                Xb = X @ glm_fit.params
                rate = np.exp(Xb)  # predicted rate (per-policy, no exposure multiplier)
            except Exception as e:
                logger.warning("M 2.4 step %d (%s) Poisson GLM fit failed: %s — skipping.", step, feat, e)
                rate = np.full_like(y, np.nan)
            model_ps = powerstat_value(y, rate, weight=w) * 100.0
            uplift = model_ps - prev_model_ps
            records.append({
                "Step": step,
                "Factor": feat,
                "Individual PowerStat": ind_ps[feat],
                "Model PowerStat": model_ps,
                "Uplift": uplift,
            })
            prev_model_ps = model_ps

        df_result = pd.DataFrame.from_records(records)
        # Plot uses the existing helper's column names — build a compatibility frame.
        plot_df = df_result.iloc[1:].copy()  # exclude intercept row from the bar chart
        plot_df = plot_df.rename(columns={
            "Factor": "Feature",
            "Individual PowerStat": "Single PowerStat",
            "Model PowerStat": "Model Test PowerStat",
            "Uplift": "PowerStat Uplift",
        })
        plot_df["Type"] = "numeric"
        encoded_plot = self._plot_uplift_bar(plot_df)

        self.test_signal = "blue"

        # Format the table: Step / Factor / individual / cumulative model / uplift.
        display = df_result.copy()
        for c in ("Individual PowerStat", "Model PowerStat", "Uplift"):
            display[c] = display[c].apply(lambda v: "-" if pd.isna(v) else f"{v:.4f}")
        # Rename columns for the rendered table.
        display = display.rename(columns={
            "Individual PowerStat": "Individual PowerStat, %",
            "Model PowerStat": "Model PowerStat (cumulative), %",
            "Uplift": "PowerStat Uplift, %",
        })

        html = f"""
        <h4>PowerStat Uplift (GLM multiplicative)</h4>
        <p><b>Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>INFO</span></p>
        <p><i>Score at step k = Π SCORING_i over the top-k factors ordered by individual PowerStat. Computed on the whole dataset (genpop).</i></p>
        <img src="data:image/png;base64,{encoded_plot}" style="display:block; width:100%; max-width:1100px; height:auto;">
        <h5>Details</h5>
        {display.to_html(index=False, escape=False)}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}

    def run(self, df: pd.DataFrame, config: dict, n_jobs=-1, m22_test_object: "M22_GiniFactorsTest" = None) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        if is_generic_classification_mode(cfg):
            self.test_signal = "blue"
            return _classification_mode_na(self.test_name)
        target_column = cfg.columns.target_column

        # Получаем и численные, и категориальные признаки
        num_features = cfg.columns.numeric_features or []
        cat_features = cfg.columns.categorical_features or []

        # GLM-пресет: M2.4 (uplift) считается по multiplicative _SCORING-колонкам.
        if is_glm_preset(cfg):
            resolved = resolve_feature_columns(
                df, num_features + cat_features,
                kind="scoring", cfg=cfg, test_code=self.test_code,
            )
            num_features = resolved
            cat_features = []

        all_features = num_features + cat_features
        weight_col = getattr(cfg.columns, 'weight_column', None)
        if is_big_data_mode(cfg):
            train_mask, test_mask = split_sample_masks(df, cfg)
            needed_cols = all_features + [target_column, weight_col]
            needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
            df_small = df.loc[:, needed_cols]
            df_train = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=150_000, random_state=241).copy()
            df_test = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=150_000, random_state=242).copy()
            df_all = sample_frame_for_big_data(df_small, cfg, max_rows=250_000, random_state=243).copy()
        else:
            df_train, df_test, df_all = split_frames(df, cfg)

        if is_glm_preset(cfg):
            return self._run_glm_uplift(df_all, num_features, target_column, cfg)

        if not all_features:
            raise ConfigValidationError(["Для M 2.5 требуется непустой список columns.numeric_features или columns.categorical_features"])

        # Проверки типов/NaN для численных признаков
        for column in num_features + [target_column]:
            if not pd.api.types.is_numeric_dtype(df_train[column]) or not pd.api.types.is_numeric_dtype(df_test[column]):
                try:
                    df_train[column] = pd.to_numeric(df_train[column], errors='raise')
                    df_test[column] = pd.to_numeric(df_test[column], errors='raise')
                except ValueError:
                    raise ValueError(f"Column {column} must be numeric.")
        if df_train[target_column].isnull().any() or df_test[target_column].isnull().any():
            raise ValueError("Target contains missing values.")
        
        # Проверки для категориальных признаков
        for column in cat_features:
            if df_train[column].isnull().any() or df_test[column].isnull().any():
                raise ValueError(f"Categorical column {column} contains missing values.")

        # Экспозиция учитывается в PowerStat по методике (Замечание после M 2.1)
        weight_col = getattr(cfg.columns, 'weight_column', None)

        # Получаем individual gini из M22 или считаем заново
        if m22_test_object and not m22_test_object.individual_features_gini.empty:
            self.individual_features_gini = m22_test_object.individual_features_gini
        else:
            # Считаем заново
            records_numeric = []
            if num_features:
                records_numeric = powerstat_for_features_fast(
                    df_tr=df_train,
                    df_te=df_test,
                    target=target_column,
                    features=num_features,
                    n_jobs=n_jobs,
                    weight=weight_col,
                )

            records_categorical = []
            if cat_features:
                records_categorical = powerstat_for_categorical_features(
                    df_tr=df_train,
                    df_te=df_test,
                    target=target_column,
                    features=cat_features,
                    n_jobs=n_jobs,
                    weight=weight_col,
                )
            
            all_records = records_numeric + records_categorical
            self.individual_features_gini = pd.DataFrame(
                all_records, 
                columns=["Feature", "PowerStat_Train", "PowerStat_Test", "Delta"]
            )

        # Упорядочим признаки по убыванию индивидуального Gini (Train)
        order_df = self.individual_features_gini.sort_values(by="PowerStat_Train", ascending=False)
        ordered_features = [f for f in order_df["Feature"].tolist() if f in all_features]

        # Создаем маппинг: какой признак численный, какой категориальный
        feature_type_map = {}
        for f in num_features:
            feature_type_map[f] = 'numeric'
        for f in cat_features:
            feature_type_map[f] = 'categorical'

        # Подготавливаем данные: будем строить матрицу пошагово
        y_tr = df_train[target_column].to_numpy(np.float32)
        y_ts = df_test[target_column].to_numpy(np.float32)
        w_tr = df_train[weight_col].to_numpy(np.float32) if weight_col and weight_col in df_train.columns else None
        w_ts = df_test[weight_col].to_numpy(np.float32) if weight_col and weight_col in df_test.columns else None

        # Создаем энкодинг для категориальных признаков (mean target encoding)
        categorical_encodings = {}
        for cat_feat in cat_features:
            encoding_map = df_train.groupby(cat_feat)[target_column].mean().to_dict()
            global_mean = df_train[target_column].mean()
            categorical_encodings[cat_feat] = (encoding_map, global_mean)

        # Функция для получения закодированного признака
        def get_encoded_feature(feat_name, df_tr_local, df_te_local):
            if feature_type_map[feat_name] == 'numeric':
                return (
                    df_tr_local[feat_name].to_numpy(np.float32),
                    df_te_local[feat_name].to_numpy(np.float32)
                )
            else:
                # Категориальный: применяем mean encoding
                encoding_map, global_mean = categorical_encodings[feat_name]
                tr_encoded = df_tr_local[feat_name].map(encoding_map).fillna(global_mean).to_numpy(np.float32)
                te_encoded = df_te_local[feat_name].map(encoding_map).fillna(global_mean).to_numpy(np.float32)
                return tr_encoded, te_encoded

        # Собираем полную матрицу для обучения модели
        X_tr_list = []
        X_ts_list = []
        for feat in ordered_features:
            tr_feat, ts_feat = get_encoded_feature(feat, df_train, df_test)
            X_tr_list.append(tr_feat)
            X_ts_list.append(ts_feat)
        
        X_tr_full = np.column_stack(X_tr_list).astype(np.float32)
        X_ts_full = np.column_stack(X_ts_list).astype(np.float32)

        records = []

        if is_binary_mode(cfg):
            # Логистическая регрессия с инкрементальным добавлением признаков
            model = LogisticRegression(solver='saga', max_iter=1000)
            model.fit(X_tr_full, y_tr)
            beta0 = np.float32(model.intercept_[0])
            betas = model.coef_[0].astype(np.float32)
            logits_tr = np.full(len(X_tr_full), beta0, dtype=np.float32)
            logits_ts = np.full(len(X_ts_full), beta0, dtype=np.float32)

            for i, feat in tqdm(list(enumerate(ordered_features)), desc="M 2.4 - Logistic steps", total=len(ordered_features)):
                logits_tr += X_tr_full[:, i] * betas[i]
                logits_ts += X_ts_full[:, i] * betas[i]
                pred_tr = expit(logits_tr)
                pred_ts = expit(logits_ts)
                ps_tr = powerstat_value(y_tr, pred_tr, weight=w_tr)
                ps_ts = powerstat_value(y_ts, pred_ts, weight=w_ts)
                uplift = ps_tr - records[i - 1][3] / 100 if i > 0 else ps_tr
                uplift_flag = self.compute_uplift_flag(uplift)
                ps_single = self.individual_features_gini[self.individual_features_gini["Feature"] == feat]["PowerStat_Train"].iloc[0] / 100
                feat_type = feature_type_map[feat]
                records.append((feat, feat_type, ps_ts * 100, ps_tr * 100, abs(ps_single) * 100, uplift * 100, uplift_flag))
        else:
            # Регрессия: пошаговое обучение LinearRegression
            scaler = StandardScaler(with_mean=True, with_std=True)
            X_tr_scaled = scaler.fit_transform(X_tr_full)
            X_ts_scaled = scaler.transform(X_ts_full)
            
            for i, feat in tqdm(list(enumerate(ordered_features)), desc="M 2.4 - Linear steps", total=len(ordered_features)):
                lr = LinearRegression(n_jobs=n_jobs) if hasattr(LinearRegression(), 'n_jobs') else LinearRegression()
                Xtr = X_tr_scaled[:, : i + 1]
                Xts = X_ts_scaled[:, : i + 1]
                lr.fit(Xtr, y_tr)
                pred_tr = lr.predict(Xtr)
                pred_ts = lr.predict(Xts)
                ps_tr = powerstat_value(y_tr, pred_tr, weight=w_tr)
                ps_ts = powerstat_value(y_ts, pred_ts, weight=w_ts)
                uplift = ps_tr - records[i - 1][3] / 100 if i > 0 else ps_tr
                uplift_flag = self.compute_uplift_flag(uplift)
                ps_single = self.individual_features_gini[self.individual_features_gini["Feature"] == feat]["PowerStat_Train"].iloc[0] / 100 if not self.individual_features_gini.empty else 0.0
                feat_type = feature_type_map[feat]
                records.append((feat, feat_type, ps_ts * 100, ps_tr * 100, abs(ps_single) * 100, uplift * 100, uplift_flag))

        df_result = pd.DataFrame(
            records, 
            columns=["Feature", "Type", "Model Test PowerStat", "Model Train PowerStat", "Single PowerStat", "PowerStat Uplift", "Uplift Signal"]
        )

        # График прироста
        encoded_plot = self._plot_uplift_bar(df_result)
        
        self.test_signal = "blue"

        html = f"""
        <h4>PowerStat Uplift</h4>
        <p><b>Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>INFO</span></p>
        <p><i>Numeric features: {len(num_features)}, categorical features: {len(cat_features)}</i></p>
        <p><i>This test is informational and shows the sequential incremental PowerStat contribution of each factor.</i></p>
        <p><i>Categorical features are encoded via mean target encoding.</i></p>
        <img src="data:image/png;base64,{encoded_plot}" style="display:block; width:100%; max-width:1100px; height:auto;">
        <h5>Details</h5>
        {df_result.to_html(index=False, float_format="%.2f")}
        """
        _log_text = {'red':'red','orange':'orange','green':'green','orange':'orange','blue':'info','gray':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}
