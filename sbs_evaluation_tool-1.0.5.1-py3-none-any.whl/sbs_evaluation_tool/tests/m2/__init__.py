"""Per-sub-test modules for SBS M2 Gini.

This package was carved out of the original monolithic ``tests/m2_gini_tests.py``
(1676 lines, four test classes plus helpers). The public class names are
re-exported here so any consumer that historically imported from
``sbs_evaluation_tool.tests.m2_gini_tests`` keeps working.

Module layout:
    _shared.py    module-level helpers shared across all sub-tests
    overall.py    M21_GiniTest        (M 2.1)
    factors.py    M22_GiniFactorsTest (M 2.2)
    dynamics.py   M23_GiniDynamicsTest (M 2.3)
    uplift.py     M24_GiniUpliftTest   (M 2.4)
"""

from .overall import M21_GiniTest
from .factors import M22_GiniFactorsTest
from .dynamics import M23_GiniDynamicsTest
from .uplift import M24_GiniUpliftTest

__all__ = [
    "M21_GiniTest",
    "M22_GiniFactorsTest",
    "M23_GiniDynamicsTest",
    "M24_GiniUpliftTest",
]
