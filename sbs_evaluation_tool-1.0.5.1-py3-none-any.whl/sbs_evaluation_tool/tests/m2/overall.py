# core import
from ...core.base_test import BaseModelTest
# default imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from io import BytesIO
import base64
# stat imports
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, roc_curve, auc
from scipy.stats import norm
from scipy import sparse
from scipy.special import expit 
# module imports
import itertools
from typing import List, Dict, Union, Any, Optional

from joblib import Parallel, delayed, parallel_backend

# NEW
from ...core.config_validation import validate_config as _validate_config, ConfigValidationError
from ...core.data_utils import (
    ensure_config,
    split_frames,
    split_sample_masks,
    get_weight_col,
    get_score_col,
    get_features,
    is_binary_mode,
    is_big_data_mode,
    is_generic_classification_mode,
    get_validation_label,
    sample_frame_for_big_data,
)
from ...core.styles import COLORS, STATUS_COLORS, figure
from ...core.metrics import gini, gini_normalized, gini_numba
from ...core.render_context import get_render_mode
from .._visual_utils import OBSERVATION_COUNT_LABEL, apply_standard_axis_style, figure_to_base64
import logging
from tqdm import tqdm
logger = logging.getLogger(__name__)

from ._shared import (
    _classification_mode_na,
    powerstat_value,
    gini_one_feature,
    gini_for_features_fast,
    gini_one_categorical_feature,
    gini_for_categorical_features,
    powerstat_one_feature,
    powerstat_for_features_fast,
    powerstat_one_categorical_feature,
    powerstat_for_categorical_features,
    determine_optimal_freq,
)


class M21_GiniTest(BaseModelTest): 
    """
    Класс для теста M 2.1: Gini Test.

    Проверяет общую способность модели к ранжированию, вычисляя коэффициент Gini 
    для обучающей и тестовой выборки, строит ROC-кривые и визуализирует результаты.
    Выдаёт итоговый сигнал (зелёный, жёлтый или красный) на основе порогов качества.

    Наследует:
        BaseModelTest: Базовый класс для всех модельных тестов.

    Атрибуты:
        * test_signal (str): Итоговый цветовой сигнал ("green", "orange", "red"),
          рассчитывается на основе значений Gini на train и test.

    Методы:
        * compute_gini(score, target): Вычисляет коэффициент Gini.
        * compute_gini_html(score, target, label): Строит ROC-кривую, возвращает HTML с Gini и графиком.
        * compute_signal(gini_train, gini_test): Определяет сигнал по значениям Gini.
        * run(score_train, target_train, score_test, target_test): Основной метод, запускающий тест.
    """ 
    def __init__(self):
        super().__init__("M 2.1", "Gini Test")

    def compute_gini(
        self,
        score: pd.Series,
        target: pd.Series,
        weight: Optional[pd.Series] = None,
    ) -> float:
        """Wrapper around :func:`core.metrics.gini` preserved for backwards compatibility.

        Coerces ``weight`` to numeric and drops it when the resulting total
        is non-positive, then delegates to the canonical metric.
        """
        w = None
        if weight is not None:
            w_num = pd.to_numeric(weight, errors="coerce").fillna(0.0).to_numpy()
            if (w_num > 0).any():
                w = w_num
        return float(gini(target, score, sample_weight=w))

    def compute_gini_html(
        self,
        score: pd.Series,
        target: pd.Series,
        label: str,
        weight: Optional[pd.Series] = None,
    ) -> str:
        """
        Строит ROC-кривую и вычисляет Gini/AUC, возвращает HTML-блок с графиком.

        Параметры:
            * score (pd.Series): Series с предсказанными значениями модели.
            * target (pd.Series): Series с фактическими бинарными метками (0/1).
            * label (str): Метка для подписи графика (например, "Train" или "Test").
            * weight (pd.Series, optional): Веса (экспозиция). Если заданы, ROC/AUC считаются взвешенно.

        Возвращает:
            * str: HTML-строка с коэффициентом Gini и изображением ROC-кривой.

        Исключения:
            * ValueError: Если столбец не является числовым и перевод в числовой тип невозможен.
            * ValueError: Если столбец содержит пропущенные значения.
        """
        # Проверяем, что данные можно перевести в числовой формат
        for col_name, col_series in zip(['score', 'target'], [score, target]):
            if not pd.api.types.is_numeric_dtype(col_series):
                try:
                    col_series = pd.to_numeric(col_series, errors='raise')
                except ValueError:
                    raise ValueError(f"Столбец {col_name} не является числовым. Перевод в числовой тип невозможен.")
            if col_series.isnull().any():
                raise ValueError(f"Столбец {col_name} содержит пропущенные значения.")

        w = None
        if weight is not None:
            w = pd.to_numeric(weight, errors="coerce").fillna(0.0)
            if (w > 0).sum() == 0:
                w = None

        auc = roc_auc_score(target, score, sample_weight=w)
        gini = 2 * auc - 1

        fpr, tpr, _ = roc_curve(target, score, sample_weight=w)
        fig, ax = figure(size="small")
        ax.plot(fpr, tpr, label=f"{label} ROC (AUC = {auc:.4f})")
        ax.plot([0, 1], [0, 1], '--', color=COLORS['GRAY'])
        ax.set_xlabel("False Positive Rate")
        ax.set_ylabel("True Positive Rate")
        ax.set_title(f"ROC Curve - {label}")
        ax.legend()
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)
        encoded = base64.b64encode(buf.getvalue()).decode()

        return gini, f"""
        <h4>{label} Gini</h4>
        <p><b>Gini:</b> {gini:.4f}</p>
        <img src="data:image/png;base64,{encoded}">
        """

    def compute_powerstat_html(self, score: pd.Series, target: pd.Series, label: str) -> tuple[float, str]:
        """
        Строит кумулятивные кривые (идеальная, модельная и случайная) и вычисляет PowerStat.

        PowerStat = (A_model - A_random) / (A_ideal - A_random),
        где A_random = 0.5 — площадь под y=x.
        Работает и для классификации (0/1), и для регрессии (неотрицательная целевая).
        Возвращает кортеж (powerstat, html).
        """
        # Приведение к численным и проверка пропусков
        y = pd.to_numeric(target, errors='raise')
        s = pd.to_numeric(score, errors='raise')
        if y.isnull().any() or s.isnull().any():
            raise ValueError("Столбцы score/target содержат пропуски.")

        # Превращаем в numpy для скорости
        y_np = y.to_numpy(dtype=float, copy=False)
        s_np = s.to_numpy(dtype=float, copy=False)
        n = y_np.shape[0]
        if n == 0:
            return 0.0, "<p>Нет данных для расчёта PowerStat.</p>"
        total = float(np.sum(y_np))
        if total <= 0:
            # Если целевая сумма нулевая — все кривые совпадут с 0; PowerStat неинформативен
            return 0.0, "<p>Сумма целевой переменной равна 0 — PowerStat = 0.</p>"

        # Подготовим вспомогательную функцию
        def cum_curve(y_vals: np.ndarray, order_idx: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
            y_sorted = y_vals[order_idx]
            cum_y = np.cumsum(y_sorted)
            x = np.arange(1, len(y_sorted) + 1, dtype=float) / len(y_sorted)
            y_share = cum_y / total
            # Добавим начало (0,0)
            x = np.concatenate([[0.0], x])
            y_share = np.concatenate([[0.0], y_share])
            return x, y_share

        # Идеальная кривая: сортировка по убыванию факта
        idx_ideal = np.argsort(-y_np)
        x_ideal, y_ideal = cum_curve(y_np, idx_ideal)

        # Модельная кривая: сортировка по убыванию прогноза
        idx_model = np.argsort(-s_np)
        x_model, y_model = cum_curve(y_np, idx_model)

        # Случайная кривая: y=x, площадь 0.5
        x_rand = np.array([0.0, 1.0])
        y_rand = np.array([0.0, 1.0])

        # Площади под кривыми
        a_ideal = float(np.trapz(y_ideal, x_ideal))
        a_model = float(np.trapz(y_model, x_model))
        a_random = 0.5
        denom = (a_ideal - a_random)
        if denom <= 0:
            powerstat = 0.0
        else:
            powerstat = max(0.0, min(1.0, (a_model - a_random) / denom))

        # Визуализация в корпоративных цветах
        fig, ax = figure(size="small")
        ax.fill_between(x_model, y_model, color=COLORS['EMERALD'], alpha=0.14)
        ax.plot(x_model, y_model, color=COLORS['EMERALD'], linewidth=2.4, label='Model')
        ax.plot(x_rand, y_rand, '--', color=COLORS['GRAY'], linewidth=1.4, label='Random baseline')

        # Доп. оформление
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        apply_standard_axis_style(
            ax,
            title=f"PowerStat Curve - {label}",
            xlabel='Cumulative Share of Observations',
            ylabel='Cumulative Share of Target Sum',
            legend_loc='lower right',
        )
        fig.tight_layout(pad=1.1)
        encoded = figure_to_base64(fig)
        plt.close(fig)

        html = f"""
        <h5>PowerStat - {label}</h5>
        <p><b>PowerStat:</b> {powerstat:.4f}</p>
        <img src="data:image/png;base64,{encoded}" style="display:block; width:100%; max-width:860px; height:auto;">
        """
        return powerstat, html

    def compute_reg_gini_html(
        self,
        score: pd.Series,
        target: pd.Series,
        label: str,
        weight: Optional[pd.Series] = None,
    ) -> str:
        """
        Регрессионный вариант: считает нормализованный Gini и строит простую кривую Лоренца.

        Возвращает кортеж (gini, html).
        """
        # проверки типов/NaN
        for col_name, col_series in zip(['score', 'target'], [score, target]):
            if not pd.api.types.is_numeric_dtype(col_series):
                try:
                    col_series = pd.to_numeric(col_series, errors='raise')
                except ValueError:
                    raise ValueError(f"Столбец {col_name} не является числовым. Перевод в числовой тип невозможен.")
            if col_series.isnull().any():
                raise ValueError(f"Столбец {col_name} содержит пропущенные значения.")

        # Нормализованный Gini (при наличии весов считаем взвешенно)
        w = None
        if weight is not None:
            w = pd.to_numeric(weight, errors="coerce").fillna(0.0).to_numpy()
            if (w > 0).sum() == 0:
                w = None
        gini = float(gini_normalized(np.asarray(target), np.asarray(score), sample_weight=w))

        # Построим кривую Лоренца для наглядности
        order = np.argsort(score)
        y_sorted = np.asarray(target)[order]
        n = len(y_sorted)
        total = y_sorted.sum()
        if weight is not None:
            w_sorted = w[order] if w is not None else None
            total_w = w_sorted.sum() if w_sorted is not None else 0.0
            pop_share = np.cumsum(w_sorted) / total_w if total_w > 0 else np.zeros_like(y_sorted, dtype=float)
            if total == 0 or total_w == 0:
                lorenz = np.zeros_like(pop_share)
            else:
                lorenz = np.cumsum(y_sorted * w_sorted) / np.sum(y_sorted * w_sorted)
        else:
            pop_share = np.arange(1, n + 1) / n
            if total == 0:
                lorenz = np.zeros_like(pop_share)
            else:
                lorenz = np.cumsum(y_sorted) / total

        fig, ax = figure(size="small")
        ax.plot(pop_share, lorenz, label="Lorenz curve", color=COLORS['EMERALD'])
        ax.plot([0, 1], [0, 1], '--', color=COLORS['GRAY'], label="Equality")
        ax.set_xlabel("Population share")
        ax.set_ylabel("Cumulative target share")
        ax.set_title(f"Lorenz Curve - {label}")
        ax.legend()
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)
        encoded = base64.b64encode(buf.getvalue()).decode()

        return gini, f"""
        <h4>{label} Normalized Gini (Regression)</h4>
        <p><b>Gini:</b> {gini:.4f}</p>
        <img src="data:image/png;base64,{encoded}">
        """

    def compute_signal(self, gini_test: float) -> str:
        """
        Итоговый сигнал зависит только от качества на тесте:
          - "red"    если Gini_test < 0.20
          - "orange" если 0.20 ≤ Gini_test < 0.35
          - "green"  если Gini_test ≥ 0.35

        Параметры:
            * gini_test (float): Значение Gini на тестовой выборке (0..1).

        Возвращает:
            * str: "red" | "orange" | "green".
        """
        if gini_test < 0.20:
            return "red"
        elif gini_test < 0.35:
            return "orange"
        return "green"

    def _plot_combined_gini(self, g_train: float, g_test: float) -> str:
        """
        Рисует один график со значениями Gini для Train и Test и референс-линией Gini=0.20 (красный пунктир).

        Возвращает base64 PNG.
        """
        # Цвет теста по правилам светофора
        if g_test < 0.20:
            test_color = 'red'
        elif g_test < 0.35:
            test_color = 'orange'  # используем оранжевый как жёлтый
        else:
            test_color = 'green'

        fig, ax = figure(size="small")
        labels = ["Train", "Test"]
        values = [g_train, g_test]
        colors = [COLORS['BLUE'], COLORS['EMERALD']]

        bars = ax.bar(labels, values, color=colors, alpha=0.85)

        # Подписи значений над столбцами
        for rect, val in zip(bars, values):
            ax.annotate(f"{val:.3f}",
                        xy=(rect.get_x() + rect.get_width() / 2, rect.get_height()),
                        xytext=(0, 6),
                        textcoords="offset points",
                        ha='center', va='bottom', fontsize=9, fontweight='bold')

        # Референс-линия Gini=0.20 (красный пунктир)
        ax.axhline(y=0.20, color=STATUS_COLORS['red'], linestyle='--', linewidth=1.5, label='Red threshold = 0.20')
        ax.axhline(y=0.35, color=STATUS_COLORS['orange'], linestyle='--', linewidth=1.5, label='Orange threshold = 0.35')

        # Оформление
        ax.set_ylim(0, max(0.45, max(values) * 1.22))
        apply_standard_axis_style(
            ax,
            title='Overall Gini: Train vs Test',
            ylabel='Gini (0..1)',
            legend_loc='upper left',
        )
        fig.tight_layout(pad=1.1)
        encoded = figure_to_base64(fig)
        plt.close(fig)
        return encoded

    def _plot_roc_both(
        self,
        y_train: pd.Series,
        s_train: pd.Series,
        y_test: pd.Series,
        s_test: pd.Series,
        w_train: Optional[pd.Series] = None,
        w_test: Optional[pd.Series] = None,
    ) -> tuple[str, float, float]:
        """
        Строит один график c ROC-кривыми для Train и Test (только для classification).
        Возвращает base64 PNG.
        """
        w_tr = None
        if w_train is not None:
            w_tr = pd.to_numeric(w_train, errors="coerce").fillna(0.0)
            if (w_tr > 0).sum() == 0:
                w_tr = None
        w_te = None
        if w_test is not None:
            w_te = pd.to_numeric(w_test, errors="coerce").fillna(0.0)
            if (w_te > 0).sum() == 0:
                w_te = None

        fpr_tr, tpr_tr, _ = roc_curve(y_train, s_train, sample_weight=w_tr)
        auc_tr = roc_auc_score(y_train, s_train, sample_weight=w_tr)
        fpr_te, tpr_te, _ = roc_curve(y_test, s_test, sample_weight=w_te)
        auc_te = roc_auc_score(y_test, s_test, sample_weight=w_te)

        fig, ax = figure(size="small")
        # Закрашиваем площадь под кривыми для наглядности ROC-AUC
        ax.fill_between(fpr_tr, tpr_tr, alpha=0.15, color=COLORS['BLUE'])
        ax.fill_between(fpr_te, tpr_te, alpha=0.15, color=COLORS['EMERALD'])
        ax.plot(fpr_tr, tpr_tr, label=f"Train ROC (AUC={auc_tr:.3f})", color=COLORS['BLUE'])
        ax.plot(fpr_te, tpr_te, label=f"Test ROC (AUC={auc_te:.3f})", color=COLORS['EMERALD'])
        ax.plot([0, 1], [0, 1], '--', color=COLORS['GRAY'], linewidth=1)
        ax.set_xlabel("False Positive Rate")
        ax.set_ylabel("True Positive Rate")
        ax.set_title("ROC-AUC - Train vs Test")
        ax.legend(loc="lower right")
        ax.grid(True, linestyle='--', alpha=0.3)
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png", dpi=150)
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode(), float(auc_tr), float(auc_te)

    def _plot_roc_both_plotly(
        self,
        y_train: pd.Series,
        s_train: pd.Series,
        y_test: pd.Series,
        s_test: pd.Series,
        w_train: Optional[pd.Series] = None,
        w_test: Optional[pd.Series] = None,
    ) -> tuple[str, float, float]:
        """Plotly-вариант ROC для Train/Test. Возвращает (html_div, auc_tr, auc_te)."""
        import plotly.graph_objects as go

        w_tr = None
        if w_train is not None:
            w_tr = pd.to_numeric(w_train, errors="coerce").fillna(0.0)
            if (w_tr > 0).sum() == 0:
                w_tr = None
        w_te = None
        if w_test is not None:
            w_te = pd.to_numeric(w_test, errors="coerce").fillna(0.0)
            if (w_te > 0).sum() == 0:
                w_te = None

        fpr_tr, tpr_tr, _ = roc_curve(y_train, s_train, sample_weight=w_tr)
        auc_tr = roc_auc_score(y_train, s_train, sample_weight=w_tr)
        fpr_te, tpr_te, _ = roc_curve(y_test, s_test, sample_weight=w_te)
        auc_te = roc_auc_score(y_test, s_test, sample_weight=w_te)

        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=fpr_tr, y=tpr_tr, mode="lines",
            name=f"Train (AUC={auc_tr:.3f})",
            line=dict(color=COLORS['BLUE'], width=2),
            fill="tozeroy", fillcolor="rgba(31,119,180,0.12)",
            hovertemplate="FPR=%{x:.3f}<br>TPR=%{y:.3f}<extra>Train</extra>",
        ))
        fig.add_trace(go.Scatter(
            x=fpr_te, y=tpr_te, mode="lines",
            name=f"Test (AUC={auc_te:.3f})",
            line=dict(color=COLORS['EMERALD'], width=2),
            fill="tozeroy", fillcolor="rgba(33,186,114,0.12)",
            hovertemplate="FPR=%{x:.3f}<br>TPR=%{y:.3f}<extra>Test</extra>",
        ))
        fig.add_trace(go.Scatter(
            x=[0, 1], y=[0, 1], mode="lines",
            line=dict(color=COLORS['GRAY'], dash="dash", width=1),
            name="Chance", hoverinfo="skip",
        ))
        fig.update_layout(
            title=dict(text="ROC-AUC — Train vs Test", font=dict(size=15)),
            template="plotly_white",
            xaxis=dict(title="False Positive Rate", range=[0, 1]),
            yaxis=dict(title="True Positive Rate", range=[0, 1], scaleanchor="x", scaleratio=1),
            legend=dict(x=0.55, y=0.05, bgcolor="rgba(255,255,255,0.7)"),
            margin=dict(l=60, r=40, t=70, b=60),
            height=460,
        )
        html = fig.to_html(include_plotlyjs="cdn", full_html=False, config={"displaylogo": False})
        return html, float(auc_tr), float(auc_te)

    def _plot_auc_bars(self, auc_tr: float, auc_te: float) -> str:
        """Простой столбиковый график ROC-AUC для Train/Test."""
        fig, ax = figure(size="small")
        labels = ["Train", "Test"]
        vals = [auc_tr, auc_te]
        colors = [COLORS['BLUE'], COLORS['EMERALD']]
        bars = ax.bar(labels, vals, color=colors, alpha=0.85)
        for r, v in zip(bars, vals):
            ax.annotate(f"{v:.3f}", (r.get_x() + r.get_width()/2, r.get_height()),
                        xytext=(0, 6), textcoords="offset points",
                        ha='center', va='bottom', fontsize=9, fontweight='bold')
        ax.set_ylim(0, max(1.0, max(vals) * 1.05))
        ax.set_ylabel("ROC-AUC (0..1)")
        ax.set_title("ROC-AUC values")
        ax.grid(True, axis='y', linestyle='--', alpha=0.3)
        plt.tight_layout()
        encoded = figure_to_base64(fig)
        plt.close(fig)
        return encoded

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        """M 2.1 — Overall Gini & PowerStat.

        Возвращает одну компактную таблицу с шестью числами: Gini и PowerStat,
        каждое в трёх разрезах — overall (вся выборка), train, test. Никаких графиков,
        никаких threshold-легенд: сравнение чисел читается напрямую.
        """
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        if is_generic_classification_mode(cfg):
            self.test_signal = "blue"
            return _classification_mode_na(self.test_name)
        target_col = cfg.columns.target_column
        score_col = get_score_col(cfg)
        weight_col = getattr(cfg.columns, "weight_column", None)
        if is_big_data_mode(cfg):
            train_mask, test_mask = split_sample_masks(df, cfg)
            needed_cols = [target_col, score_col, weight_col]
            needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
            df_small = df.loc[:, needed_cols]
            df_train = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=200_000, random_state=211).copy()
            df_test = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=200_000, random_state=212).copy()
            df_all = sample_frame_for_big_data(df_small, cfg, max_rows=300_000, random_state=213).copy()
        else:
            df_train, df_test, df_all = split_frames(df, cfg)

        w_train = get_weight_col(df_train, cfg)
        w_test = get_weight_col(df_test, cfg)
        w_all = get_weight_col(df_all, cfg) if df_all is not None else None
        if df_all is None:
            df_all = df  # fallback: use the full input frame

        # Проверки типов/NaN
        for label_df, frame in (("train", df_train), ("test", df_test), ("overall", df_all)):
            for col_name in (score_col, target_col):
                col_series = frame[col_name]
                if not pd.api.types.is_numeric_dtype(col_series):
                    try:
                        pd.to_numeric(col_series, errors='raise')
                    except ValueError:
                        raise ValueError(f"Столбец {col_name} ({label_df}) не является числовым.")
                if col_series.isnull().any():
                    raise ValueError(f"Столбец {col_name} ({label_df}) содержит пропущенные значения.")

        # --- Gini (нормализованный для регрессии, 2*AUC-1 для бинарной задачи) ---
        if is_binary_mode(cfg):
            gini_overall = self.compute_gini(df_all[score_col], df_all[target_col], w_all)
            gini_train = self.compute_gini(df_train[score_col], df_train[target_col], w_train)
            gini_test = self.compute_gini(df_test[score_col], df_test[target_col], w_test)
        else:
            def _w(w):
                return w.to_numpy() if w is not None else None
            gini_overall = float(gini_normalized(
                np.asarray(df_all[target_col]), np.asarray(df_all[score_col]), sample_weight=_w(w_all)))
            gini_train = float(gini_normalized(
                np.asarray(df_train[target_col]), np.asarray(df_train[score_col]), sample_weight=_w(w_train)))
            gini_test = float(gini_normalized(
                np.asarray(df_test[target_col]), np.asarray(df_test[score_col]), sample_weight=_w(w_test)))

        # --- PowerStat (через общий weighted-aware helper) ---
        ps_overall = float(powerstat_value(df_all[target_col], df_all[score_col], weight=w_all))
        ps_train = float(powerstat_value(df_train[target_col], df_train[score_col], weight=w_train))
        ps_test = float(powerstat_value(df_test[target_col], df_test[score_col], weight=w_test))

        # Сигнал по тесту (по Gini test, как и раньше)
        self.test_signal = self.compute_signal(gini_test)

        # Компактная таблица: один ряд из 6 значений.
        html = f"""
        <h4>M 2.1 — Overall Gini & PowerStat</h4>
        <p><b>Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal.upper()}</span></p>
        <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse">
            <thead>
                <tr>
                    <th>Gini</th><th>Gini Train</th><th>Gini Test</th>
                    <th>PowerStat</th><th>PowerStat Train</th><th>PowerStat Test</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{gini_overall:.4f}</td><td>{gini_train:.4f}</td><td>{gini_test:.4f}</td>
                    <td>{ps_overall:.4f}</td><td>{ps_train:.4f}</td><td>{ps_test:.4f}</td>
                </tr>
            </tbody>
        </table>
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"DASHBOARD": html}

