# core import
from ...core.base_test import BaseModelTest
# default imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from io import BytesIO
import base64
# stat imports
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, roc_curve, auc
from scipy.stats import norm
from scipy import sparse
from scipy.special import expit 
# module imports
import itertools
from typing import List, Dict, Union, Any, Optional

from joblib import Parallel, delayed, parallel_backend

# NEW
from ...core.config_validation import validate_config as _validate_config, ConfigValidationError
from ...core.data_utils import (
    ensure_config,
    split_frames,
    split_sample_masks,
    get_weight_col,
    get_score_col,
    get_features,
    is_binary_mode,
    is_big_data_mode,
    is_generic_classification_mode,
    get_validation_label,
    sample_frame_for_big_data,
)
from ...core.styles import COLORS, STATUS_COLORS, figure
from ...core.metrics import gini, gini_normalized, gini_numba
from ...core.render_context import get_render_mode
from .._visual_utils import (
    OBSERVATION_COUNT_LABEL,
    apply_standard_axis_style,
    build_tabbed_sections_html,
    figure_to_base64,
    render_flag_table,
)
import logging
from tqdm import tqdm
logger = logging.getLogger(__name__)

from ._shared import (
    _classification_mode_na,
    powerstat_value,
    gini_one_feature,
    gini_for_features_fast,
    gini_one_categorical_feature,
    gini_for_categorical_features,
    powerstat_one_feature,
    powerstat_for_features_fast,
    powerstat_one_categorical_feature,
    powerstat_for_categorical_features,
    determine_optimal_freq,
)


class M23_GiniDynamicsTest(BaseModelTest):
    """
    Класс для теста M 2.4: Gini Dynamics.

    Анализирует динамику коэффициента Gini по времени на обучающей и тестовой выборках.
    Цель — выявить деградацию модели или нестабильность качества прогноза во времени.

    Общая логика:
        1. Данные агрегируются по датам (по умолчанию — помесячно).
        2. Для каждого временного бакета рассчитывается:
            - Gini (%),
            - Количество наблюдений и событий,
            - Среднее значение целевой переменной,
            - Доверительные интервалы (95% и 99%).
        3. Строится график: динамика Gini + количество наблюдений.
        4. Выводится сигнал:
            - "red": если ≥50% временных бакетов имеют Gini < 35%,
            - "orange": если ≥30% бакетов имеют Gini < 35%,
            - "green": в остальных случаях.

    Атрибуты:
        * test_signal (str): Итоговый цветовой сигнал ("green", "orange", "red").

    Методы:
        * compute_confidence_interval(gini, n, alpha): Рассчитывает доверительный интервал Gini.
        * compute_table(df, date_column, score_column, target_column): Строит таблицу метрик по времени.
        * determine_signal(gini_values): Вычисляет итоговый сигнал по значению Gini.
        * plot_dynamics(df, title): Строит график динамики Gini и количества наблюдений.
        * run(df_train, df_test, date_column, score_column, target_column): Запускает тест и возвращает HTML-отчёт.
    """
    def __init__(self):
        super().__init__("M 2.3", "Gini Dynamics (quarterly)")

    def compute_confidence_interval(self, gini, n_pos, n_neg=None, alpha=0.05):
        """Normal-approximation CI for Gini/PowerStat using **Hanley-McNeil** SE.

        Hanley-McNeil 1982 derives the SE of AUC from the U-statistic structure
        of ROC area, accounting for both positive and negative class sizes::

            AUC      = (gini + 1) / 2
            Q1       = AUC / (2 - AUC)
            Q2       = 2 * AUC² / (1 + AUC)
            SE_AUC²  = (AUC*(1 - AUC)
                        + (n_pos - 1) * (Q1 - AUC²)
                        + (n_neg - 1) * (Q2 - AUC²)) / (n_pos * n_neg)
            SE_Gini  = 2 * SE_AUC

        For Poisson-frequency models we set ``n_pos = Σ y_i`` (total event
        count in the slice — each claim counts as one positive sample) and
        ``n_neg = N - n_pos``. Reference dynamics tables match this within
        rounding noise.

        ``n_neg=None`` falls back to the EHT approximation
        ``SE = sqrt((1 - gini²) / n_pos)`` — used when the negative-class
        size is unavailable (e.g. ungrouped credit-scoring summaries).

        Parameters
        ----------
        gini : float
            PowerStat / Gini value on ``[-1, 1]``.
        n_pos : int
            Positive-event count in the slice. ``n_pos <= 0`` collapses
            the CI to a point at ``gini``.
        n_neg : int, optional
            Negative-class size. When provided, Hanley-McNeil is used;
            when ``None`` (or ≤ 0), EHT fallback.
        alpha : float
            Significance level. Default 0.05 → 95 % CI.

        Returns
        -------
        Tuple[float, float]
            ``(low, high)`` on the same scale as ``gini``.
        """
        if n_pos <= 0:
            return gini, gini
        z = norm.ppf(1 - alpha / 2)
        if n_neg is None or n_neg <= 0:
            se = np.sqrt(max(0.0, 1.0 - gini * gini) / n_pos)
            return gini - z * se, gini + z * se
        auc = (gini + 1.0) / 2.0
        auc = min(max(auc, 0.0), 1.0)
        q1 = auc / (2.0 - auc) if auc < 2.0 else 0.0
        q2 = 2.0 * auc * auc / (1.0 + auc) if auc > -1.0 else 0.0
        auc_sq = auc * auc
        num = (auc * (1.0 - auc)
               + (n_pos - 1) * (q1 - auc_sq)
               + (n_neg - 1) * (q2 - auc_sq))
        denom = n_pos * n_neg
        se_auc_sq = max(0.0, num / denom) if denom > 0 else 0.0
        se_gini = 2.0 * np.sqrt(se_auc_sq)
        return gini - z * se_gini, gini + z * se_gini

    def compute_table(self, df: pd.DataFrame, date_column: str, score_column: str, target_column: str) -> pd.DataFrame:
        """
        Группирует данные по времени и рассчитывает Gini, доверительные интервалы и прочие статистики.

        Параметры:
            * df (pd.DataFrame): Датафрейм с исходными данными.
            * date_column (str): Имя колонки с датами.
            * score_column (str): Имя колонки с прогнозами модели.
            * target_column (str): Имя колонки с фактическими метками.

        Возвращает:
            * pd.DataFrame: Таблица с динамикой Gini и сопутствующей статистикой.
        """
        df = df.copy()
        df[date_column] = pd.to_datetime(df[date_column])
        df.set_index(date_column, inplace=True)
        freq = "Q"  # квартальная агрегация
        grouped = df.groupby(pd.Grouper(freq=freq))

        stats = []
        for date, group in grouped:
            if len(group) == 0:
                continue
            n = len(group)
            y_true = group[target_column]
            y_score = group[score_column]
            if len(np.unique(y_true)) < 2:
                gini = 0
            else:
                auc = roc_auc_score(y_true, y_score)
                gini = 2 * auc - 1
            # Hanley-McNeil CI on (n_pos, n_neg).
            n_pos = float((y_true > 0).sum())
            n_neg = float(len(y_true) - n_pos)
            gini_95_low, gini_95_high = self.compute_confidence_interval(gini, n_pos, n_neg=n_neg, alpha=0.05)
            gini_99_low, gini_99_high = self.compute_confidence_interval(gini, n_pos, n_neg=n_neg, alpha=0.01)
            stats.append((date.to_period(freq).start_time.strftime("%d-%m-%Y"), n, y_true.sum(), y_true.mean(), gini * 100,
                          gini_95_low * 100, gini_95_high * 100,
                          gini_99_low * 100, gini_99_high * 100))

        return pd.DataFrame(stats, columns=[
            "Date", "Observations", "Events", "Mean Target", "Gini %",
            "CI 95% Low", "CI 95% High", "CI 99% Low", "CI 99% High"
        ])

    def compute_table_regression_gini(
        self,
        df: pd.DataFrame,
        date_column: str,
        score_column: str,
        target_column: str,
        weight_column: Optional[str] = None,
    ) -> pd.DataFrame:
        """Quarterly table of normalized Gini (Lorenz-area form) for regression/frequency.

        Same layout as ``compute_table_regression`` but uses
        :func:`gini_normalized` with ``sample_weight``. CI built with normal
        approximation around the metric using effective sample size.
        """
        df = df.copy()
        df[date_column] = pd.to_datetime(df[date_column])
        df.set_index(date_column, inplace=True)
        freq = "Q"
        grouped = df.groupby(pd.Grouper(freq=freq))

        use_w = weight_column and weight_column in df.columns
        stats = []
        for date, group in grouped:
            if len(group) == 0:
                continue
            n = len(group)
            y_true = group[target_column].to_numpy()
            y_score = group[score_column].to_numpy()
            w = group[weight_column].to_numpy(dtype=float) if use_w else None
            try:
                g = float(gini_normalized(y_true, y_score, sample_weight=w))
            except Exception:
                g = 0.0
            n_pos = float(np.sum(y_true))  # for Poisson-frequency: Σy = total events
            n_neg = float(len(y_true) - n_pos)
            g95l, g95h = self.compute_confidence_interval(g, n_pos, n_neg=n_neg, alpha=0.05)
            g99l, g99h = self.compute_confidence_interval(g, n_pos, n_neg=n_neg, alpha=0.01)
            stats.append((date.to_period(freq).start_time.strftime("%d-%m-%Y"), n,
                          np.sum(y_true), np.mean(y_true), g * 100,
                          g95l * 100, g95h * 100, g99l * 100, g99h * 100))

        return pd.DataFrame(stats, columns=[
            "Date", "Observations", "Events", "Mean Target", "Gini %",
            "CI 95% Low", "CI 95% High", "CI 99% Low", "CI 99% High"
        ])

    def compute_table_regression(
        self,
        df: pd.DataFrame,
        date_column: str,
        score_column: str,
        target_column: str,
        weight_column: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        Регрессионный вариант таблицы динамики: считает PowerStat (формула M 2.1, cumulative-gains)
        вместо Gini/ROC-AUC. По методике (Замечание после M 2.1) при наличии экспозиции
        кумулятивные доли строятся с учётом весов наблюдений.

        CI для каждого среза: нормальная аппроксимация PowerStat с эффективным размером
        выборки n_eff = (Σw)² / Σw² при наличии весов; иначе — обычное n.
        """
        df = df.copy()
        df[date_column] = pd.to_datetime(df[date_column])
        df.set_index(date_column, inplace=True)
        freq = "Q"
        grouped = df.groupby(pd.Grouper(freq=freq))

        use_w = weight_column and weight_column in df.columns
        stats = []
        for date, group in grouped:
            if len(group) == 0:
                continue
            n = len(group)
            y_true = group[target_column].to_numpy()
            y_score = group[score_column].to_numpy()
            w = group[weight_column].to_numpy(dtype=float) if use_w else None
            try:
                ps = float(powerstat_value(y_true, y_score, weight=w))
            except Exception:
                ps = 0.0
            # Hanley-McNeil CI: SE accounts for both positive (events) and negative class sizes.
            n_pos = float(np.sum(y_true))  # total events in the slice
            n_neg = float(len(y_true) - n_pos)
            ps_95_low, ps_95_high = self.compute_confidence_interval(ps, n_pos, n_neg=n_neg, alpha=0.05)
            ps_99_low, ps_99_high = self.compute_confidence_interval(ps, n_pos, n_neg=n_neg, alpha=0.01)
            stats.append((date.to_period(freq).start_time.strftime("%d-%m-%Y"), n, np.sum(y_true), np.mean(y_true), ps * 100,
                          ps_95_low * 100, ps_95_high * 100,
                          ps_99_low * 100, ps_99_high * 100))

        return pd.DataFrame(stats, columns=[
            "Date", "Observations", "Events", "Mean Target", "PowerStat %",
            "CI 95% Low", "CI 95% High", "CI 99% Low", "CI 99% High"
        ])

    def _flag_for_gini(self, gini_pct: float) -> str:
        # Локальный флаг по кварталу
        if gini_pct < 15:
            return "red"
        elif gini_pct < 35:
            return "orange"
        else:
            return "green"

    def plot_dynamics(self, df: pd.DataFrame, title: str, flags: List[str],
                      metric_col: str = "Gini %", metric_label: str = "Normalized Gini") -> str:
        """Динамика метрики в стиле M 4.2 (Calibration by Predict Bins).

        Идиома: бары наблюдений на secondary axis, два залитых CI-бэнда (99% red,
        95% orange), сплошная линия метрики поверх, красные звёзды на точках с red-флагом.
        """
        x = pd.to_datetime(df["Date"], dayfirst=True, errors='coerce')
        work = df.copy()
        work["_x"] = x
        work = work.sort_values("_x").reset_index(drop=True)
        n = len(work)
        x_idx = np.arange(n)
        labels = [f"{d.year}Q{((d.month-1)//3)+1}" for d in work["_x"]]

        m  = pd.to_numeric(work[metric_col],     errors='coerce').interpolate("linear", limit_area="inside").ffill().bfill()
        c95l = pd.to_numeric(work["CI 95% Low"],  errors='coerce').interpolate("linear", limit_area="inside").ffill().bfill()
        c95h = pd.to_numeric(work["CI 95% High"], errors='coerce').interpolate("linear", limit_area="inside").ffill().bfill()
        c99l = pd.to_numeric(work["CI 99% Low"],  errors='coerce').interpolate("linear", limit_area="inside").ffill().bfill()
        c99h = pd.to_numeric(work["CI 99% High"], errors='coerce').interpolate("linear", limit_area="inside").ffill().bfill()

        fig, ax1 = figure(size="wide")
        ax2 = ax1.twinx()

        # Бары наблюдений на вторичной оси (рисуются первыми → лежат позади линий).
        ax2.bar(x_idx, work["Observations"], alpha=0.35, color=COLORS['EMERALD'], label="Observations")
        ax2.set_ylabel("Observations")

        # CI-бэнды (как в M 4.2): 99% red, 95% orange поверх.
        ax1.fill_between(x_idx, c99l, c99h, color=COLORS['RED'], alpha=0.30, label="99% CI")
        ax1.fill_between(x_idx, c95l, c95h, color=COLORS['ORANGE'], alpha=0.45, label="95% CI")

        # Линия метрики поверх (сплошная, синяя с маркерами).
        ax1.plot(x_idx, m, color=COLORS['BLUE'], linewidth=2.0, marker='o', markersize=6,
                 label=metric_label)

        # Красные звёзды для красных кварталов.
        red_idx = [i for i in range(n) if i < len(flags) and flags[i] == 'red']
        if red_idx:
            ax1.scatter(red_idx, m.iloc[red_idx], marker='*', color=COLORS['RED'], s=140,
                        zorder=5, label="Red flag")

        ax1.set_xlabel("Period")
        ax1.set_ylabel(f"{metric_label}, %")
        ax1.set_xticks(x_idx)
        ax1.set_xticklabels(labels, rotation=45, ha='right')
        ax1.grid(True, linestyle='--', alpha=0.3)

        ax1.set_title(title)

        ax1.legend(loc='upper left')
        ax2.legend(loc='upper right')
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png", bbox_inches='tight')
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode()

    def plot_dynamics_plotly(self, df: pd.DataFrame, title: str, flags: List[str],
                              metric_col: str = "Gini %", metric_label: str = "Normalized Gini") -> str:
        """Plotly-эквивалент ``plot_dynamics`` в стиле M 4.2."""
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots

        x = pd.to_datetime(df["Date"], dayfirst=True, errors='coerce')
        work = df.copy()
        work["_x"] = x
        work = work.sort_values("_x").reset_index(drop=True)

        for col in [metric_col, "CI 95% Low", "CI 95% High", "CI 99% Low", "CI 99% High"]:
            work[col] = pd.to_numeric(work[col], errors='coerce')
        m    = work[metric_col].interpolate("linear", limit_area="inside").ffill().bfill()
        c95l = work["CI 95% Low"].interpolate("linear", limit_area="inside").ffill().bfill()
        c95h = work["CI 95% High"].interpolate("linear", limit_area="inside").ffill().bfill()
        c99l = work["CI 99% Low"].interpolate("linear", limit_area="inside").ffill().bfill()
        c99h = work["CI 99% High"].interpolate("linear", limit_area="inside").ffill().bfill()

        labels = [f"{d.year}Q{((d.month-1)//3)+1}" for d in work["_x"]]

        fig = make_subplots(specs=[[{"secondary_y": True}]])

        # Бары наблюдений на вторичной оси (рисуем первыми → за линиями).
        fig.add_trace(
            go.Bar(x=labels, y=work["Observations"], name="Количество наблюдений",
                   marker=dict(color=COLORS['EMERALD']), opacity=0.35,
                   hovertemplate="%{x}<br>Наблюдений: %{y:,.0f}<extra></extra>"),
            secondary_y=True,
        )

        # 99% CI band — два scatter trace: нижний прозрачный, верхний с fill="tonexty".
        fig.add_trace(
            go.Scatter(x=labels, y=c99l, mode="lines", line=dict(width=0),
                       hoverinfo="skip", showlegend=False),
            secondary_y=False,
        )
        fig.add_trace(
            go.Scatter(x=labels, y=c99h, mode="lines", line=dict(width=0),
                       fill="tonexty", fillcolor="rgba(250,25,41,0.30)",
                       name="99% ДИ", hoverinfo="skip"),
            secondary_y=False,
        )
        # 95% CI band поверх 99%.
        fig.add_trace(
            go.Scatter(x=labels, y=c95l, mode="lines", line=dict(width=0),
                       hoverinfo="skip", showlegend=False),
            secondary_y=False,
        )
        fig.add_trace(
            go.Scatter(x=labels, y=c95h, mode="lines", line=dict(width=0),
                       fill="tonexty", fillcolor="rgba(255,204,0,0.45)",
                       name="95% ДИ", hoverinfo="skip"),
            secondary_y=False,
        )

        # Линия метрики поверх всего.
        fig.add_trace(
            go.Scatter(x=labels, y=m, mode="lines+markers",
                       name=f"Коэффициент {metric_label}",
                       line=dict(color=COLORS['BLUE'], width=2),
                       marker=dict(size=7),
                       hovertemplate="%{x}<br>" + metric_label + ": %{y:.2f}%<extra></extra>"),
            secondary_y=False,
        )

        # Red-flag stars.
        red_idx = [i for i in range(len(work)) if i < len(flags) and flags[i] == 'red']
        if red_idx:
            fig.add_trace(
                go.Scatter(x=[labels[i] for i in red_idx],
                           y=[m.iloc[i] for i in red_idx],
                           mode="markers", name="Red flag",
                           marker=dict(symbol="star", size=15, color=COLORS['RED'])),
                secondary_y=False,
            )

        fig.update_layout(
            template="plotly_white",
            hovermode="x unified",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
            margin=dict(l=60, r=60, t=60, b=80),
            height=440,
            title=dict(text=title, font=dict(size=15)),
        )
        fig.update_xaxes(title_text="Period", type="category", tickangle=-45)
        fig.update_yaxes(title_text=f"Коэффициент {metric_label}, %", secondary_y=False)
        fig.update_yaxes(title_text="Количество наблюдений", secondary_y=True, showgrid=False)

        return fig.to_html(include_plotlyjs="cdn", full_html=False, config={"displaylogo": False})

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        if is_generic_classification_mode(cfg):
            self.test_signal = "blue"
            return _classification_mode_na(self.test_name)
        date_column = cfg.columns.date_column
        target_column = cfg.columns.target_column
        score_column  = get_score_col(cfg)
        weight_column = getattr(cfg.columns, 'weight_column', None)
        if is_big_data_mode(cfg):
            train_mask, test_mask = split_sample_masks(df, cfg)
            needed_cols = [date_column, target_column, score_column, weight_column]
            needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
            df_small = df.loc[:, needed_cols]
            df_train = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=150_000, random_state=231).copy()
            df_test = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=150_000, random_state=232).copy()
            df_all = sample_frame_for_big_data(df_small, cfg, max_rows=250_000, random_state=233).copy()
        else:
            df_train, df_test, df_all = split_frames(df, cfg)

        # Прежние проверки типов/NaN
        for column in [score_column, target_column]:
            for sub, name in [(df_train, "train"), (df_test, "test"), (df_all, "all")]:
                if not pd.api.types.is_numeric_dtype(sub[column]):
                    try:
                        sub[column] = pd.to_numeric(sub[column], errors='raise')
                    except ValueError:
                        raise ValueError(f"Столбец {column} ({name}) не является числовым.")
                if sub[column].isnull().any():
                    raise ValueError(f"Столбец {column} ({name}) содержит пропущенные значения.")

        binary = is_binary_mode(cfg)

        # Build one or two metric variants (PowerStat + Gini), each with all/train/test tables.
        # Binary mode: only Gini (computed via ROC-AUC).
        # Regression/frequency/severity: both metrics shown as a tabbed toggle.
        variants = []
        if binary:
            al = self.compute_table(df_all,   date_column, score_column, target_column)
            tr = self.compute_table(df_train, date_column, score_column, target_column)
            te = self.compute_table(df_test,  date_column, score_column, target_column)
            variants.append(("Gini", "Gini %", "Gini", al, tr, te))
        else:
            ps_al = self.compute_table_regression(df_all,   date_column, score_column, target_column, weight_column=weight_column)
            ps_tr = self.compute_table_regression(df_train, date_column, score_column, target_column, weight_column=weight_column)
            ps_te = self.compute_table_regression(df_test,  date_column, score_column, target_column, weight_column=weight_column)
            variants.append(("PowerStat", "PowerStat %", "PowerStat", ps_al, ps_tr, ps_te))
            g_al = self.compute_table_regression_gini(df_all,   date_column, score_column, target_column, weight_column=weight_column)
            g_tr = self.compute_table_regression_gini(df_train, date_column, score_column, target_column, weight_column=weight_column)
            g_te = self.compute_table_regression_gini(df_test,  date_column, score_column, target_column, weight_column=weight_column)
            variants.append(("Gini", "Gini %", "Normalized Gini", g_al, g_tr, g_te))

        # Overall signal — taken from the first (primary) variant on All (the canonical view).
        prim_label, prim_col, prim_metric, prim_al, prim_tr, prim_te = variants[0]
        flags_all_prim   = [self._flag_for_gini(float(v)) for v in prim_al[prim_col].tolist()]
        flags_train_prim = [self._flag_for_gini(float(v)) for v in prim_tr[prim_col].tolist()]
        flags_test_prim  = [self._flag_for_gini(float(v)) for v in prim_te[prim_col].tolist()]

        def fractions(flags: List[str], obs: List[float]):
            total = max(1, len(flags))
            red_frac = sum(1 for f in flags if f == 'red') / total
            orange_frac = sum(1 for f in flags if f == 'orange') / total
            obs_sum = max(1.0, float(sum(obs)))
            red_obs = float(sum(o for f, o in zip(flags, obs) if f == 'red')) / obs_sum
            orange_obs = float(sum(o for f, o in zip(flags, obs) if f == 'orange')) / obs_sum
            return red_frac, orange_frac, red_obs, orange_obs

        r_al, y_al, r_al_obs, y_al_obs = fractions(flags_all_prim,   prim_al["Observations"].astype(float).tolist())
        r_tr, y_tr, r_tr_obs, y_tr_obs = fractions(flags_train_prim, prim_tr["Observations"].astype(float).tolist())
        r_te, y_te, r_te_obs, y_te_obs = fractions(flags_test_prim,  prim_te["Observations"].astype(float).tolist())
        # All is the canonical view; flagging based on it primarily, train/test as supporting evidence.
        if (r_al > 0.3 or r_al_obs > 0.3):
            overall = 'red'
        elif (y_al < 0.3 and y_al_obs < 0.3):
            overall = 'green'
        else:
            overall = 'orange'
        self.test_signal = overall

        signal_html = (
            f"<p><b>Overall Signal:</b> "
            f"<span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal.upper()}</span></p>"
        )

        def _smart_format(v: float) -> str:
            """Pick decimals to show ≥3 significant figures (handy for rare-event
            Poisson rates that round to ``0.00`` under a fixed ``%.2f``)."""
            if not np.isfinite(v) or v == 0:
                return f"{v:.2f}"
            av = abs(v)
            if av >= 1:
                return f"{v:.2f}"
            if av >= 0.01:
                return f"{v:.4f}"
            if av >= 0.0001:
                return f"{v:.6f}"
            return f"{v:.2e}"

        def _format_rate_columns(t: pd.DataFrame) -> pd.DataFrame:
            t = t.copy()
            if "Mean Target" in t.columns:
                t["Mean Target"] = t["Mean Target"].apply(_smart_format)
            return t

        # Render each variant as one tab containing All + Train + Test sub-blocks.
        def _render_variant(label: str, metric_col: str, metric_label: str,
                            table_all: pd.DataFrame, table_train: pd.DataFrame, table_test: pd.DataFrame) -> str:
            flags_all   = [self._flag_for_gini(float(v)) for v in table_all[metric_col].tolist()]
            flags_train = [self._flag_for_gini(float(v)) for v in table_train[metric_col].tolist()]
            flags_test  = [self._flag_for_gini(float(v)) for v in table_test[metric_col].tolist()]
            title_prefix = f"{metric_label} Dynamics (Quarterly)"
            if get_render_mode() == "plotly":
                plot_all   = self.plot_dynamics_plotly(table_all,   f"{title_prefix} - All", flags_all,
                                                      metric_col=metric_col, metric_label=metric_label)
                plot_train = self.plot_dynamics_plotly(table_train, f"{title_prefix} - Train", flags_train,
                                                      metric_col=metric_col, metric_label=metric_label)
                plot_test  = self.plot_dynamics_plotly(table_test,  f"{title_prefix} - Test", flags_test,
                                                      metric_col=metric_col, metric_label=metric_label)
            else:
                b64_al = self.plot_dynamics(table_all,   f"{title_prefix} - All", flags_all,
                                            metric_col=metric_col, metric_label=metric_label)
                b64_tr = self.plot_dynamics(table_train, f"{title_prefix} - Train", flags_train,
                                            metric_col=metric_col, metric_label=metric_label)
                b64_te = self.plot_dynamics(table_test,  f"{title_prefix} - Test", flags_test,
                                            metric_col=metric_col, metric_label=metric_label)
                plot_all   = f'<img src="data:image/png;base64,{b64_al}">'
                plot_train = f'<img src="data:image/png;base64,{b64_tr}">'
                plot_test  = f'<img src="data:image/png;base64,{b64_te}">'

            # Attach Flag column to enable red-row highlighting in the table.
            al_with = _format_rate_columns(table_all);   al_with["Flag"] = flags_all
            tr_with = _format_rate_columns(table_train); tr_with["Flag"] = flags_train
            te_with = _format_rate_columns(table_test);  te_with["Flag"] = flags_test
            return (
                f"<h5>All</h5>"
                f"{plot_all}"
                f"{render_flag_table(al_with, flag_col='Flag', float_format='%.2f')}"
                f"<br><h5>Train</h5>"
                f"{plot_train}"
                f"{render_flag_table(tr_with, flag_col='Flag', float_format='%.2f')}"
                f"<br><h5>Test</h5>"
                f"{plot_test}"
                f"{render_flag_table(te_with, flag_col='Flag', float_format='%.2f')}"
            )

        if len(variants) == 1:
            label, col, metric, al_t, tr_t, te_t = variants[0]
            body = _render_variant(label, col, metric, al_t, tr_t, te_t)
        else:
            tabs = []
            for label, col, metric, al_t, tr_t, te_t in variants:
                tabs.append({
                    "label": f"{label} Dynamics",
                    "html": _render_variant(label, col, metric, al_t, tr_t, te_t),
                })
            body = build_tabbed_sections_html(tabs, root_prefix="m23-metric")

        html = f"""
        <h4>Dynamics (Quarterly)</h4>
        {signal_html}
        {body}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"DASHBOARD": html}

