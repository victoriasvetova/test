"""Shared imports and module-level helpers for the m2 test classes."""

# core import
from ...core.base_test import BaseModelTest
# default imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from io import BytesIO
import base64
# stat imports
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, roc_curve, auc
from scipy.stats import norm
from scipy import sparse
from scipy.special import expit 
# module imports
import itertools
from typing import List, Dict, Union, Any, Optional

from joblib import Parallel, delayed, parallel_backend

# NEW
from ...core.config_validation import validate_config as _validate_config, ConfigValidationError
from ...core.data_utils import (
    ensure_config,
    split_frames,
    get_weight_col,
    get_score_col,
    get_features,
    is_binary_mode,
    is_generic_classification_mode,
    is_glm_preset,
    resolve_feature_columns,
    get_validation_label,
)
from ...core.styles import COLORS, STATUS_COLORS, figure
from ...core.metrics import gini, gini_normalized, gini_numba
from .._visual_utils import OBSERVATION_COUNT_LABEL, apply_standard_axis_style, figure_to_base64
import logging
from tqdm import tqdm
logger = logging.getLogger(__name__)


def _classification_mode_na(test_name: str) -> Dict[str, str]:
    return {
        "DASHBOARD": (
            f"<h4>{test_name}</h4>"
            "<p><b>Skipped:</b> generic `classification` mode is not yet mapped "
            "to a methodology-specific ranking test. Use `binary` for binomial/logistic tasks.</p>"
        )
    }


def powerstat_value(
    target: Union[pd.Series, np.ndarray],
    score: Union[pd.Series, np.ndarray],
    weight: Optional[Union[pd.Series, np.ndarray]] = None,
) -> float:
    """Compute PowerStat (cumulative-gains Lorenz-area metric) — M 2.1 formula.

    When ``weight`` (e.g. exposure) is provided, the cumulative observation share
    is built on **weighted counts** and the cumulative target share remains on
    actual values, per the methodology замечание after M 2.1:
    «необходимо учитывать [веса] при расчёте как кумулятивной доли наблюдений,
    так и кумулятивной доли фактических значений целевой переменной».

      x-axis:  Σw_σ(k) / Σw_total
      y-axis:  Σy_σ(k) / Σy_total      (σ = order by score desc → model curve;
                                          σ = order by y desc     → ideal curve)

    Tie handling: the model curve groups rows with the **same score** into one
    cumulative-gain segment (the model has no opinion on row order inside a
    tie, so the segment is a straight line between the tied block's start
    and end). The ideal curve stays row-by-row, sorted by ``-y``. This is the
    canonical actuarial construction and makes the metric invariant to the
    arbitrary within-tie row order returned by ``np.argsort`` — critical for
    factors where a large share of observations sit at the baseline
    coefficient (1.0), which would otherwise produce noisy / sign-flipping
    PowerStat values.
    """
    y_np = pd.to_numeric(pd.Series(target), errors="raise").to_numpy(dtype=float, copy=False)
    s_np = pd.to_numeric(pd.Series(score), errors="raise").to_numpy(dtype=float, copy=False)
    if weight is not None:
        w_np = pd.to_numeric(pd.Series(weight), errors="raise").to_numpy(dtype=float, copy=False)
        if w_np.shape != y_np.shape:
            w_np = w_np[: y_np.shape[0]]
        mask = np.isfinite(y_np) & np.isfinite(s_np) & np.isfinite(w_np) & (w_np > 0)
        y_np = y_np[mask]
        s_np = s_np[mask]
        w_np = w_np[mask]
    else:
        mask = np.isfinite(y_np) & np.isfinite(s_np)
        y_np = y_np[mask]
        s_np = s_np[mask]
        w_np = np.ones_like(y_np)

    n = y_np.shape[0]
    if n == 0:
        return 0.0
    total_y = float(np.sum(y_np))
    total_w = float(np.sum(w_np))
    if total_y <= 0 or total_w <= 0:
        return 0.0

    # --- Model curve: collapse tied scores into one cumulative segment. ---
    # Sort unique scores descending; aggregate y and w within each score.
    order = np.argsort(-s_np, kind="mergesort")
    s_ord = s_np[order]
    y_ord = y_np[order]
    w_ord = w_np[order]
    # Boundaries where the score changes (within s_ord which is sorted desc).
    change = np.empty(n, dtype=bool)
    change[0] = True
    change[1:] = s_ord[1:] != s_ord[:-1]
    group_ids = np.cumsum(change) - 1
    n_groups = int(group_ids[-1]) + 1
    y_g = np.bincount(group_ids, weights=y_ord, minlength=n_groups)
    w_g = np.bincount(group_ids, weights=w_ord, minlength=n_groups)
    x_model = np.concatenate([[0.0], np.cumsum(w_g) / total_w])
    y_model = np.concatenate([[0.0], np.cumsum(y_g) / total_y])

    # --- Ideal curve: row-by-row sort by -y (no tie aggregation). ---
    o_i = np.argsort(-y_np, kind="mergesort")
    x_ideal = np.concatenate([[0.0], np.cumsum(w_np[o_i]) / total_w])
    y_ideal = np.concatenate([[0.0], np.cumsum(y_np[o_i]) / total_y])

    a_ideal = float(np.trapz(y_ideal, x_ideal))
    a_model = float(np.trapz(y_model, x_model))
    denom = a_ideal - 0.5
    if denom <= 0:
        return 0.0
    # PowerStat can legitimately be negative for anti-predictive factors
    # (model ranking worse than random). We only clip the upper bound:
    # a value above 1.0 is a numerical artefact, but values below 0
    # carry diagnostic meaning per methodology.
    return float(min(1.0, (a_model - 0.5) / denom))



def gini_one_feature(y_tr: np.array, y_te: np.array, x_tr: np.array, x_te: np.array, name:str):
        """
        Вычисляет индекс Джини для указанной переменной на тренировочном и тестовом наборах данных.
        """
        # Считаем gini на трейн и переводим в %
        g_tr = gini_numba(y_tr, x_tr) * 100.0
        # Считаем gini на тесте и переводим в %
        g_te = gini_numba(y_te, x_te) * 100.0
        return name, g_tr, g_te, abs(g_tr - g_te)

def gini_for_features_fast(df_tr: pd.DataFrame, df_te: pd.DataFrame, target: str, features: list, n_jobs=-1) -> list:
    """
    Вычисляет индекс Джини для списка факторов на тренировочном и тестовом наборах данных.

    Параметры
    ----------
    * df_tr : pd.DataFrame
          - Тренировочный набор данных.
    * df_te : pd.DataFrame
          - Тестовый набор данных.
    * target : str
          - Имя целевой переменной.
    * features : list
          - Список имен функций, для которых нужно вычислить индекс Джини.
    * n_jobs : int, optional
          - Количество заданий для параллельной обработки. По умолчанию: -1 (используются все доступные ядра).

    Возвращает
    -------
    * list: Список, содержащий результаты вычисления индекса Джини для каждой переменной.
   """
    # Получаем таргет для трайн и тест
    y_tr = df_tr[target].to_numpy(dtype=np.float32)
    y_te = df_te[target].to_numpy(dtype=np.float32)

    with parallel_backend("threading"):
        # Запускаем обработку признаков 
        out = Parallel(n_jobs=n_jobs)(
            delayed(gini_one_feature)(
                y_tr, y_te,
                df_tr[f].to_numpy(dtype=np.float32), # Нам хватит даже для весов, тк точность до 7 знаков
                df_te[f].to_numpy(dtype=np.float32),
                f
            ) for f in features
        )
    return out

def gini_one_categorical_feature(
    y_tr: np.array, 
    y_te: np.array, 
    x_tr: np.array, 
    x_te: np.array, 
    name: str
) -> tuple:
    """
    Вычисляет индекс Джини для категориального признака используя mean target encoding.
    
    Параметры:
        * y_tr: целевая переменная на train
        * y_te: целевая переменная на test
        * x_tr: значения категориального признака на train
        * x_te: значения категориального признака на test
        * name: название признака
    
    Возвращает:
        * tuple: (название признака, gini train %, gini test %, разница %)
    """
    # Создаем датафрейм для удобства группировки
    df_tr = pd.DataFrame({'cat': x_tr, 'target': y_tr})
    df_te = pd.DataFrame({'cat': x_te, 'target': y_te})
    
    # Вычисляем mean target encoding на train
    # Для каждой категории считаем среднее значение таргета
    encoding_map = df_tr.groupby('cat')['target'].mean().to_dict()
    
    # Применяем encoding к обеим выборкам
    # Для неизвестных категорий в test используем общий средний
    global_mean = df_tr['target'].mean()
    
    x_tr_encoded = df_tr['cat'].map(encoding_map).fillna(global_mean).to_numpy(dtype=np.float32)
    x_te_encoded = df_te['cat'].map(encoding_map).fillna(global_mean).to_numpy(dtype=np.float32)
    
    # Считаем gini на основе закодированных значений
    g_tr = gini_numba(y_tr, x_tr_encoded) * 100.0
    g_te = gini_numba(y_te, x_te_encoded) * 100.0
    
    return name, g_tr, g_te, abs(g_tr - g_te)

def gini_for_categorical_features(
    df_tr: pd.DataFrame, 
    df_te: pd.DataFrame, 
    target: str, 
    features: list, 
    n_jobs=-1
) -> list:
    """
    Вычисляет индекс Джини для списка категориальных признаков.
    Использует mean target encoding для преобразования категорий в числа.
    
    Параметры:
        * df_tr: тренировочный набор данных
        * df_te: тестовый набор данных
        * target: имя целевой переменной
        * features: список имен категориальных признаков
        * n_jobs: количество потоков для параллельной обработки
    
    Возвращает:
        * list: список результатов для каждого признака
    """
    if not features:
        return []
    
    # Получаем таргет для train и test
    y_tr = df_tr[target].to_numpy(dtype=np.float32)
    y_te = df_te[target].to_numpy(dtype=np.float32)
    
    with parallel_backend("threading"):
        # Запускаем обработку признаков
        out = Parallel(n_jobs=n_jobs)(
            delayed(gini_one_categorical_feature)(
                y_tr, y_te,
                df_tr[f].to_numpy(),  # Категориальные признаки оставляем как есть
                df_te[f].to_numpy(),
                f
            ) for f in features
        )
    return out

# Переопределим M22_GiniFactorsTest с улучшениями после сброса
def powerstat_one_feature(
    y_tr: np.array, y_te: np.array,
    x_tr: np.array, x_te: np.array,
    name: str,
    w_tr: Optional[np.array] = None,
    w_te: Optional[np.array] = None,
):
    ps_tr = powerstat_value(y_tr, x_tr, weight=w_tr) * 100.0
    ps_te = powerstat_value(y_te, x_te, weight=w_te) * 100.0
    return name, ps_tr, ps_te, abs(ps_tr - ps_te)


def powerstat_for_features_fast(
    df_tr: pd.DataFrame, df_te: pd.DataFrame,
    target: str, features: list,
    n_jobs: int = -1,
    weight: Optional[str] = None,
) -> list:
    y_tr = df_tr[target].to_numpy(dtype=np.float32)
    y_te = df_te[target].to_numpy(dtype=np.float32)
    w_tr = df_tr[weight].to_numpy(dtype=np.float32) if weight and weight in df_tr.columns else None
    w_te = df_te[weight].to_numpy(dtype=np.float32) if weight and weight in df_te.columns else None

    with parallel_backend("threading"):
        out = Parallel(n_jobs=n_jobs)(
            delayed(powerstat_one_feature)(
                y_tr, y_te,
                df_tr[f].to_numpy(dtype=np.float32),
                df_te[f].to_numpy(dtype=np.float32),
                f,
                w_tr, w_te,
            ) for f in features
        )
    return out


def powerstat_one_categorical_feature(
    y_tr: np.array,
    y_te: np.array,
    x_tr: np.array,
    x_te: np.array,
    name: str,
    w_tr: Optional[np.array] = None,
    w_te: Optional[np.array] = None,
) -> tuple:
    df_tr = pd.DataFrame({"cat": x_tr, "target": y_tr})
    df_te = pd.DataFrame({"cat": x_te, "target": y_te})

    encoding_map = df_tr.groupby("cat")["target"].mean().to_dict()
    global_mean = df_tr["target"].mean()

    x_tr_encoded = df_tr["cat"].map(encoding_map).fillna(global_mean).to_numpy(dtype=np.float32)
    x_te_encoded = df_te["cat"].map(encoding_map).fillna(global_mean).to_numpy(dtype=np.float32)

    ps_tr = powerstat_value(y_tr, x_tr_encoded, weight=w_tr) * 100.0
    ps_te = powerstat_value(y_te, x_te_encoded, weight=w_te) * 100.0
    return name, ps_tr, ps_te, abs(ps_tr - ps_te)


def powerstat_for_categorical_features(
    df_tr: pd.DataFrame,
    df_te: pd.DataFrame,
    target: str,
    features: list,
    n_jobs: int = -1,
    weight: Optional[str] = None,
) -> list:
    if not features:
        return []

    y_tr = df_tr[target].to_numpy(dtype=np.float32)
    y_te = df_te[target].to_numpy(dtype=np.float32)
    w_tr = df_tr[weight].to_numpy(dtype=np.float32) if weight and weight in df_tr.columns else None
    w_te = df_te[weight].to_numpy(dtype=np.float32) if weight and weight in df_te.columns else None

    with parallel_backend("threading"):
        out = Parallel(n_jobs=n_jobs)(
            delayed(powerstat_one_categorical_feature)(
                y_tr, y_te,
                df_tr[f].to_numpy(),
                df_te[f].to_numpy(),
                f,
                w_tr, w_te,
            ) for f in features
        )
    return out




# Реализация тестов M 2.4 Gini Dynamics и M 2.5 Gini Uplift
def determine_optimal_freq(dates: pd.Series, max_bins: int = 40) -> str:
    """
    Функция принимает на вход Series с датами и максимальное количество бинов.
    Определяет оптимальную частоту для группировки дат.

    Параметры:
        * dates (pd.Series): Series с датами.
        * max_bins (int): Максимальное количество бинов.

    Возвращает:
        * str: Оптимальная частота для группировки дат.
    """
    dates = pd.to_datetime(dates)
    total_days = (dates.max() - dates.min()).days
    if total_days <= 180:
        return "W"  # weekly
    elif total_days <= 365:
        return "M"  # monthly
    elif total_days <= 3 * 365:
        return "Q"  # quarterly
    else:
        return "A"  # annually
