﻿import base64
from io import BytesIO
from typing import Callable, Iterable, Optional, Sequence

import pandas as pd
import matplotlib.pyplot as plt
from uuid import uuid4

from ..core.styles import COLORS, rgba


SCALE_TITLE_LINEAR = "Linear Scale"
SCALE_TITLE_LOG = "Log Scale"
OBSERVATION_COUNT_LABEL = "Observation Count"
SHARE_LABEL = "Share"
MEAN_RATE_LABEL = "Mean Rate"
TARGET_RATE_LABEL = "Target Rate"
# Inline row styles for flagged table rows. The explicit foreground keeps
# notebook output readable when the surrounding report uses a dark theme.
# so dense tables stay readable but failing rows still pop visually.
_FLAG_ROW_STYLES = {
    'red': {
        'background': rgba(COLORS['RED'], 0.14),
        'color': COLORS['RED_DARK'],
    },
    'orange': {
        'background': rgba(COLORS['ORANGE'], 0.18),
        'color': COLORS['TEXT'],
    },
    'amber': {
        'background': rgba(COLORS['ORANGE'], 0.18),
        'color': COLORS['TEXT'],
    },
    'yellow': {
        'background': rgba(COLORS['ORANGE'], 0.18),
        'color': COLORS['TEXT'],
    },
}

_FLAG_PRIORITY = {
    '': -2,
    'blue': -1,
    'gray': -1,
    'grey': -1,
    'green': 0,
    'orange': 1,
    'amber': 1,
    'yellow': 1,
    'red': 2,
}


def worst_flag(*flags: object) -> str:
    """Return the most severe traffic-light flag among candidate flags."""
    best_flag = ""
    best_priority = _FLAG_PRIORITY[best_flag]
    for flag in flags:
        normalized = str(flag or "").strip().lower()
        priority = _FLAG_PRIORITY.get(normalized, best_priority)
        if priority > best_priority:
            best_flag = "orange" if normalized in {"amber", "yellow"} else normalized
            best_priority = priority
    return best_flag


def _fmt_cell(value, float_format: str) -> str:
    """Format a single cell value, applying float_format only to floats."""
    if isinstance(value, float):
        try:
            return float_format % value
        except (TypeError, ValueError):
            return str(value)
    if pd.isna(value):
        return ""
    return str(value)


def render_flag_table(
    df: pd.DataFrame,
    flag_col: str,
    *,
    drop_flag_col: bool = False,
    float_format: str = "%.4f",
    extra_classes: str = "",
    flag_to_text: Optional[dict] = None,
) -> str:
    """Render a DataFrame as HTML with per-row colored status.
    Row style is derived from the value in ``flag_col`` (case-insensitive):
    ``red`` -> soft red, ``orange/amber/yellow`` -> soft amber, otherwise no tint.
    ``red`` в†’ soft red, ``orange/orange/amber`` в†’ soft amber, otherwise no tint.

    Parameters
    ----------
    df : DataFrame
        Source table.
    flag_col : str
        Column whose value (red / orange / amber / yellow / green / blue / gray)
        drives the row color.
    drop_flag_col : bool
        If True, the ``flag_col`` is not rendered as a visible column; the
        background tint alone communicates the status.
    float_format : str
        Format spec for float cells (printf-style).
    extra_classes : str
        Extra CSS classes appended to the ``<table>`` tag.
    flag_to_text : dict
        Optional mapping to override visible text for the flag column
        (e.g. ``{"red": "RED"}``). Has no effect when ``drop_flag_col=True``.
    """
    if df is None or len(df) == 0:
        return "<p><i>No rows to display.</i></p>"

    visible_cols = [c for c in df.columns if not (drop_flag_col and c == flag_col)]
    head_html = "".join(f"<th>{c}</th>" for c in visible_cols)

    rows_html = []
    for _, row in df.iterrows():
        flag = str(row.get(flag_col, "") or "").strip().lower()
        row_style = _FLAG_ROW_STYLES.get(flag, {})
        if row_style:
            style = (
                f' style="background:{row_style["background"]};'
                f' color:{row_style["color"]};"'
            )
        else:
            style = ""
        flag_attr = f' data-sbs-row-flag="{flag}"' if flag else ""
        cells = []
        for col in visible_cols:
            val = row[col]
            if col == flag_col and flag_to_text:
                val = flag_to_text.get(flag, val)
            cells.append(f"<td>{_fmt_cell(val, float_format)}</td>")
        rows_html.append(f"<tr{flag_attr}{style}>{''.join(cells)}</tr>")

    cls_attr = f' class="{extra_classes}"' if extra_classes else ""
    return (
        f'<table border="1" cellpadding="6" cellspacing="0"'
        f' style="border-collapse:collapse"{cls_attr}>'
        f"<thead><tr>{head_html}</tr></thead>"
        f"<tbody>{''.join(rows_html)}</tbody>"
        f"</table>"
    )

PERIOD_LABELS = {
    "W": "Weekly",
    "M": "Monthly",
    "Q": "Quarterly",
}


def build_scale_specs(show_both_scales: bool, use_log_scale: bool) -> list[tuple[bool, str]]:
    if show_both_scales:
        return [
            (False, SCALE_TITLE_LINEAR),
            (True, SCALE_TITLE_LOG),
        ]
    return [
        (use_log_scale, SCALE_TITLE_LOG if use_log_scale else SCALE_TITLE_LINEAR),
    ]


def build_period_specs(requested_period: str | None) -> list[tuple[str, str]]:
    if requested_period is None:
        return [("W", PERIOD_LABELS["W"]), ("M", PERIOD_LABELS["M"]), ("Q", PERIOD_LABELS["Q"])]
    return [(requested_period, PERIOD_LABELS[requested_period])]


def figure_to_base64(fig) -> str:
    buf = BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    encoded = base64.b64encode(buf.getvalue()).decode("utf-8")
    plt.close(fig)
    return encoded


def apply_standard_axis_style(
    ax,
    *,
    title: str | None = None,
    xlabel: str | None = None,
    ylabel: str | None = None,
    legend_loc: str | None = "best",
    title_size: int = 13,
    label_size: int = 11,
) -> None:
    if title is not None:
        ax.set_title(title, fontsize=title_size, fontweight="bold", pad=12)
    if xlabel is not None:
        ax.set_xlabel(xlabel, fontsize=label_size)
    if ylabel is not None:
        ax.set_ylabel(ylabel, fontsize=label_size)
    ax.grid(True, linestyle="--", linewidth=0.6, alpha=0.3)
    handles, labels = ax.get_legend_handles_labels()
    if legend_loc and handles:
        ax.legend(loc=legend_loc, frameon=False)


def apply_secondary_axis_style(
    ax,
    *,
    ylabel: str | None = None,
    legend_loc: str | None = None,
    label_size: int = 11,
) -> None:
    if ylabel is not None:
        ax.set_ylabel(ylabel, fontsize=label_size)
    handles, labels = ax.get_legend_handles_labels()
    if legend_loc and handles:
        ax.legend(loc=legend_loc, frameon=False)


def build_tabbed_sections_html(
    tabs: list[dict],
    *,
    root_prefix: str = "tabs",
) -> str:
    root_id = f"{root_prefix}-{uuid4().hex}"
    button_html = []
    panel_html = []

    for idx, tab in enumerate(tabs):
        active = "true" if idx == 0 else "false"
        display = "block" if idx == 0 else "none"
        color = tab.get("color", COLORS["TAB_TEXT"])
        button_html.append(
            f"""
            <button type="button"
                    data-tab-target="{root_id}-panel-{idx}"
                    data-tab-button="{root_id}"
                    aria-selected="{active}"
                    style="padding:8px 14px; border:1px solid #d9dee8; background:#fff; cursor:pointer; border-radius:8px; color:{color}; font-weight:600;">
                {tab['label']}
            </button>
            """
        )
        panel_html.append(
            f"""
            <div id="{root_id}-panel-{idx}" data-tab-panel="{root_id}" style="display:{display}; margin-top:16px;">
                {tab['html']}
            </div>
            """
        )

    script = f"""
    <script>
    (function() {{
        var root = document.getElementById('{root_id}');
        if (!root) return;
        var buttons = root.querySelectorAll('button[data-tab-button="{root_id}"]');
        var panels = root.querySelectorAll('div[data-tab-panel="{root_id}"]');
        buttons.forEach(function(btn) {{
            btn.addEventListener('click', function() {{
                var targetId = btn.getAttribute('data-tab-target');
                buttons.forEach(function(other) {{ other.setAttribute('aria-selected', 'false'); }});
                panels.forEach(function(panel) {{ panel.style.display = 'none'; }});
                btn.setAttribute('aria-selected', 'true');
                var target = document.getElementById(targetId);
                if (target) target.style.display = 'block';
            }});
        }});
    }})();
    </script>
    """

    return f"""
    <div id="{root_id}">
        <div style="display:flex; gap:8px; flex-wrap:wrap; margin:14px 0 8px 0;">
            {''.join(button_html)}
        </div>
        {''.join(panel_html)}
    </div>
    {script}
    """
