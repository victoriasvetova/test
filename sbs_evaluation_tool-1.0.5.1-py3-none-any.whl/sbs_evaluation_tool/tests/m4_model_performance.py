"""Back-compat shim — real implementation now lives in the ``tests.m4`` subpackage."""

from .m4 import (
    M41_TargetRateTest,
    M42_CalibrationCurveByPredictBinsLn,
    M43_CalibrationCurveByDatesLn,
)
from .m4._legacy import (  # noqa: F401
    _LegacyMetricConfidenceIntervalTest,
    _LegacySampleSizeAdequacyTest,
    _LegacyCalibrationTest,
    _LegacyOverfittingTest,
    _LegacyMetricStabilityTest,
    _LegacyShapImportanceTest,
    _LegacyFeatureContributionTest,
    _LegacyUpliftTest,
    _LegacyMissingValuesImpactTest,
    _LegacyTwoForestSelectionTest,
)

__all__ = [
    "M41_TargetRateTest",
    "M42_CalibrationCurveByPredictBinsLn",
    "M43_CalibrationCurveByDatesLn",
]
