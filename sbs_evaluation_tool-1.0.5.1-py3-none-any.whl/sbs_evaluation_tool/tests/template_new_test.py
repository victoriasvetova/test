from typing import Dict
import io
import base64
import pandas as pd
import matplotlib.pyplot as plt
from ..core.base_test import BaseModelTest
from ..core.styles import figure


class MX1_ExampleTest(BaseModelTest):
    """
    Пример нового теста. Не участвует в отчёте, пока вы явно не зарегистрируете его в группе.

    Код: "M X.1"
    Название: "Пример теста"
    """

    def __init__(self):
        super().__init__(test_code="M X.1", test_name="Пример теста")

    def determine_signal(self, metrics: Dict[str, float]) -> str:
        """Определение сигнала по максимуму |z|-отклонения."""
        z = abs(metrics.get("z_score", 0.0))
        if z > 2.58:
            return "red"
        if z > 1.96:
            return "orange"
        return "green"

    def _fig_to_img_html(self, fig) -> str:
        buf = io.BytesIO()
        fig.savefig(buf, format="png", bbox_inches="tight", dpi=150)
        plt.close(fig)
        data = base64.b64encode(buf.getvalue()).decode("ascii")
        return f'<img src="data:image/png;base64,{data}" style="max-width:100%; height:auto;"/>'

    def run(self, df: pd.DataFrame, config: dict, **kwargs) -> Dict[str, str]:
        # Извлекаем служебные колонки
        date_col = config["columns"]["date_column"]
        target_col = config["columns"]["target_column"]

        # Подготовка данных
        work = df[[date_col, target_col]].dropna().copy()
        work[date_col] = pd.to_datetime(work[date_col])
        grp = work.groupby(pd.Grouper(key=date_col, freq="M"))[target_col]
        mean_true = grp.mean()
        std_true = grp.std(ddof=1)
        cnt = grp.size()
        se = std_true / cnt.clip(lower=1).pow(0.5)

        # Простейшая метрика: максимум |z| относительно глобального среднего
        global_mean = work[target_col].mean()
        z = ((mean_true - global_mean).abs() / se.replace({0: float("inf")})).fillna(0.0)
        metrics = {"z_score": float(z.replace([float("inf"), float("nan")], 0.0).max())}
        self.test_signal = self.determine_signal(metrics)
        self.test_meta = {"n_periods": int(cnt.gt(0).sum()), **metrics}

        # Визуализация с 95%/99% CI
        x = range(len(mean_true))
        lo95, hi95 = mean_true - 1.96*se, mean_true + 1.96*se
        lo99, hi99 = mean_true - 2.58*se, mean_true + 2.58*se

        fig, ax = figure(size="short")
        ax.fill_between(x, lo99, hi99, color="red", alpha=0.12, label="99% CI")
        ax.fill_between(x, lo95, hi95, color="orange", alpha=0.18, label="95% CI")
        ax.plot(x, mean_true.values, color="steelblue", lw=2, label="Mean target")
        ax.axhline(global_mean, color="gray", lw=1, ls="--", label="Global mean")
        ax.set_title(f"{self.test_code} {self.test_name}  |  signal: {self.test_signal}")
        ax.set_xlabel("Month")
        ax.set_ylabel("Target mean")
        ax.legend(loc="best")
        ax.set_xticks(list(x))
        ax.set_xticklabels([d.strftime("%Y-%m") for d in mean_true.index], rotation=45, ha="right")

        dashboard = f"""
        <div>
          <b>Signal:</b> <span style='color:{self.test_signal}'>{self.test_signal.upper()}</span><br>
          <b>Max |z|:</b> {metrics['z_score']:.2f}  |  <b>Periods:</b> {self.test_meta['n_periods']}
        </div>
        """
        html_plot = self._fig_to_img_html(fig)
        return {"DASHBOARD": dashboard + html_plot}
