"""Compatibility wrapper for `tests_blackbox.m8_fairness_tests`."""

from .tests_blackbox.m8_fairness_tests import *  # noqa: F401,F403
