"""M5 uplift tests: M5.1 Analysis of factor contribution to model quality (uplift test).

- Runs separately for 'train' and 'test' when `sample_column` exists (case-insensitive).
- Supports both classification and regression tasks; uses task-appropriate metrics.
- Produces a permutation-importance ranking and an incremental-addition curve for key metrics.

Notes:
- Default modelling uses RandomForestClassifier / RandomForestRegressor with fixed random_state.
- For efficiency, grouping of features is applied when number of features is large.
"""
from __future__ import annotations
from typing import Dict, List, Optional
import math
import numpy as np
import pandas as pd
from io import BytesIO
import base64
import matplotlib.pyplot as plt
import logging
import warnings
from tqdm.auto import tqdm

from ...core.base_test import BaseModelTest
from ...core.styles import COLORS, STATUS_COLORS
from ...core.config_validation import validate_config, ConfigValidationError
from ...core.metrics import gini as _gini_from_probs

# sklearn
try:
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    from sklearn.inspection import permutation_importance
    from sklearn.metrics import roc_auc_score, r2_score, mean_absolute_error, mean_squared_error
    from sklearn.feature_selection import mutual_info_classif, mutual_info_regression
    from sklearn.linear_model import LinearRegression
    SKLEARN = True
    # Suppress sklearn warnings about single class ROC AUC
    warnings.filterwarnings('ignore', 'Only one class is present in y_true', UserWarning, 'sklearn')
    warnings.filterwarnings('ignore', 'invalid value encountered', RuntimeWarning)
except Exception:
    SKLEARN = False

# shap
try:
    import shap
    SHAP_AVAILABLE = True
except Exception:
    SHAP_AVAILABLE = False

logger = logging.getLogger(__name__)


def _to_base64(fig) -> str:
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode('utf-8')


def _iv_for_feature(feature: pd.Series, target: pd.Series, n_bins: int = 10) -> float:
    # IV defined for binary target; if not binary return nan
    try:
        vals = target.dropna().unique()
        if len(vals) != 2:
            return float('nan')
        df = pd.DataFrame({'f': feature, 't': target}).dropna()
        if df.empty:
            return float('nan')
        # bin feature into quantiles
        try:
            df['b'] = pd.qcut(df['f'], q=min(n_bins, len(df)), duplicates='drop')
        except Exception:
            # fallback to regular bins
            df['b'] = pd.cut(df['f'], bins=min(n_bins, len(df)), duplicates='drop')
        grouped = df.groupby('b')
        total_good = float((df['t'] == vals[0]).sum())
        total_bad = float((df['t'] == vals[1]).sum())
        iv = 0.0
        for _, g in grouped:
            good = float((g['t'] == vals[0]).sum())
            bad = float((g['t'] == vals[1]).sum())
            dist_g = good / total_good if total_good > 0 else 0.0
            dist_b = bad / total_bad if total_bad > 0 else 0.0
            if dist_g > 0 and dist_b > 0:
                woe = math.log(dist_g / dist_b)
                iv += (dist_g - dist_b) * woe
        return float(iv)
    except Exception:
        return float('nan')


def _abs_corr(x: pd.Series, y: pd.Series) -> float:
    try:
        return abs(float(x.corr(y)))
    except Exception:
        return float('nan')


class M50_ShapImportanceTest(BaseModelTest):
    """M5.0 SHAP importance analysis for feature ranking.
    
    Computes SHAP values for training and test samples, provides feature importance ranking,
    and creates summary plots for feature contribution analysis.
    """
    def __init__(self, top_n: int = 20, random_state: int = 42):
        super().__init__('M 5.0', 'SHAP Feature Importance Analysis')
        self.top_n = top_n
        self.random_state = random_state

    def run(self, df: pd.DataFrame = None, config: dict = None, model=None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M5.0 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        if not SKLEARN:
            return {"report": "<h4>M5.0 skipped</h4><p>scikit-learn is required for this test.</p>"}
            
        if not SHAP_AVAILABLE:
            return {"report": "<h4>M5.0 skipped</h4><p>SHAP library is not available in the environment.</p>"}

        task = getattr(cfg, 'task', None)
        if task not in ('classification', 'regression'):
            return {"report": "<h4>M5.0 skipped</h4><p>Task must be 'classification' or 'regression'.</p>"}

        logger.info(f"Starting M5.0 SHAP Analysis with {len(df)} rows, task: {task}")

        sample_col = getattr(cfg.columns, 'sample_column', None)
        if not sample_col or sample_col not in df.columns:
            return {"report": "<h4>M5.0 skipped</h4><p>sample_column with 'train' and 'test' values required.</p>"}

        # get train/test
        s = df[sample_col].astype(str).str.lower()
        if 'train' not in s.unique() or 'test' not in s.unique():
            return {"report": "<h4>M5.0 skipped</h4><p>Both 'train' and 'test' samples must be present in sample_column.</p>"}

        df_train = df[s == 'train'].copy()
        df_test = df[s == 'test'].copy()
        
        logger.info(f"Train sample: {len(df_train)} rows, Test sample: {len(df_test)} rows")

        target_col = cfg.columns.target_column
        if target_col not in df.columns:
            return {"report": f"<h4>M5.0 skipped</h4><p>Target column '{target_col}' missing.</p>"}

        # Select features
        features = []
        try:
            nf = getattr(cfg.columns, 'numeric_features', None)
            cf = getattr(cfg.columns, 'categorical_features', None)
            if nf:
                features.extend(list(nf))
            if cf:
                features.extend(list(cf))
        except Exception:
            pass
            
        # fallback: all columns except reserved
        reserved = set([getattr(cfg.columns, 'target_column', ''), getattr(cfg.columns, 'id_column', ''), 
                       getattr(cfg.columns, 'date_column', ''), getattr(cfg.columns, 'sample_column', ''), 
                       getattr(cfg.columns, 'prediction_column', ''), getattr(cfg.columns, 'score_column', '')])
        if not features:
            features = [c for c in df.columns if c not in reserved]
        
        features = [c for c in features if c in df.columns]
        if not features:
            return {"report": "<h4>M5.0 skipped</h4><p>No candidate features found.</p>"}
            
        logger.info(f"Selected {len(features)} features for SHAP analysis")

        # Prepare data
        X_train = df_train[features].copy()
        X_test = df_test[features].copy()
        y_train = df_train[target_col]
        y_test = df_test[target_col]

        # Simple preprocessing: fillna with mean for numeric
        X_train = X_train.fillna(X_train.mean())
        X_test = X_test.fillna(X_train.mean())

        # Fit model if not provided
        if model is None:
            logger.info("Fitting new model for SHAP analysis")
            if task == 'classification':
                model = RandomForestClassifier(n_estimators=100, random_state=self.random_state, n_jobs=-1)
            else:
                model = RandomForestRegressor(n_estimators=100, random_state=self.random_state, n_jobs=-1)
            model.fit(X_train, y_train)

        try:
            logger.info("Computing SHAP values for train and test samples")
            # Create explainer
            explainer = shap.TreeExplainer(model)
            
            # Compute SHAP values for samples (limit size for performance)
            train_sample_size = min(500, len(X_train))
            test_sample_size = min(500, len(X_test))
            
            X_train_sample = X_train.sample(n=train_sample_size, random_state=self.random_state)
            X_test_sample = X_test.sample(n=test_sample_size, random_state=self.random_state)
            
            logger.debug(f"Computing SHAP for {train_sample_size} train and {test_sample_size} test samples")
            
            shap_values_train = explainer.shap_values(X_train_sample)
            shap_values_test = explainer.shap_values(X_test_sample)
            
            # For classification, handle multi-class output
            if task == 'classification' and isinstance(shap_values_train, list):
                # Take positive class (class 1) for binary classification
                shap_values_train = shap_values_train[1] if len(shap_values_train) > 1 else shap_values_train[0]
                shap_values_test = shap_values_test[1] if len(shap_values_test) > 1 else shap_values_test[0]

            # Calculate mean absolute SHAP values for feature importance
            shap_importance_train = np.abs(shap_values_train).mean(0)
            shap_importance_test = np.abs(shap_values_test).mean(0)
            
            # Create importance dataframe
            importance_df = pd.DataFrame({
                'feature': features,
                'shap_importance_train': shap_importance_train,
                'shap_importance_test': shap_importance_test
            })
            importance_df['shap_importance_avg'] = (importance_df['shap_importance_train'] + importance_df['shap_importance_test']) / 2
            importance_df = importance_df.sort_values('shap_importance_avg', ascending=False)
            
            logger.info(f"SHAP analysis completed. Top feature: {importance_df.iloc[0]['feature']}")

            # Create summary plots
            plots_html = []
            
            # Train SHAP summary plot
            plt.figure(figsize=(10, 6))
            shap.summary_plot(shap_values_train, X_train_sample, show=False, max_display=self.top_n)
            plt.title('SHAP Summary Plot - Training Data')
            plt.tight_layout()
            img1 = _to_base64(plt.gcf())
            plots_html.append(f'<h5>SHAP Summary Plot - Training Data</h5><img src="data:image/png;base64,{img1}" />')

            # Test SHAP summary plot
            plt.figure(figsize=(10, 6))
            shap.summary_plot(shap_values_test, X_test_sample, show=False, max_display=self.top_n)
            plt.title('SHAP Summary Plot - Test Data')
            plt.tight_layout()
            img2 = _to_base64(plt.gcf())
            plots_html.append(f'<h5>SHAP Summary Plot - Test Data</h5><img src="data:image/png;base64,{img2}" />')

            # Feature importance comparison plot
            top_features = importance_df.head(self.top_n)
            fig, ax = plt.subplots(figsize=(10, 6))
            x = np.arange(len(top_features))
            width = 0.35
            
            ax.barh(x - width/2, top_features['shap_importance_train'], width, label='Train', alpha=0.8)
            ax.barh(x + width/2, top_features['shap_importance_test'], width, label='Test', alpha=0.8)
            
            ax.set_xlabel('Mean |SHAP value|')
            ax.set_title(f'SHAP Feature Importance Comparison (Top {self.top_n})')
            ax.set_yticks(x)
            ax.set_yticklabels(top_features['feature'])
            ax.legend()
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            
            img3 = _to_base64(fig)
            plots_html.append(f'<h5>SHAP Feature Importance Comparison</h5><img src="data:image/png;base64,{img3}" />')

            # Calculate feature importance stability (correlation between train and test)
            correlation = np.corrcoef(importance_df['shap_importance_train'], importance_df['shap_importance_test'])[0, 1]
            
            # Determine signal based on importance stability
            if correlation > 0.8:
                signal = 'green'
                reason = 'High correlation between train/test SHAP importance (>0.8)'
            elif correlation > 0.6:
                signal = 'orange' 
                reason = 'Moderate correlation between train/test SHAP importance (0.6-0.8)'
            else:
                signal = 'red'
                reason = 'Low correlation between train/test SHAP importance (<0.6)'

            self.test_signal = signal
            self.test_meta = {
                'feature_importance': importance_df.to_dict('records'),
                'correlation': correlation,
                'top_features': list(top_features['feature']),
                'shap_available': True
            }

            html = f"<h4>M5.0 SHAP Feature Importance Analysis</h4>"
            html += f"<p><b>Signal:</b> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span> вЂ” {reason}</p>"
            html += f"<p><b>Train-Test Importance Correlation:</b> {correlation:.3f}</p>"
            html += "".join(plots_html)
            html += f"<h5>Top {len(top_features)} Features by SHAP Importance</h5>"
            html += top_features[['feature', 'shap_importance_train', 'shap_importance_test', 'shap_importance_avg']].to_html(index=False, float_format='%.4f')

            return {"DASHBOARD": html}

        except Exception as e:
            logger.exception("SHAP analysis failed")
            self.test_signal = 'red'
            self.test_meta = {'shap_available': False, 'error': str(e)}
            return {"report": f"<h4>M5.0 SHAP Analysis Failed</h4><p>Error: {str(e)}</p>"}


class M51_UpliftTest(BaseModelTest):
    """M5.1 Uplift test: incremental feature addition focused on Gini metric.

    Parameters (constructor):
      - model_type: 'rf' (default) or others in future
      - group_size: int or None - number of features to add per step; if None, automatic grouping is used
      - feature_order: 'shap', 'permutation', 'random' - how to order features for incremental addition
      - shap_importance: pd.Series - SHAP importance from M5.0 test (if available)
    """
    def __init__(self, model_type: str = 'rf', group_size: Optional[int] = None, 
                 feature_order: str = 'shap', shap_importance: Optional[pd.Series] = None, 
                 random_state: int = 42):
        super().__init__('M 5.1', 'Uplift: feature incremental Gini analysis')
        self.model_type = model_type
        self.group_size = group_size
        self.feature_order = feature_order  # 'shap', 'permutation', 'random'
        self.shap_importance = shap_importance
        self.random_state = int(random_state)

    def _select_features(self, cfg, df: pd.DataFrame) -> List[str]:
        # Try to read numeric_features and categorical_features from config columns
        cols = []
        try:
            nf = getattr(cfg.columns, 'numeric_features', None)
            cf = getattr(cfg.columns, 'categorical_features', None)
            if nf:
                cols.extend(list(nf))
            if cf:
                cols.extend(list(cf))
        except Exception:
            pass
        # fallback: all columns except reserved
        reserved = set([getattr(cfg.columns, 'target_column', ''), getattr(cfg.columns, 'id_column', ''), getattr(cfg.columns, 'date_column', ''), getattr(cfg.columns, 'sample_column', ''), getattr(cfg.columns, 'prediction_column', ''), getattr(cfg.columns, 'score_column', '')])
        if not cols:
            cols = [c for c in df.columns if c not in reserved]
        # filter out non-numeric/categorical that are obviously complex
        cols = [c for c in cols if c in df.columns]
        return cols

    def _fit_base_model(self, X: pd.DataFrame, y: pd.Series, task: str):
        if task == 'classification':
            model = RandomForestClassifier(n_estimators=100, random_state=self.random_state, n_jobs=-1)
        else:
            model = RandomForestRegressor(n_estimators=100, random_state=self.random_state, n_jobs=-1)
        model.fit(X, y)
        return model

    def _get_feature_order(self, features: List[str], X_train: pd.DataFrame, y_train: pd.Series, task: str) -> List[str]:
        """Get feature ordering based on specified method."""
        logger.info(f"Determining feature order using method: {self.feature_order}")
        
        if self.feature_order == 'shap' and self.shap_importance is not None:
            # Use SHAP importance from M5.0 test
            logger.info("Using SHAP importance for feature ordering")
            # Filter to only features we have
            available_features = [f for f in self.shap_importance.index if f in features]
            if available_features:
                return available_features
            else:
                logger.warning("No features from SHAP importance found, falling back to permutation")
                
        if self.feature_order == 'random':
            # Random order
            logger.info("Using random feature ordering")
            import random
            random.seed(self.random_state)
            ordered = features.copy()
            random.shuffle(ordered)
            return ordered
            
        # Default: permutation importance
        logger.info("Computing permutation importance for feature ordering")
        model_full = self._fit_base_model(X_train, y_train, task)
        try:
            pi = permutation_importance(model_full, X_train, y_train, n_repeats=10, 
                                      random_state=self.random_state, n_jobs=-1)
            importances = pd.Series(pi.importances_mean, index=features).sort_values(ascending=False)
            return list(importances.index)
        except Exception:
            # fallback to feature importances from tree
            try:
                importances = pd.Series(getattr(model_full, 'feature_importances_', 
                                              np.zeros(len(features))), index=features).sort_values(ascending=False)
                return list(importances.index)
            except Exception:
                logger.warning("Failed to compute feature importance, using original order")
                return features

    def _compute_metrics(self, task: str, y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
        """Compute Gini metric similar to Main_metrics.py calc_gini function."""
        if task == 'classification':
            try:
                # Use sklearn's roc_auc_score like in Main_metrics
                if y_pred.ndim == 2:
                    # if multiclass probabilities, take positive class (index 1)
                    prob = y_pred[:, 1] if y_pred.shape[1] > 1 else y_pred[:, 0]
                else:
                    prob = y_pred
                
                # Calculate AUC and convert to Gini (like calc_gini function)
                auc = roc_auc_score(y_true, prob)
                gini = float(2.0 * auc - 1.0)  # Standard Gini formula: 2*AUC - 1
                
                logger.debug(f"Computed AUC: {auc:.4f}, Gini: {gini:.4f}")
                return {'gini': gini, 'auc': auc}
                
            except Exception as e:
                logger.warning(f"Failed to compute Gini: {e}")
                return {'gini': float('nan'), 'auc': float('nan')}
        else:
            # For regression, use correlation as quality metric
            try:
                correlation = float(abs(np.corrcoef(y_true, y_pred)[0, 1]))
                # Scale correlation to be more Gini-like (0 to 1 range)
                gini_like = correlation  # correlation already in [0,1] range for abs()
                
                logger.debug(f"Computed correlation: {correlation:.4f} (as Gini-like metric)")
                return {'gini': gini_like, 'correlation': correlation}
                
            except Exception as e:
                logger.warning(f"Failed to compute correlation: {e}")
                return {'gini': float('nan'), 'correlation': float('nan')}

    def _predict_for_model(self, m, X, task):
        """Get predictions from model in appropriate format."""
        try:
            if task == 'classification':
                if hasattr(m, 'predict_proba'):
                    proba = m.predict_proba(X)
                    # if binary, take column 1 (positive class)
                    if proba.ndim == 2 and proba.shape[1] >= 2:
                        return proba[:, 1]
                    return proba[:, 0]
                else:
                    return m.predict(X)
            else:
                return m.predict(X)
        except Exception:
            # last resort
            return m.predict(X)

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M5.1 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        if not SKLEARN:
            return {"report": "<h4>M5.1 skipped</h4><p>scikit-learn is required for this test.</p>"}

        task = getattr(cfg, 'task', None)
        if task not in ('classification', 'regression'):
            return {"report": "<h4>M5.1 skipped</h4><p>Task must be 'classification' or 'regression'.</p>"}

        logger.info(f"Starting M5.1 Uplift Test with {len(df)} rows, task: {task}")

        sample_col = getattr(cfg.columns, 'sample_column', None)
        if not sample_col or sample_col not in df.columns:
            logger.info('M5.1 skipped: sample_column not present')
            return {"report": "<h4>M5.1 skipped</h4><p>sample_column with 'train' and 'test' values required for paired analysis.</p>"}

        # get train/test
        s = df[sample_col].astype(str).str.lower()
        if 'train' not in s.unique() or 'test' not in s.unique():
            return {"report": "<h4>M5.1 skipped</h4><p>Both 'train' and 'test' samples must be present in sample_column.</p>"}

        df_train = df[s == 'train'].copy()
        df_test = df[s == 'test'].copy()
        
        logger.info(f"Train sample: {len(df_train)} rows, Test sample: {len(df_test)} rows")

        target_col = cfg.columns.target_column
        if target_col not in df.columns:
            return {"report": f"<h4>M5.1 skipped</h4><p>Target column '{target_col}' missing.</p>"}

        features = self._select_features(cfg, df_train)
        if not features:
            logger.info('M5.1 skipped: no candidate features found')
            return {"report": "<h4>M5.1 skipped</h4><p>No candidate features found.</p>"}
            
        logger.info(f"Selected {len(features)} features: {features[:5]}{'...' if len(features) > 5 else ''}")

        # prepare X/y
        X_train = df_train[features].copy()
        X_test = df_test[features].copy()
        y_train = df_train[target_col]
        y_test = df_test[target_col]

        # simple preprocessing: drop rows with NA in target; impute numeric NAs with mean
        X_train = X_train.fillna(X_train.mean())
        X_test = X_test.fillna(X_train.mean())

        logger.info('M5.1: determining feature order and computing baseline')
        
        # Get feature ordering
        ordered = self._get_feature_order(features, X_train, y_train, task)
        logger.info(f"Feature order determined using '{self.feature_order}' method")
        logger.info(f"Top 5 features: {ordered[:5]}")
        
        # Compute baseline Gini using ALL features (like Main_metrics approach)
        logger.info("Computing baseline model with all features...")
        model_full = self._fit_base_model(X_train, y_train, task)
        y_pred_full_test = self._predict_for_model(model_full, X_test, task)
        full_metrics = self._compute_metrics(task, y_test.values, np.array(y_pred_full_test))
        baseline_gini = full_metrics.get('gini', float('nan'))
        
        logger.info(f"Baseline Gini with ALL {len(features)} features: {baseline_gini:.4f}")

        # Determine step size for incremental addition
        n = len(ordered)
        if self.group_size and self.group_size > 0:
            step = int(self.group_size)
        else:
            # Auto step: 1 for small datasets, larger for big ones
            step = 1 if n <= 20 else max(2, int(n * 0.05))  # 5% of features per step

        logger.info(f'Starting incremental feature addition: {n} features, step size = {step}')
        
        # MAIN UPLIFT LOGIC: Add features incrementally and measure Gini
        results = []
        best_gini = -float('inf')
        optimal_n_features = len(features)
        
        # Try different numbers of features: step, 2*step, 3*step, ..., all
        feature_counts_to_try = list(range(step, n + 1, step))
        if n not in feature_counts_to_try:
            feature_counts_to_try.append(n)  # Always include all features
            
        logger.info(f"Will try these feature counts: {feature_counts_to_try}")
        
        progress_bar = tqdm(feature_counts_to_try, desc='Testing feature subsets', leave=True)
        for n_features in progress_bar:
            progress_bar.set_description(f'Testing {n_features}/{n} features')
            
            # Select top N features according to our ordering
            selected_features = ordered[:n_features]
            
            # Prepare train/test data with selected features
            X_train_subset = X_train[selected_features]
            X_test_subset = X_test[selected_features]
            
            try:
                # Train model with this subset
                model = self._fit_base_model(X_train_subset, y_train, task)
                
                # Get predictions
                y_train_pred = self._predict_for_model(model, X_train_subset, task)
                y_test_pred = self._predict_for_model(model, X_test_subset, task)
                
                # Compute Gini (like calc_gini in Main_metrics)
                train_metrics = self._compute_metrics(task, y_train.values, np.array(y_train_pred))
                test_metrics = self._compute_metrics(task, y_test.values, np.array(y_test_pred))
                
                train_gini = train_metrics.get('gini', float('nan'))
                test_gini = test_metrics.get('gini', float('nan'))
                
                # Track best performance
                if not math.isnan(test_gini) and test_gini > best_gini:
                    best_gini = test_gini
                    optimal_n_features = n_features
                
                # Store result
                results.append({
                    'n_features': n_features,
                    'features': selected_features,
                    'train_gini': train_gini,
                    'test_gini': test_gini,
                    'train_auc': train_metrics.get('auc', float('nan')),
                    'test_auc': test_metrics.get('auc', float('nan'))
                })
                
                logger.debug(f"With {n_features} features: Train Gini={train_gini:.4f}, Test Gini={test_gini:.4f}")
                
            except Exception as e:
                logger.error(f"Failed to train model with {n_features} features: {e}")
                results.append({
                    'n_features': n_features,
                    'features': selected_features,
                    'train_gini': float('nan'),
                    'test_gini': float('nan'),
                    'train_auc': float('nan'),
                    'test_auc': float('nan')
                })

        # INTERPRETATION LOGIC (simple and clear)
        logger.info(f"Best test Gini: {best_gini:.4f} with {optimal_n_features} features")
        logger.info(f"Baseline (all features) Gini: {baseline_gini:.4f}")
        
        # Simple interpretation rules:
        improvement_threshold = 0.02  # 2% improvement threshold
        degradation_threshold = 0.01  # 1% degradation threshold
        
        if not math.isnan(best_gini) and not math.isnan(baseline_gini):
            improvement = best_gini - baseline_gini
            improvement_pct = improvement / abs(baseline_gini) if baseline_gini != 0 else 0
            
            logger.info(f"Improvement: {improvement:.4f} ({improvement_pct:.1%})")
            
            if improvement > improvement_threshold:
                overall_signal = 'red'  # Significant improvement with fewer features = model has redundant features
                reason = f"Subset of {optimal_n_features} features performs {improvement:.4f} better than all features"
            elif improvement < -degradation_threshold:
                overall_signal = 'green'  # All features needed
                reason = f"All features needed - removing features degrades performance by {-improvement:.4f}"
            else:
                overall_signal = 'orange'  # Marginal difference
                reason = f"Marginal difference ({improvement:.4f}) between optimal subset and all features"
        else:
            overall_signal = 'orange'
            reason = "Could not compute reliable comparison due to NaN values"

        logger.info(f'M5.1 completed: {overall_signal} - {reason}')
        logger.info(f'M5.1 completed: {overall_signal} - {reason}')

        # Build simple feature ranking table
        feature_table = pd.DataFrame({
            'rank': range(1, len(ordered) + 1),
            'feature': ordered,
            'order_method': [self.feature_order] * len(ordered)
        })

        # Plot Gini uplift curve (clear and simple)
        n_feats = [r['n_features'] for r in results]
        train_ginis = [r.get('train_gini', float('nan')) for r in results]
        test_ginis = [r.get('test_gini', float('nan')) for r in results]

        fig, ax = plt.subplots(figsize=(12, 8))

        # Main curves
        ax.plot(n_feats, train_ginis, label='Train Gini', marker='o', linewidth=2, markersize=6)
        ax.plot(n_feats, test_ginis, label='Test Gini', marker='s', linewidth=2, markersize=6)

        # Reference lines
        ax.axhline(baseline_gini, color='gray', linestyle='--', linewidth=1,
                   label=f'Baseline (all {len(features)} features): {baseline_gini:.3f}')
        ax.axvline(optimal_n_features, color='red', linestyle=':', alpha=0.7,
                   label=f'Optimal: {optimal_n_features} features (Gini: {best_gini:.3f})')

        # Styling
        ax.set_xlabel('Number of Features', fontsize=12)
        ax.set_ylabel('Gini Coefficient', fontsize=12)
        ax.set_title(
            f'Feature Uplift Analysis - {self.feature_order.title()} Ordering\n'
            f'Task: {task.title()}, Signal: {overall_signal.upper()}', fontsize=14
        )
        ax.legend(loc='best', frameon=True, shadow=True)
        ax.grid(True, alpha=0.3)
        
        # Set reasonable y-axis limits
        all_ginis = [g for g in train_ginis + test_ginis + [baseline_gini] if not math.isnan(g)]
        if all_ginis:
            y_min = min(all_ginis) - 0.05
            y_max = max(all_ginis) + 0.05
            ax.set_ylim(y_min, y_max)
        
        plt.tight_layout()
        img = _to_base64(fig)

        # Build clear HTML report
        html = f"<h4>M5.1 Feature Uplift Test - Clear Gini Analysis</h4>"
        html += f"<div style='background-color: #f0f0f0; padding: 10px; margin: 10px 0; border-radius: 5px;'>"
        html += f"<p><b>рџ“Љ Task:</b> {task.title()}</p>"
        html += f"<p><b>рџ”„ Feature ordering method:</b> {self.feature_order.title()}</p>"
        html += f"<p><b>рџЋЇ Signal:</b> <span style='color:{overall_signal}; font-weight:bold; font-size:1.2em'>{overall_signal.upper()}</span></p>"
        html += f"<p><b>рџ’Ў Interpretation:</b> {reason}</p>"
        html += f"</div>"
        
        html += f"<div style='background-color: #f9f9f9; padding: 10px; margin: 10px 0; border-left: 4px solid #4CAF50;'>"
        html += f"<h5>рџ“€ Key Results:</h5>"
        html += f"<ul>"
        html += f"<li><b>Baseline Gini</b> (all {len(features)} features): {baseline_gini:.4f}</li>"
        html += f"<li><b>Best Gini</b> ({optimal_n_features} features): {best_gini:.4f}</li>"
        html += f"<li><b>Improvement:</b> {best_gini - baseline_gini:+.4f}</li>"
        html += f"<li><b>Optimal feature count:</b> {optimal_n_features}/{len(features)} ({optimal_n_features/len(features)*100:.1f}%)</li>"
        html += f"</ul>"
        html += f"</div>"
        
        html += f"<h5>рџ“Љ Uplift Curve</h5>"
        html += f"<p><i>Shows how Gini changes as we add features in order of importance</i></p>"
        html += f"<img src=\"data:image/png;base64,{img}\" style='max-width: 100%; height: auto;' />"
        
        html += f"<h5>рџЏ† Top 15 Features by Importance</h5>"
        html += feature_table.head(15).to_html(index=False, classes="table table-striped", table_id="feature_ranking")

        # Results summary table
        df_steps = pd.DataFrame([
            {
                'n_features': r['n_features'], 
                'train_gini': r.get('train_gini', float('nan')), 
                'test_gini': r.get('test_gini', float('nan')),
                'improvement_vs_baseline': r.get('test_gini', float('nan')) - baseline_gini
            } for r in results
        ])
        
        html += f"<h5>рџ“‹ Detailed Results</h5>"
        html += f"<p><i>Performance at each step of feature addition</i></p>"
        html += df_steps.to_html(index=False, float_format='%.4f', classes="table table-striped")

        # Store metadata
        self.test_signal = overall_signal
        self.test_meta = {
            'feature_order_method': self.feature_order,
            'optimal_n_features': optimal_n_features,
            'best_test_gini': best_gini,
            'baseline_gini': baseline_gini,
            'improvement': best_gini - baseline_gini,
            'interpretation': reason,
            'feature_ranking': feature_table.to_dict(orient='records'),
            'detailed_results': df_steps.to_dict(orient='records')
        }
        
        return {"DASHBOARD": html}
