"""M4 calibration tests: M4.1 Predicted vs actual level comparison (classification and regression).

For CLASSIFICATION:
Test M4.1 compares mean predicted probability for each class to the observed frequency.
It computes 95% and 99% confidence intervals around the mean predicted probability
(using standard error of the mean of predicted probabilities) and classifies each class
as red/orange/green according to containment of the observed frequency in CI.

For REGRESSION:
Test M4.1 performs calibration analysis by dividing predictions into quantile bins
and comparing mean predicted values vs mean actual values within each bin.
It computes confidence intervals for predicted means and evaluates calibration quality.

If `sample_column` exists in config and df, the test runs separately for 'train' and 'test'
(case-insensitive) and returns a combined HTML dashboard and per-sample meta.
"""
from __future__ import annotations
from typing import Dict, List, Optional
import numpy as np
import pandas as pd
import math
from io import BytesIO
import base64
import matplotlib.pyplot as plt

from ...core.base_test import BaseModelTest
from ...core.config_validation import validate_config, ConfigValidationError

import logging
from tqdm.auto import tqdm

logger = logging.getLogger(__name__)


def _to_base64(fig) -> str:
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode('utf-8')


def _find_score_col_for_class(df: pd.DataFrame, base_score_col: Optional[str], cls) -> Optional[pd.Series]:
    """Try to find predicted probability column for a class (same heuristics as other tests)."""
    if base_score_col and base_score_col in df.columns and df[base_score_col].dtype.kind in 'fiu':
        return df[base_score_col]
    candidates = []
    if base_score_col:
        candidates.extend([f"{base_score_col}_{cls}", f"{base_score_col}{cls}", f"{base_score_col}-{cls}"])
    candidates.extend([f"prob_{cls}", f"p_{cls}", f"score_{cls}", f"proba_{cls}"])
    for c in candidates:
        if c in df.columns:
            return df[c]
    return None


class M41_PredictedVsActualLevelTest(BaseModelTest):
    """M4.1 Comparison of predicted and actual levels of the target variable.

    For CLASSIFICATION:
    Computes for each class K:
      Pbar_K = mean predicted probability for class K across N rows
      nu_K = observed frequency of class K (count/N)

    Builds 95% and 99% CI around Pbar_K using se = sqrt(var(p_i)/N) and z-scores.
    Per-class signal:
      - RED if nu_K not in CI_99
      - ORANGE if nu_K not in CI_95 but in CI_99
      - GREEN if nu_K in CI_95

    For REGRESSION:
    Divides predictions into quantile bins and compares:
      Pbar_bin = mean predicted value in bin
      Ybar_bin = mean actual value in bin
    
    Builds CI around prediction means and evaluates calibration quality.
    """
    def __init__(self):
        super().__init__('M 4.1 (classification and regression)', 'Calibration: predicted vs actual level')

    def _compute_for_df_regression(self, df_sub: pd.DataFrame, cfg: object) -> Optional[Dict]:
        """Compute calibration analysis for regression task using quantile bins."""
        target = cfg.columns.target_column
        score_col = cfg.columns.score_column
        
        if target not in df_sub.columns:
            logger.warning(f"Target column {target} not found in data")
            return None
            
        if score_col not in df_sub.columns:
            logger.warning(f"Score column {score_col} not found in data")
            return None

        # Clean data
        clean_data = df_sub[[target, score_col]].dropna()
        if len(clean_data) < 10:
            logger.warning(f"Insufficient clean data: {len(clean_data)} rows")
            return None
            
        y_true = clean_data[target].astype(float).values
        y_pred = clean_data[score_col].astype(float).values
        
        logger.info(f"Regression calibration analysis with {len(clean_data)} clean observations")
        
        # Calculate global statistics for CI construction
        global_pred_mean = float(np.mean(y_pred))
        global_pred_var = float(np.var(y_pred, ddof=0))
        global_se = math.sqrt(global_pred_var / len(clean_data))
        
        # Global confidence intervals around mean predicted value
        z95 = 1.959963984540054
        z99 = 2.5758293035489004
        global_ci95 = (global_pred_mean - z95 * global_se, global_pred_mean + z95 * global_se)
        global_ci99 = (global_pred_mean - z99 * global_se, global_pred_mean + z99 * global_se)
        
        logger.info(f"Global prediction mean: {global_pred_mean:.4f}, CI95: {global_ci95}, CI99: {global_ci99}")
        
        # Create quantile bins (default 10 bins)
        n_bins = min(10, len(clean_data) // 5)  # At least 5 observations per bin
        n_bins = max(3, n_bins)  # At least 3 bins
        
        try:
            # Create bins based on prediction quantiles
            bin_edges = np.quantile(y_pred, np.linspace(0, 1, n_bins + 1))
            bin_edges = np.unique(bin_edges)  # Remove duplicates
            if len(bin_edges) < 3:
                logger.warning("Too few unique prediction values for binning")
                return None
                
            # Assign observations to bins
            bin_indices = np.digitize(y_pred, bin_edges[1:-1])
            
            per_bin = []
            n_red = 0
            n_orange = 0
            red_obs = 0
            orange_obs = 0
            total_obs = len(clean_data)
            
            logger.debug(f"Created {len(bin_edges)-1} bins for regression analysis")
            
            for bin_idx in range(len(bin_edges) - 1):
                mask = (bin_indices == bin_idx)
                if not np.any(mask):
                    continue
                    
                bin_y_true = y_true[mask]
                bin_y_pred = y_pred[mask]
                bin_size = len(bin_y_true)
                
                # Statistics for this bin
                pred_mean = float(np.mean(bin_y_pred))
                actual_mean = float(np.mean(bin_y_true))
                
                # Use global CI for comparison (same for all bins)
                ci95 = global_ci95
                ci99 = global_ci99
                
                logger.debug(f"Bin {bin_idx+1}: size={bin_size}, pred_mean={pred_mean:.4f}, actual_mean={actual_mean:.4f}")
                
                # Determine signal based on whether actual mean falls in prediction CI
                if math.isnan(actual_mean) or math.isnan(pred_mean):
                    sig = 'na'
                else:
                    if not (ci99[0] <= actual_mean <= ci99[1]):
                        sig = 'red'
                        n_red += 1
                        red_obs += bin_size
                    elif not (ci95[0] <= actual_mean <= ci95[1]):
                        sig = 'orange'
                        n_orange += 1
                        orange_obs += bin_size
                    else:
                        sig = 'green'
                        
                logger.debug(f"Bin {bin_idx+1} signal: {sig}")
                
                per_bin.append({
                    'bin': f'Bin {bin_idx+1}',
                    'bin_range': f'[{bin_edges[bin_idx]:.3f}, {bin_edges[bin_idx+1]:.3f}]',
                    'size': bin_size,
                    'pred_mean': pred_mean,
                    'actual_mean': actual_mean,
                    'ci95': ci95,
                    'ci99': ci99,
                    'signal': sig
                })
            
            if not per_bin:
                logger.warning("No valid bins created")
                return None
                
            total_bins = len(per_bin)
            frac_red_bins = n_red / max(1, total_bins)
            frac_orange_bins = n_orange / max(1, total_bins)
            frac_red_orange = (n_red + n_orange) / max(1, total_bins)
            red_obs_share = red_obs / max(1, total_obs)
            orange_obs_share = orange_obs / max(1, total_obs)
            
            logger.info(f"Red bins: {n_red}/{total_bins} ({frac_red_bins:.2%}), Orange bins: {n_orange}/{total_bins} ({frac_orange_bins:.2%})")
            logger.info(f"Red obs share: {red_obs_share:.2%}, Orange obs share: {orange_obs_share:.2%}")
            
            # Overall signal (similar logic to classification)
            if frac_red_bins > 0.20 or red_obs_share > 0.15:
                overall = 'red'
            elif (frac_red_orange <= 0.20) and (orange_obs_share <= 0.15) and (red_obs_share <= 0.05):
                overall = 'green'
            else:
                overall = 'orange'
                
            logger.info(f"Regression overall signal: {overall}")
            
            return {
                'per_bin': per_bin, 
                'overall': overall, 
                'meta': {
                    'n_bins': total_bins,
                    'frac_red_bins': frac_red_bins, 
                    'frac_orange_bins': frac_orange_bins, 
                    'red_obs_share': red_obs_share, 
                    'orange_obs_share': orange_obs_share,
                    'global_pred_mean': global_pred_mean,
                    'global_ci95': global_ci95,
                    'global_ci99': global_ci99,
                    'task': 'regression'
                }
            }
            
        except Exception as e:
            logger.error(f"Error in regression calibration analysis: {e}")
            return None

    def _compute_for_df(self, df_sub: pd.DataFrame, cfg: object) -> Optional[Dict]:
        """Route to appropriate computation method based on task type."""
        task = getattr(cfg, 'task', 'classification')
        
        if task == 'regression':
            return self._compute_for_df_regression(df_sub, cfg)
        else:
            return self._compute_for_df_classification(df_sub, cfg)
    
    def _compute_for_df_classification(self, df_sub: pd.DataFrame, cfg: object) -> Optional[Dict]:
        """Original classification logic."""
        target = cfg.columns.target_column
        score_col = cfg.columns.score_column
        if target not in df_sub.columns:
            logger.warning(f"Target column {target} not found in data")
            return None
            
        classes = sorted(df_sub[target].dropna().unique())
        if len(classes) == 0:
            logger.warning("No valid classes found in target column")
            return None
            
        logger.info(f"Found {len(classes)} classes: {classes}")
        
        N = len(df_sub)
        per_class = []
        n_red = 0
        n_orange = 0
        red_obs = 0
        orange_obs = 0
        found_any = False

        logger.debug(f"Processing {N} observations across {len(classes)} classes")

        for cls in tqdm(classes, desc='Processing classes', leave=False):
            col = _find_score_col_for_class(df_sub, score_col, cls)
            if col is None:
                logger.warning(f"No probability column found for class {cls}")
                # cannot compute for this class
                per_class.append({'class': cls, 'pred_mean': float('nan'), 'obs_frac': float('nan'), 'ci95': (None, None), 'ci99': (None, None), 'signal': 'na'})
                continue
                
            found_any = True
            logger.debug(f"Using column {col.name} for class {cls}")
            
            # ensure numeric and align to full N (fillna with 0 to preserve denominator as N)
            p = df_sub[col.name].astype(float).fillna(0.0).values
            pbar = float(np.mean(p))
            # population variance (ddof=0)
            varp = float(np.nanvar(p, ddof=0))
            se = math.sqrt(varp / N) if N > 0 else float('nan')
            z95 = 1.959963984540054
            z99 = 2.5758293035489004
            ci95 = (max(0.0, pbar - z95 * se), min(1.0, pbar + z95 * se))
            ci99 = (max(0.0, pbar - z99 * se), min(1.0, pbar + z99 * se))
            obs_frac = float((df_sub[target] == cls).sum()) / float(N) if N > 0 else float('nan')
            
            logger.debug(f"Class {cls}: pred_mean={pbar:.4f}, obs_frac={obs_frac:.4f}, CI95={ci95}, CI99={ci99}")
            
            # determine signal for class
            if math.isnan(obs_frac) or math.isnan(pbar):
                sig = 'na'
            else:
                if not (ci99[0] <= obs_frac <= ci99[1]):
                    sig = 'red'
                    n_red += 1
                    red_obs += int((df_sub[target] == cls).sum())
                elif not (ci95[0] <= obs_frac <= ci95[1]):
                    sig = 'orange'
                    n_orange += 1
                    orange_obs += int((df_sub[target] == cls).sum())
                else:
                    sig = 'green'
                    
            logger.debug(f"Class {cls} signal: {sig}")
            per_class.append({'class': cls, 'pred_mean': pbar, 'obs_frac': obs_frac, 'ci95': ci95, 'ci99': ci99, 'signal': sig, 'count': int((df_sub[target] == cls).sum())})

        if not found_any:
            logger.warning("No probability columns found for any class")
            return None

        total_classes = len(classes)
        frac_red_classes = n_red / max(1, total_classes)
        frac_orange_classes = n_orange / max(1, total_classes)
        frac_red_orange = (n_red + n_orange) / max(1, total_classes)
        total_obs = len(df_sub)
        red_obs_share = red_obs / max(1, total_obs)
        orange_obs_share = orange_obs / max(1, total_obs)

        logger.info(f"Red classes: {n_red}/{total_classes} ({frac_red_classes:.2%}), Orange classes: {n_orange}/{total_classes} ({frac_orange_classes:.2%})")
        logger.info(f"Red obs share: {red_obs_share:.2%}, Orange obs share: {orange_obs_share:.2%}")

        # Overall signal per Table 6.15
        if frac_red_classes > 0.20 or red_obs_share > 0.15:
            overall = 'red'
        elif (frac_red_orange <= 0.20) and (orange_obs_share <= 0.15) and (red_obs_share <= 0.05):
            overall = 'green'
        else:
            overall = 'orange'
            
        logger.info(f"Overall signal determined: {overall}")

        return {
            'per_class': per_class, 
            'overall': overall, 
            'meta': {
                'frac_red_classes': frac_red_classes, 
                'frac_orange_classes': frac_orange_classes, 
                'red_obs_share': red_obs_share, 
                'orange_obs_share': orange_obs_share,
                'task': 'classification'
            }
        }

    def _render_html(self, res: Dict) -> str:
        """Render HTML for both classification and regression results."""
        task = res.get('meta', {}).get('task', 'classification')
        
        if task == 'regression':
            return self._render_html_regression(res)
        else:
            return self._render_html_classification(res)
    
    def _render_html_regression(self, res: Dict) -> str:
        """Render HTML for regression calibration results."""
        dfbins = pd.DataFrame(res['per_bin'])
        if dfbins.empty:
            return "<h4>M4.1 Regression Calibration skipped</h4><p>No valid bins created.</p>"
        
        logger.debug(f"Rendering regression visualization for {len(dfbins)} bins")
        
        # Create calibration plot for regression
        fig, ax = plt.subplots(figsize=(max(8, len(dfbins) * 1.2), 6))
        
        # Define colors
        ci99_color = '#FFD700'  # Gold for 99% CI
        ci95_color = '#FF6B6B'  # Light red for 95% CI
        observed_color = '#FF0000'  # Red for actual values
        predicted_color = '#000080'  # Navy blue for predicted values
        
        x = np.arange(len(dfbins))
        pred_means = dfbins['pred_mean'].values
        actual_means = dfbins['actual_mean'].values
        
        # Get global CI from metadata
        global_ci95 = res.get('meta', {}).get('global_ci95', (0, 0))
        global_ci99 = res.get('meta', {}).get('global_ci99', (0, 0))
        global_pred_mean = res.get('meta', {}).get('global_pred_mean', 0)
        
        # Plot horizontal CI bands (same for all bins)
        ax.axhspan(global_ci99[0], global_ci99[1], alpha=0.2, color=ci99_color, 
                  label='CI 99.0% (Global predicted mean)')
        ax.axhspan(global_ci95[0], global_ci95[1], alpha=0.3, color=ci95_color, 
                  label='CI 95.0% (Global predicted mean)')
        
        # Plot global mean as horizontal line
        ax.axhline(global_pred_mean, color=predicted_color, linestyle='--', linewidth=2,
                  label=f'Global predicted mean: {global_pred_mean:.3f}')
        
        # Plot actual values as red diamonds
        ax.scatter(x, actual_means, color=observed_color, marker='D', s=80, 
                  label='Actual mean values (by bin)', zorder=5)
        
        # Plot predicted means as blue circles (bin-specific)
        ax.scatter(x, pred_means, color=predicted_color, marker='o', s=60, 
                  label='Predicted mean values (by bin)', zorder=5, alpha=0.7)
        
        # Styling
        ax.set_xlabel('Prediction Quantile Bins', fontsize=12)
        ax.set_ylabel('Target Value', fontsize=12)
        ax.set_title('Regression Calibration Plot: Predicted vs Actual Values by Bin', fontsize=14, fontweight='bold')
        
        # Set x-axis labels
        ax.set_xticks(x)
        ax.set_xticklabels([f"Bin {i+1}" for i in range(len(dfbins))], rotation=45)
        
        # Grid and legend
        ax.grid(True, alpha=0.3, linestyle='--')
        ax.legend(loc='best', fontsize=10, frameon=True, fancybox=True, shadow=True)
        
        plt.tight_layout()
        img = _to_base64(fig)

        # Build HTML report
        html = f"<h4>M4.1 Regression Calibration Analysis</h4>"
        html += f"<p>Signal: <b style='color:{'green' if res['overall']=='green' else ('orange' if res['overall']=='orange' else 'red')}'>{res['overall'].upper()}</b></p>"
        html += f"<p><i>Analysis divides predictions into {len(dfbins)} quantile bins and compares actual means vs global predicted mean CI.</i></p>"
        html += f"<p><b>Global Predicted Mean:</b> {global_pred_mean:.4f}</p>"
        html += f"<p><b>Global CI 95%:</b> [{global_ci95[0]:.4f}, {global_ci95[1]:.4f}]</p>"
        html += f"<p><b>Global CI 99%:</b> [{global_ci99[0]:.4f}, {global_ci99[1]:.4f}]</p>"
        html += f"<img src=\"data:image/png;base64,{img}\" />"
        
        # Format table for display (remove individual CI columns since they're now global)
        df_display = dfbins.copy()
        df_display = df_display[['bin', 'bin_range', 'size', 'pred_mean', 'actual_mean', 'signal']]
        
        html += "<h5>Bin-wise Results</h5>"
        html += "<p><i>Signal is based on whether actual mean falls within global CI bands</i></p>"
        html += df_display.to_html(index=False, float_format='%.4f')
        return html
    
    def _render_html_classification(self, res: Dict) -> str:
        """Render HTML for classification calibration results."""
        dfpc = pd.DataFrame(res['per_class'])
        if dfpc.empty:
            return "<h4>M4.1 skipped</h4><p>No classes with probability columns found.</p>"
        
        logger.debug(f"Rendering classification visualization for {len(dfpc)} classes")
        
        # prepare table
        df_table = dfpc.copy()
        df_table['pred_mean_pct'] = df_table['pred_mean'] * 100.0
        df_table['obs_pct'] = df_table['obs_frac'] * 100.0
        df_table['ci95_lo_pct'] = df_table['ci95'].apply(lambda x: (x[0] * 100.0) if x[0] is not None else None)
        df_table['ci95_hi_pct'] = df_table['ci95'].apply(lambda x: (x[1] * 100.0) if x[1] is not None else None)
        df_table['ci99_lo_pct'] = df_table['ci99'].apply(lambda x: (x[0] * 100.0) if x[0] is not None else None)
        df_table['ci99_hi_pct'] = df_table['ci99'].apply(lambda x: (x[1] * 100.0) if x[1] is not None else None)
        df_table = df_table[['class', 'count', 'pred_mean_pct', 'obs_pct', 'ci95_lo_pct', 'ci95_hi_pct', 'ci99_lo_pct', 'ci99_hi_pct', 'signal']]

        # Create enhanced visualization like in the image
        fig, ax = plt.subplots(figsize=(max(8, len(df_table) * 1.5), 6))
        
        # Define colors for different elements
        ci99_color = '#FFD700'  # Gold for 99% CI
        ci95_color = '#FF6B6B'  # Light red for 95% CI
        observed_color = '#FF0000'  # Red for observed points
        predicted_color = '#000080'  # Navy blue for predicted PD
        
        x = np.arange(len(df_table))
        pred = df_table['pred_mean_pct'].fillna(0.0).values
        obs = df_table['obs_pct'].fillna(0.0).values
        
        # Calculate error bars for confidence intervals
        ci95_lo_err = pred - df_table['ci95_lo_pct'].fillna(df_table['pred_mean_pct']).values
        ci95_hi_err = df_table['ci95_hi_pct'].fillna(df_table['pred_mean_pct']).values - pred
        ci99_lo_err = pred - df_table['ci99_lo_pct'].fillna(df_table['pred_mean_pct']).values
        ci99_hi_err = df_table['ci99_hi_pct'].fillna(df_table['pred_mean_pct']).values - pred
        
        # Plot 99% CI bars (wider, orange)
        ax.errorbar(x, pred, yerr=[ci99_lo_err, ci99_hi_err], 
                   fmt='none', ecolor=ci99_color, elinewidth=8, capsize=0, 
                   alpha=0.8, label='CI 99.0%')
        
        # Plot 95% CI bars (narrower, red)
        ax.errorbar(x, pred, yerr=[ci95_lo_err, ci95_hi_err], 
                   fmt='none', ecolor=ci95_color, elinewidth=4, capsize=6, 
                   alpha=0.9, label='CI 95.0%')
        
        # Plot observed target rate as red diamonds
        ax.scatter(x, obs, color=observed_color, marker='D', s=80, 
                  label='Observed target rate', zorder=5)
        
        # Plot predicted PD as blue circles
        ax.scatter(x, pred, color=predicted_color, marker='o', s=60, 
                  label='Predicted PD', zorder=5)
        
        # Styling to match the image
        ax.set_xlabel('Target Class', fontsize=12)
        ax.set_ylabel('Target rate', fontsize=12)
        ax.set_title('Calibration Plot: Predicted vs Observed Rates', fontsize=14, fontweight='bold')
        
        # Set x-axis labels
        ax.set_xticks(x)
        ax.set_xticklabels(df_table['class'], rotation=0)
        
        # Format y-axis as percentages
        y_min = min(min(obs), min(pred)) * 0.95
        y_max = max(max(obs), max(pred)) * 1.05
        ax.set_ylim(y_min, y_max)
        
        # Add percentage format to y-axis
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{y:.2f}%'))
        
        # Grid
        ax.grid(True, alpha=0.3, linestyle='--')
        
        # Legend positioned like in the image
        ax.legend(loc='upper right', fontsize=10, frameon=True, fancybox=True, shadow=True)
        
        # Tight layout
        plt.tight_layout()
        
        img = _to_base64(fig)

        html = f"<h4>M4.1 Predicted vs Actual (per-class)</h4>"
        html += f"<p>Signal: <b style='color:{'green' if res['overall']=='green' else ('orange' if res['overall']=='orange' else 'red')}'>{res['overall'].upper()}</b></p>"
        html += f"<img src=\"data:image/png;base64,{img}\" />"
        html += df_table.to_html(index=False, float_format='%.2f')
        return html

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M4.1 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        task = getattr(cfg, 'task', 'classification')
        if task not in ['classification', 'regression']:
            return {"report": f"<h4>M4.1 skipped</h4><p>Test applies to classification and regression tasks only. Current task: {task}</p>"}

        logger.info(f"Starting M4.1 Calibration Test for {task} with {len(df)} rows")
        
        target_col = cfg.columns.target_column
        score_col = cfg.columns.score_column
        logger.info(f"Using target column: {target_col}, score column: {score_col}")

        sample_col = getattr(cfg.columns, 'sample_column', None)
        if sample_col and sample_col in df.columns:
            logger.info(f"Processing samples separately using column: {sample_col}")
            samples = ['train', 'test']
            html_sections = []
            meta = {}
            overall_signal = 'green'
            
            sample_progress = tqdm(samples, desc="Processing samples", leave=False)
            for s in sample_progress:
                sample_progress.set_description(f"Processing {s} sample")
                df_s = df[df[sample_col].astype(str).str.lower() == s]
                if df_s.empty:
                    logger.warning(f"No data found for {s} sample")
                    html_sections.append(f"<h3>{s.capitalize()}</h3><p>skipped (no rows)</p>")
                    continue
                logger.info(f"Processing {s} sample with {len(df_s)} rows")
                res = self._compute_for_df(df_s, cfg)
                if res is None:
                    logger.warning(f"{s} sample skipped due to insufficient data or missing score columns")
                    html_sections.append(f"<h3>{s.capitalize()}</h3><p>skipped (insufficient data or no score columns)</p>")
                    continue
                html_sections.append(f"<h2>{s.capitalize()}</h2>" + self._render_html(res))
                meta[s] = res['meta']
                sig = res['overall']
                logger.info(f"{s} sample completed with signal: {sig}")
                if sig == 'red':
                    overall_signal = 'red'
                elif sig == 'orange' and overall_signal != 'red':
                    overall_signal = 'orange'
            sample_progress.close()
            
            if not html_sections:
                return {"report": "<h4>M4.1 skipped</h4><p>No valid train/test samples found.</p>"}
            self.test_signal = overall_signal
            self.test_meta = meta
            logger.info(f"M4.1 completed with overall signal: {overall_signal}")
            return {"DASHBOARD": "".join(html_sections)}

        # fallback: single run on provided df
        logger.info("Processing full dataset (no sample separation)")
        res = self._compute_for_df(df, cfg)
        if res is None:
            return {"report": "<h4>M4.1 skipped</h4><p>Insufficient data or no score columns found.</p>"}
        self.test_signal = res['overall']
        self.test_meta = res['meta']
        logger.info(f"M4.1 completed with signal: {res['overall']}")
        return {"DASHBOARD": self._render_html(res)}
