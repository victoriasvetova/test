"""M3 regression-only tests: Spearman correlation and REC-curve analysis.

Classes implemented:
 - M31_SpearmanRankTest (M3.1) вЂ” regression-only
 - M32_RECAnalysisTest (M3.2) вЂ” regression-only

All user text in English. Tests use `validate_config` and return HTML dashboards.
"""
from __future__ import annotations
from typing import Dict, List, Optional
import numpy as np
import pandas as pd
from io import BytesIO
import base64
import math
import logging
from tqdm.auto import tqdm
import matplotlib.pyplot as plt

from ...core.base_test import BaseModelTest
from ...core.config_validation import validate_config, ConfigValidationError

logger = logging.getLogger(__name__)


def _to_base64(fig) -> str:
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode('utf-8')


class M31_SpearmanRankTest(BaseModelTest):
    """M3.1 Spearman rank correlation between actual and predicted (regression only).

    Interpretation thresholds (rho as percent):
      - rho < 40% -> RED
      - 40% <= rho < 55% -> ORANGE
      - rho >= 55% -> GREEN

    Returns a scatter plot and summary. Sets `self.test_signal` and `self.test_meta`.
    """
    def __init__(self):
        super().__init__('M 3.1 (regression only)', 'Spearman rank correlation')

    def run(self, df: pd.DataFrame = None, config: dict = None, sample: str = 'test') -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except Exception as e:
            return {"report": f"<h4>M3.1 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        if getattr(cfg, 'task', None) != 'regression':
            return {"report": "<h4>M3.1 skipped</h4><p>Test applies to regression tasks only.</p>"}

        logger.info(f"Starting M3.1 Spearman Rank Test with {len(df)} rows")

        date_col = cfg.columns.date_column
        target_col = cfg.columns.target_column
        score_col = cfg.columns.score_column

        if target_col not in df.columns:
            return {"report": f"<h4>M3.1 skipped</h4><p>Target column '{target_col}' missing.</p>"}
        if score_col not in df.columns:
            return {"report": f"<h4>M3.1 skipped</h4><p>Score column '{score_col}' missing (model predictions required).</p>"}

        logger.info(f"Using target column: {target_col}, score column: {score_col}")

        def compute_for_df(df_sub):
            sub = df_sub[[target_col, score_col]].dropna()
            if sub.empty:
                logger.warning("No valid data after removing NaN values")
                return None
            
            logger.debug(f"Computing Spearman correlation for {len(sub)} observations")
            try:
                rho = sub[target_col].corr(sub[score_col], method='spearman')
            except Exception as e:
                logger.exception('Failed to compute Spearman')
                return None
            rho_pct = float(rho * 100.0) if not math.isnan(rho) else float('nan')
            if math.isnan(rho_pct):
                logger.warning("Spearman correlation resulted in NaN")
                return None
                
            logger.info(f"Spearman correlation: {rho_pct:.2f}%")
            
            if rho_pct < 40.0:
                signal = 'red'
            elif rho_pct < 55.0:
                signal = 'orange'
            else:
                signal = 'green'
                
            logger.debug(f"Signal assigned: {signal}")
            
            # plot
            fig = plt.figure(figsize=(6, 4))
            plt.scatter(sub[target_col], sub[score_col], alpha=0.6, s=10)
            plt.xlabel('Actual')
            plt.ylabel('Predicted')
            plt.title(f'Scatter Actual vs Predicted (Spearman={rho_pct:.2f}%)')
            plt.tight_layout()
            img = _to_base64(fig)
            html = f"<h4>M3.1 Spearman Rank Correlation</h4><p>Spearman rho (percent): <b>{rho_pct:.2f}%</b> вЂ” <b style='color:{'green' if signal=='green' else ('orange' if signal=='orange' else 'red')}'>{signal.upper()}</b></p>"
            html += f"<p>Observations used: <b>{len(sub)}</b></p>"
            html += f"<img src=\"data:image/png;base64,{img}\" />"
            return {'html': html, 'meta': {'spearman_rho': rho_pct, 'n': int(len(sub))}, 'signal': signal}

        sample_col = getattr(cfg.columns, 'sample_column', None)
        if sample_col and sample_col in df.columns:
            logger.info(f"Processing samples separately using column: {sample_col}")
            samples = ['train', 'test']
            html_sections = []
            meta = {}
            overall_signal = 'green'
            
            sample_progress = tqdm(samples, desc="Processing samples", leave=False)
            for s in sample_progress:
                sample_progress.set_description(f"Processing {s} sample")
                df_s = df[df[sample_col].astype(str).str.lower() == s]
                if df_s.empty:
                    logger.warning(f"No data found for {s} sample")
                    continue
                logger.info(f"Processing {s} sample with {len(df_s)} rows")
                res = compute_for_df(df_s)
                if res is None:
                    html_sections.append(f"<h4>{s.capitalize()} - skipped (insufficient data)</h4>")
                    logger.warning(f"{s} sample skipped due to insufficient data")
                    continue
                html_sections.append(f"<h3>{s.capitalize()}</h3>" + res['html'])
                meta[s] = res['meta']
                sig = res['signal']
                if sig == 'red':
                    overall_signal = 'red'
                elif sig == 'orange' and overall_signal != 'red':
                    overall_signal = 'orange'
            sample_progress.close()
            
            if not html_sections:
                return {"report": "<h4>M3.1 skipped</h4><p>No train/test samples found with sufficient data.</p>"}
            self.test_signal = overall_signal
            self.test_meta = meta
            logger.info(f"M3.1 completed with overall signal: {overall_signal}")
            return {"DASHBOARD": "".join(html_sections)}

        # fallback: original single-sample behavior
        # subset by sample if requested
        if getattr(cfg.columns, 'sample_column', None) and cfg.columns.sample_column in df.columns:
            s = df[cfg.columns.sample_column].astype(str).str.lower()
            df_used = df[s == sample].copy()
        else:
            df_used = df.copy()
        res = compute_for_df(df_used)
        if res is None:
            return {"report": "<h4>M3.1 skipped</h4><p>No rows with both target and prediction available.</p>"}
        self.test_signal = res['signal']
        self.test_meta = res['meta']
        return {"DASHBOARD": res['html']}


class M32_RECAnalysisTest(BaseModelTest):
    """M3.2 REC-curve analysis for regression (regression only).

    - Baseline forecast is the mean of the training sample (if sample column exists and 'train' present), otherwise overall mean.
    - REC curve: x = error threshold, y = proportion of observations with absolute error <= threshold.
    - AOC (area over curve) approximated by mean absolute error (MAE).
    - Signal: ratio = AOC_model / AOC_baseline; ratio > 1 -> RED (worse than baseline), ratio < 1 -> GREEN, close to 1 -> ORANGE.
    """
    def __init__(self, n_bins: int = 100):
        super().__init__('M 3.2 (regression only)', 'REC Curve / AOC')
        self.n_bins = int(n_bins)

    def run(self, df: pd.DataFrame = None, config: dict = None, sample: str = 'test') -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except Exception as e:
            return {"report": f"<h4>M3.2 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        if getattr(cfg, 'task', None) != 'regression':
            return {"report": "<h4>M3.2 skipped</h4><p>Test applies to regression tasks only.</p>"}

        logger.info(f"Starting M3.2 REC Analysis Test with {len(df)} rows")

        target_col = cfg.columns.target_column
        score_col = cfg.columns.score_column

        if target_col not in df.columns:
            return {"report": f"<h4>M3.2 skipped</h4><p>Target column '{target_col}' missing.</p>"}
        if score_col not in df.columns:
            return {"report": f"<h4>M3.2 skipped</h4><p>Score column '{score_col}' missing (model predictions required).</p>"}

        logger.info(f"Using target column: {target_col}, score column: {score_col}")

        # determine baseline prediction (mean on train if present)
        baseline_pred = None
        if getattr(cfg.columns, 'sample_column', None) and cfg.columns.sample_column in df.columns:
            s = df[cfg.columns.sample_column].astype(str).str.lower()
            if 'train' in s.unique():
                baseline_pred = df[s == 'train'][target_col].mean()
                logger.info(f"Using train sample mean as baseline: {baseline_pred:.4f}")
        if baseline_pred is None or math.isnan(baseline_pred):
            baseline_pred = df[target_col].mean()
            logger.info(f"Using overall mean as baseline: {baseline_pred:.4f}")

        def compute_for_df(df_sub):
            sub = df_sub[[target_col, score_col]].dropna()
            if sub.empty:
                logger.warning("No valid data after removing NaN values")
                return None
                
            logger.debug(f"Computing REC analysis for {len(sub)} observations")
            
            y_true = sub[target_col].values
            y_pred = sub[score_col].values
            
            # Calculate errors
            err_model = np.abs(y_true - y_pred)
            err_base = np.abs(y_true - baseline_pred)
            
            logger.debug(f"Model MAE: {np.mean(err_model):.4f}, Baseline MAE: {np.mean(err_base):.4f}")
            
            # Sort errors for REC curves
            idx_m = np.argsort(err_model)
            sorted_err_m = err_model[idx_m]
            cdf_m = np.arange(1, len(sorted_err_m) + 1) / len(sorted_err_m)
            
            idx_b = np.argsort(err_base)
            sorted_err_b = err_base[idx_b]
            cdf_b = np.arange(1, len(sorted_err_b) + 1) / len(sorted_err_b)
            
            # Calculate AOC (Area Over Curve) - using MAE as approximation
            aoc_model = float(np.mean(err_model))
            aoc_baseline = float(np.mean(err_base))
            ratio = aoc_model / aoc_baseline if aoc_baseline != 0 else float('inf')
            
            if math.isinf(ratio) or np.isnan(ratio):
                logger.warning("Invalid ratio calculated")
                return None
                
            logger.info(f"AOC ratio: {ratio:.3f} (model/baseline)")
            
            if ratio > 1.0:
                signal = 'red'
            elif ratio < 1.0:
                signal = 'green'
            else:
                signal = 'orange'
                
            logger.debug(f"Signal assigned: {signal}")
            
            # Create enhanced visualization like in the image
            fig, ax = plt.subplots(figsize=(10, 6))
            
            # Plot REC curves
            ax.plot(sorted_err_m, cdf_m * 100, 'b-', linewidth=2, label='REC-curve model')
            ax.plot(sorted_err_b, cdf_b * 100, 'r--', linewidth=2, label='REC-curve baseline')
            
            # Fill areas under curves for AOC visualization
            ax.fill_between(sorted_err_m, 0, cdf_m * 100, alpha=0.3, color='blue', label='AOC model')
            ax.fill_between(sorted_err_b, 0, cdf_b * 100, alpha=0.3, color='red', label='AOC baseline')
            
            # Styling to match the image
            ax.set_xlabel('Squared Error', fontsize=12)
            ax.set_ylabel('Accuracy', fontsize=12)
            ax.set_title('Regression Error Characteristic curves', fontsize=14, fontweight='bold')
            
            # Set y-axis to percentage format
            ax.set_ylim(0, 100)
            ax.set_ylabel('Accuracy', fontsize=12)
            
            # Add percentage labels on y-axis
            yticks = np.arange(0, 101, 20)
            ax.set_yticks(yticks)
            ax.set_yticklabels([f'{int(y)}%' for y in yticks])
            
            # Grid
            ax.grid(True, alpha=0.3)
            
            # Legend
            ax.legend(loc='lower right', fontsize=10)
            
            # Tight layout
            plt.tight_layout()
            
            img = _to_base64(fig)
            
            html = f"<h4>M3.2 REC Curve Analysis</h4>"
            html += f"<p>AOC model: <b>{aoc_model:.4f}</b>; AOC baseline: <b>{aoc_baseline:.4f}</b>; ratio: <b>{ratio:.3f}</b> вЂ” <b style='color:{'green' if signal=='green' else ('orange' if signal=='orange' else 'red')}'>{signal.upper()}</b></p>"
            html += f"<p>Observations used: <b>{len(sub)}</b></p>"
            html += f"<img src=\"data:image/png;base64,{img}\" />"
            
            return {'html': html, 'meta': {'aoc_model': aoc_model, 'aoc_baseline': aoc_baseline, 'ratio': ratio, 'n': int(len(sub))}, 'signal': signal}

        sample_col = getattr(cfg.columns, 'sample_column', None)
        if sample_col and sample_col in df.columns:
            logger.info(f"Processing samples separately using column: {sample_col}")
            samples = ['train', 'test']
            html_sections = []
            meta = {}
            overall_signal = 'green'
            
            sample_progress = tqdm(samples, desc="Processing samples", leave=False)
            for s in sample_progress:
                sample_progress.set_description(f"Processing {s} sample")
                df_s = df[df[sample_col].astype(str).str.lower() == s]
                if df_s.empty:
                    logger.warning(f"No data found for {s} sample")
                    continue
                logger.info(f"Processing {s} sample with {len(df_s)} rows")
                res = compute_for_df(df_s)
                if res is None:
                    html_sections.append(f"<h4>{s.capitalize()} - skipped (insufficient data)</h4>")
                    logger.warning(f"{s} sample skipped due to insufficient data")
                    continue
                html_sections.append(f"<h3>{s.capitalize()}</h3>" + res['html'])
                meta[s] = res['meta']
                sig = res['signal']
                if sig == 'red':
                    overall_signal = 'red'
                elif sig == 'orange' and overall_signal != 'red':
                    overall_signal = 'orange'
            sample_progress.close()
            
            if not html_sections:
                return {"report": "<h4>M3.2 skipped</h4><p>No train/test samples found with sufficient data.</p>"}
            self.test_signal = overall_signal
            self.test_meta = meta
            logger.info(f"M3.2 completed with overall signal: {overall_signal}")
            return {"DASHBOARD": "".join(html_sections)}

        # fallback: subset test sample or full df
        if getattr(cfg.columns, 'sample_column', None) and cfg.columns.sample_column in df.columns:
            s = df[cfg.columns.sample_column].astype(str).str.lower()
            df_used = df[s == sample].copy()
            logger.info(f"Using {sample} sample with {len(df_used)} rows")
        else:
            df_used = df.copy()
            logger.info(f"Using full dataset with {len(df_used)} rows")
            
        res = compute_for_df(df_used)
        if res is None:
            return {"report": "<h4>M3.2 skipped</h4><p>No rows with both target and prediction available.</p>"}
        self.test_signal = res['signal']
        self.test_meta = res['meta']
        logger.info(f"M3.2 completed with signal: {res['signal']}")
        return {"DASHBOARD": res['html']}
