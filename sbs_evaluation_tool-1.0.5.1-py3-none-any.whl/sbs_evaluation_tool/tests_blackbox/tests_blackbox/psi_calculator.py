"""Legacy BlackBox PSICalculator — now re-exports the canonical implementation.

The previous 251-line copy duplicated ``tests/psi_calculator.py`` with cp1251-mojibake
docstrings and weaker NaN/weight handling. Kept as a thin re-export so existing
imports (`from .psi_calculator import PSICalculator, PSICalculatorExtended`)
keep working. To be deleted in Phase 2 when the nested folder is flattened.
"""

from ...tests.psi_calculator import (  # noqa: F401
    PSICalculator,
    PSICalculatorExtended,
)
