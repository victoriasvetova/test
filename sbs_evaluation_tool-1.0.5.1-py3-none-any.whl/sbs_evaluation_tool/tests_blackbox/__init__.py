"""Public BlackBox PD validation namespace for SBS Evaluation Tool.

Use `run_sbs_blackbox_evaluation` for the methodology-aligned lightweight
BlackBox runner. Heavy SHAP/permutation tests are intentionally not enabled
by default.
"""

from .runner import run_sbs_blackbox_evaluation

__all__ = ["run_sbs_blackbox_evaluation"]
