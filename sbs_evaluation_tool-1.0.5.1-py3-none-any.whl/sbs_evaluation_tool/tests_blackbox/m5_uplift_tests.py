"""Compatibility wrapper for `tests_blackbox.m5_uplift_tests`."""

from .tests_blackbox.m5_uplift_tests import *  # noqa: F401,F403
