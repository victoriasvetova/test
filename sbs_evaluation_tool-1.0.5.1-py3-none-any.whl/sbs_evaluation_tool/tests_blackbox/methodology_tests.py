"""Methodology-aligned BlackBox PD test classes.

This module maps the archived BlackBox PD methodology to the current library
without enabling heavy tests such as permutation importance or SHAP by default.
"""
from __future__ import annotations

import math
from typing import Dict, Optional

import numpy as np
import pandas as pd
from scipy.stats import binom

from ..core.base_test import BaseModelTest
from ..core.config_validation import ConfigValidationError, validate_config
from ..core.data_utils import split_frames
from ..core.metrics import gini as _binary_gini, bootstrap_gini_ci
from .m1_sampling_tests import (
    M11_SampleConsistencyTest,
    M12_DataFreshnessTest,
    M13_SplitRandomnessTest,
)
from .m2_classification_tests import M21_GiniOverallTest, M23_GiniDynamicsTest
from .m6_stability_tests import M61_StabilityKeyMetricTest
from .psi_calculator import PSICalculatorExtended


def _score_col(cfg) -> Optional[str]:
    return cfg.columns.score_column or cfg.columns.prediction_column


def _sample_items(df: pd.DataFrame, cfg) -> list[tuple[str, pd.DataFrame]]:
    sample_col = getattr(cfg.columns, "sample_column", None)
    if sample_col and sample_col in df.columns:
        sample = df[sample_col].astype(str).str.lower()
        items = []
        train = df.loc[sample == "train"]
        validation = df.loc[sample != "train"]
        if not train.empty:
            items.append(("train", train))
        if not validation.empty:
            items.append(("test", validation))
        if items:
            return items
    return [("all", df)]


def _event_series(target: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(target, errors="coerce")
    if numeric.notna().any():
        return numeric.astype(float)

    values = pd.Series(target.dropna().unique())
    if values.empty:
        return pd.Series(np.nan, index=target.index, dtype=float)
    positive = 1 if 1 in set(values.tolist()) else sorted(values.astype(str).tolist())[-1]
    return (target.astype(str) == str(positive)).astype(float)


def _clean_pd_frame(df: pd.DataFrame, target_col: str, score_col: str) -> pd.DataFrame:
    out = pd.DataFrame(
        {
            "target": _event_series(df[target_col]),
            "pd": pd.to_numeric(df[score_col], errors="coerce"),
        },
        index=df.index,
    )
    out = out.replace([np.inf, -np.inf], np.nan).dropna()
    out["pd"] = out["pd"].clip(0.0, 1.0)
    return out


def _binomial_rate_ci(pd_value: float, n: int, confidence: float) -> tuple[float, float]:
    if n <= 0 or not np.isfinite(pd_value):
        return float("nan"), float("nan")
    alpha = 1.0 - confidence
    p = float(np.clip(pd_value, 0.0, 1.0))
    low_threshold = alpha / 2.0
    low_count = int(binom.ppf(low_threshold, n, p))
    if float(binom.cdf(low_count, n, p)) > low_threshold:
        low_count -= 1
    low_count = max(low_count, 0)
    high_count = float(binom.ppf(1.0 - alpha / 2.0, n, p))
    return low_count / n, high_count / n


def _calibration_signal(actual_rate: float, ci95: tuple[float, float], ci99: tuple[float, float]) -> str:
    if not np.isfinite(actual_rate) or not all(np.isfinite(x) for x in (*ci95, *ci99)):
        return "blue"
    if ci95[0] <= actual_rate <= ci95[1]:
        return "green"
    if ci99[0] <= actual_rate <= ci99[1]:
        return "orange"
    return "red"


def _worst_signal(signals: list[str]) -> str:
    rank = {"blue": -1, "green": 0, "orange": 1, "orange": 1, "red": 2}
    if not signals:
        return "blue"
    return max(signals, key=lambda x: rank.get(x, -1))


def _binomial_limit(n: int, p: float, confidence: float) -> int:
    if n <= 0:
        return 0
    return int(binom.ppf(confidence, n, p))


class BBM11_SampleConsistencyTest(M11_SampleConsistencyTest):
    """M1.1. Train/test split quality."""

    def __init__(self):
        super().__init__()
        self.test_code = "M 1.1"
        self.test_name = "Sample Split Quality"


class BBM12_SampleRepresentativenessTest(M13_SplitRandomnessTest):
    """M1.2. Sample representativeness by model factors.

    Uses the existing split-predictability check as a practical proxy: if model
    factors can predict train vs validation membership, the validation sample is
    not representative enough.
    """

    def __init__(self, k_folds: int = 4):
        super().__init__(k_folds=k_folds)
        self.test_code = "M 1.2"
        self.test_name = "Sample Representativeness by Factors"


class BBM13_DataFreshnessTest(M12_DataFreshnessTest):
    """M1.3. Data freshness."""

    def __init__(self):
        super().__init__()
        self.test_code = "M 1.3"
        self.test_name = "Data Freshness"


class BBM14_ControlChecksPlaceholder(BaseModelTest):
    """M1.4. Control checklist coverage.

    The methodology requires a business/control checklist. The current library
    has no stable schema for that checklist, so the test is explicit INFO rather
    than a silent omission.
    """

    def __init__(self):
        super().__init__("M 1.4", "Control Checklist Coverage")

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        self.test_signal = "blue"
        return {
            "DASHBOARD": (
                "<h4>M1.4 Control Checklist Coverage</h4>"
                "<p><b>INFO:</b> control-check schema is not configured yet. "
                "Add an explicit checklist contract before turning this into a "
                "traffic-light test.</p>"
            )
        }


class BBM15_MissingExtremeValuesPlaceholder(BaseModelTest):
    """M1.5. Missing and extreme values, informational."""

    def __init__(self):
        super().__init__("M 1.5", "Missing and Extreme Values")

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            self.test_signal = "blue"
            return {"DASHBOARD": f"<h4>M1.5 skipped</h4><p>{'; '.join(e.errors)}</p>"}

        features = list(cfg.columns.numeric_features or []) + list(cfg.columns.categorical_features or [])
        features = [f for f in dict.fromkeys(features) if f in df.columns]
        rows = []
        for feature in features:
            s = df[feature]
            missing_share = float(s.isna().mean())
            extreme_share = float("nan")
            if pd.api.types.is_numeric_dtype(s):
                x = pd.to_numeric(s, errors="coerce").dropna()
                if x.size >= 4:
                    q1, q3 = np.percentile(x, [25, 75])
                    iqr = q3 - q1
                    if iqr > 0:
                        lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
                        extreme_share = float(((x < lo) | (x > hi)).mean())
            rows.append(
                {
                    "feature": feature,
                    "missing_share": missing_share,
                    "extreme_share": extreme_share,
                }
            )

        self.test_signal = "blue"
        table = pd.DataFrame(rows).to_html(index=False, float_format="%.4f") if rows else "<p>No features configured.</p>"
        return {
            "DASHBOARD": (
                "<h4>M1.5 Missing and Extreme Values</h4>"
                "<p><b>INFO:</b> informational test; traffic light is not assigned.</p>"
                f"{table}"
            )
        }


class BBM21_RankingEfficiencyTest(M21_GiniOverallTest):
    """M2.1. Overall ranking efficiency."""

    def __init__(self, n_bootstrap: int = 300):
        super().__init__(n_bootstrap=n_bootstrap)
        self.test_code = "M 2.1"
        self.test_name = "Overall Ranking Efficiency"


class BBM22_GiniConfidenceIntervalTest(BaseModelTest):
    """M2.2. Confidence interval for key Gini metric."""

    def __init__(self, n_bootstrap: int = 300, random_state: int = 42):
        super().__init__("M 2.2", "Gini Confidence Interval")
        self.n_bootstrap = int(n_bootstrap)
        self.random_state = int(random_state)

    def _bootstrap_ci(self, y: pd.Series, score: pd.Series) -> tuple[float, float, float]:
        gini = _binary_gini(y, score)
        if math.isnan(gini):
            return float("nan"), float("nan"), float("nan")
        lo, hi = bootstrap_gini_ci(
            np.asarray(y), np.asarray(score),
            n_iter=self.n_bootstrap, ci=0.95, seed=self.random_state,
        )
        return gini, lo, hi

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"DASHBOARD": f"<h4>M2.2 skipped</h4><p>{'; '.join(e.errors)}</p>"}

        if cfg.task != "classification":
            self.test_signal = "blue"
            return {"DASHBOARD": "<h4>M2.2 skipped</h4><p>PD BlackBox Gini CI is classification-only.</p>"}

        score_col = _score_col(cfg)
        target_col = cfg.columns.target_column
        if not score_col or score_col not in df.columns or target_col not in df.columns:
            self.test_signal = "blue"
            return {"DASHBOARD": "<h4>M2.2 skipped</h4><p>Score or target column is missing.</p>"}

        sections = []
        rows = []
        try:
            frames = split_frames(df, cfg)
            sample_items = [("train", frames[0]), ("test", frames[1])]
        except Exception:
            sample_items = [("all", df)]

        worst = "green"
        for label, part in sample_items:
            if part is None or part.empty:
                continue
            gini, lo, hi = self._bootstrap_ci(part[target_col], part[score_col])
            gini_pct = gini * 100.0 if np.isfinite(gini) else float("nan")
            lo_pct = lo * 100.0 if np.isfinite(lo) else float("nan")
            hi_pct = hi * 100.0 if np.isfinite(hi) else float("nan")
            if not np.isfinite(gini_pct):
                signal = "orange"
            elif gini_pct < 20.0 and (not np.isfinite(hi_pct) or hi_pct < 20.0):
                signal = "red"
            elif gini_pct < 40.0:
                signal = "orange"
            else:
                signal = "green"
            if signal == "red":
                worst = "red"
            elif signal == "orange" and worst != "red":
                worst = "orange"
            rows.append(
                {
                    "sample": label,
                    "gini_pct": gini_pct,
                    "ci_95_low_pct": lo_pct,
                    "ci_95_high_pct": hi_pct,
                    "n": len(part),
                    "signal": signal,
                }
            )

        self.test_signal = worst
        table = pd.DataFrame(rows).to_html(index=False, float_format="%.3f") if rows else "<p>No valid samples.</p>"
        sections.append(
            f"<h4>M2.2 Gini Confidence Interval</h4>"
            f"<p>Bootstrap iterations: <b>{self.n_bootstrap}</b></p>"
            f"{table}"
        )
        return {"DASHBOARD": "".join(sections)}


class BBM23_GiniDynamicsTest(M23_GiniDynamicsTest):
    """M2.3. Gini dynamics."""

    def __init__(self, freq: str = "M", n_bootstrap: int = 200, min_events: int = 50):
        super().__init__(freq=freq, n_bootstrap=n_bootstrap, min_events=min_events)
        self.test_code = "M 2.3"
        self.test_name = "Gini Dynamics"


class BBM31_PermutationImportanceSkipped(BaseModelTest):
    """M3.1. Heavy permutation test placeholder."""

    def __init__(self):
        super().__init__("M 3.1", "Permutation Feature Significance")

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        self.test_signal = "blue"
        return {
            "DASHBOARD": (
                "<h4>M3.1 Permutation Feature Significance</h4>"
                "<p><b>Skipped:</b> heavy permutation test is intentionally not "
                "enabled in the lightweight BlackBox runner.</p>"
            )
        }


class BBM32_ShapImportanceSkipped(BaseModelTest):
    """M3.2. Heavy SHAP comparison placeholder."""

    def __init__(self):
        super().__init__("M 3.2", "SHAP Importance Train/Test Comparison")

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        self.test_signal = "blue"
        return {
            "DASHBOARD": (
                "<h4>M3.2 SHAP Importance Train/Test Comparison</h4>"
                "<p><b>Skipped:</b> SHAP is a heavy test and is not enabled in "
                "the lightweight BlackBox runner.</p>"
            )
        }


class BBM41_TargetRateCalibrationTest(BaseModelTest):
    """M4.1. Predicted vs actual target rate.

    Methodology: observed event count is tested against Bin(n, PD), where PD is
    the average model probability in the sample.
    """

    def __init__(self):
        super().__init__("M 4.1", "Predicted vs Actual Target Rate")

    def _sample_result(self, label: str, part: pd.DataFrame, target_col: str, score_col: str) -> dict:
        clean = _clean_pd_frame(part, target_col, score_col)
        n = int(len(clean))
        if n == 0:
            return {
                "sample": label,
                "n": 0,
                "events": 0,
                "predicted_pd": float("nan"),
                "actual_rate": float("nan"),
                "ci95_low": float("nan"),
                "ci95_high": float("nan"),
                "ci99_low": float("nan"),
                "ci99_high": float("nan"),
                "signal": "blue",
            }

        pd_mean = float(clean["pd"].mean())
        events = int(clean["target"].sum())
        actual_rate = float(clean["target"].mean())
        ci95 = _binomial_rate_ci(pd_mean, n, 0.95)
        ci99 = _binomial_rate_ci(pd_mean, n, 0.99)
        return {
            "sample": label,
            "n": n,
            "events": events,
            "predicted_pd": pd_mean,
            "actual_rate": actual_rate,
            "ci95_low": ci95[0],
            "ci95_high": ci95[1],
            "ci99_low": ci99[0],
            "ci99_high": ci99[1],
            "signal": _calibration_signal(actual_rate, ci95, ci99),
        }

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            self.test_signal = "blue"
            return {"DASHBOARD": f"<h4>M4.1 skipped</h4><p>{'; '.join(e.errors)}</p>"}

        if cfg.task != "classification":
            self.test_signal = "blue"
            return {"DASHBOARD": "<h4>M4.1 skipped</h4><p>BlackBox PD calibration is classification-only.</p>"}

        score_col = _score_col(cfg)
        target_col = cfg.columns.target_column
        if not score_col or score_col not in df.columns or target_col not in df.columns:
            self.test_signal = "blue"
            return {"DASHBOARD": "<h4>M4.1 skipped</h4><p>Score or target column is missing.</p>"}

        rows = [
            self._sample_result(label, part, target_col, score_col)
            for label, part in _sample_items(df, cfg)
            if part is not None and not part.empty
        ]
        self.test_signal = _worst_signal([r["signal"] for r in rows])
        self.test_meta = {"score_column": score_col, "target_column": target_col, "samples": rows}

        table = pd.DataFrame(rows).to_html(index=False, float_format="%.6f") if rows else "<p>No valid samples.</p>"
        html = (
            "<h4>M4.1 Predicted vs Actual Target Rate</h4>"
            "<p>Methodology: CI is built from the binomial distribution "
            "<code>Y ~ Bin(n, PD)</code>, where <code>PD</code> is the average "
            "model probability in the sample. The actual target rate is compared "
            "with 95% and 99% intervals.</p>"
            f"{table}"
        )
        return {"DASHBOARD": html}


class BBM42_CalibrationCurveShapeTest(BaseModelTest):
    """M4.2. Calibration by discrete model category.

    The methodology applies M4.1 inside model categories/buckets and then checks
    whether the number of interval outliers is acceptable under Bin(m, p), where
    m is the number of categories.
    """

    def __init__(self, group_column: Optional[str] = None):
        super().__init__("M 4.2", "Calibration Curve Shape")
        self.group_column = group_column

    def _resolve_group_column(self, cfg, df: pd.DataFrame, config: dict) -> Optional[str]:
        columns_config = (config or {}).get("columns") or {}
        candidate = (
            self.group_column
            or (config or {}).get("group_column")
            or (config or {}).get("bucket_column")
            or (config or {}).get("rating_column")
            or columns_config.get("group_column")
            or columns_config.get("bucket_column")
            or columns_config.get("rating_column")
        )
        if candidate and candidate in df.columns:
            return candidate

        score_col = _score_col(cfg)
        pred_col = getattr(cfg.columns, "prediction_column", None)
        if pred_col and pred_col in df.columns and pred_col != score_col:
            return pred_col
        return None

    def _sample_table(self, part: pd.DataFrame, target_col: str, score_col: str, group_col: str) -> pd.DataFrame:
        rows = []
        work = _clean_pd_frame(part, target_col, score_col)
        work["group"] = part.loc[work.index, group_col].astype(str)

        for group, g in work.groupby("group", dropna=False):
            n = int(len(g))
            if n == 0:
                continue
            pd_mean = float(g["pd"].mean())
            actual_rate = float(g["target"].mean())
            ci95 = _binomial_rate_ci(pd_mean, n, 0.95)
            ci99 = _binomial_rate_ci(pd_mean, n, 0.99)
            signal = _calibration_signal(actual_rate, ci95, ci99)
            rows.append(
                {
                    "bucket": group,
                    "n": n,
                    "events": int(g["target"].sum()),
                    "predicted_pd": pd_mean,
                    "actual_rate": actual_rate,
                    "ci95_low": ci95[0],
                    "ci95_high": ci95[1],
                    "ci99_low": ci99[0],
                    "ci99_high": ci99[1],
                    "outside_95": bool(signal in ("orange", "red")),
                    "outside_99": bool(signal == "red"),
                    "bucket_signal": signal,
                }
            )
        return pd.DataFrame(rows)

    def _sample_signal(self, table: pd.DataFrame) -> tuple[str, dict]:
        buckets = int(len(table))
        out95 = int(table["outside_95"].sum()) if buckets else 0
        out99 = int(table["outside_99"].sum()) if buckets else 0
        limits = {
            "buckets": buckets,
            "outside_95_count": out95,
            "outside_99_count": out99,
            "outside_95_limit_95": _binomial_limit(buckets, 0.05, 0.95),
            "outside_95_limit_99": _binomial_limit(buckets, 0.05, 0.99),
            "outside_99_limit_95": _binomial_limit(buckets, 0.01, 0.95),
            "outside_99_limit_99": _binomial_limit(buckets, 0.01, 0.99),
        }
        if (
            out95 > limits["outside_95_limit_99"]
            or out99 > limits["outside_99_limit_99"]
        ):
            return "red", limits
        if (
            out95 > limits["outside_95_limit_95"]
            or out99 > limits["outside_99_limit_95"]
        ):
            return "orange", limits
        return "green", limits

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            self.test_signal = "blue"
            return {"DASHBOARD": f"<h4>M4.2 skipped</h4><p>{'; '.join(e.errors)}</p>"}

        if cfg.task != "classification":
            self.test_signal = "blue"
            return {"DASHBOARD": "<h4>M4.2 skipped</h4><p>BlackBox PD calibration is classification-only.</p>"}

        score_col = _score_col(cfg)
        target_col = cfg.columns.target_column
        group_col = self._resolve_group_column(cfg, df, config or {})
        if not score_col or score_col not in df.columns or target_col not in df.columns:
            self.test_signal = "blue"
            return {"DASHBOARD": "<h4>M4.2 skipped</h4><p>Score or target column is missing.</p>"}
        if not group_col:
            self.test_signal = "blue"
            return {
                "DASHBOARD": (
                    "<h4>M4.2 skipped</h4>"
                    "<p>Methodology requires a discrete model category/bucket "
                    "output. Configure <code>group_column</code>, "
                    "<code>bucket_column</code>, <code>rating_column</code>, or "
                    "set <code>prediction_column</code> to a categorical model "
                    "output distinct from <code>score_column</code>.</p>"
                )
            }

        sections = [
            "<h4>M4.2 Calibration Curve Shape</h4>"
            "<p>Methodology: M4.1 binomial intervals are calculated inside each "
            f"discrete bucket from <code>{group_col}</code>. The final signal is "
            "based on binomial limits for the number of buckets outside the 95% "
            "and 99% intervals.</p>"
        ]
        signals = []
        sample_meta = []
        for label, part in _sample_items(df, cfg):
            if part is None or part.empty:
                continue
            table = self._sample_table(part, target_col, score_col, group_col)
            signal, limits = self._sample_signal(table)
            signals.append(signal)
            sample_meta.append({"sample": label, "signal": signal, **limits})
            limits_html = pd.DataFrame([{"sample": label, **limits, "signal": signal}]).to_html(
                index=False, float_format="%.6f"
            )
            bucket_html = table.to_html(index=False, float_format="%.6f") if not table.empty else "<p>No valid buckets.</p>"
            sections.append(f"<h5>Sample: {label}</h5>{limits_html}{bucket_html}")

        self.test_signal = _worst_signal(signals)
        self.test_meta = {
            "score_column": score_col,
            "target_column": target_col,
            "group_column": group_col,
            "samples": sample_meta,
        }
        return {"DASHBOARD": "".join(sections)}


class BBM51_RankingStabilityTest(M61_StabilityKeyMetricTest):
    """M5.1. Train/validation ranking stability."""

    def __init__(self):
        BaseModelTest.__init__(self, "M 5.1", "Ranking Efficiency Stability")


class BBM52_ScoreDistributionStabilityTest(BaseModelTest):
    """M5.2. Score distribution stability via PSI."""

    def __init__(self, psi_calc: Optional[PSICalculatorExtended] = None):
        super().__init__("M 5.2", "Score Distribution Stability")
        self.psi_calc = psi_calc or PSICalculatorExtended()

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
            train_df, test_df, _ = split_frames(df, cfg)
        except ConfigValidationError as e:
            return {"DASHBOARD": f"<h4>M5.2 skipped</h4><p>{'; '.join(e.errors)}</p>"}
        except Exception as e:
            return {"DASHBOARD": f"<h4>M5.2 skipped</h4><p>{str(e)}</p>"}

        score_col = _score_col(cfg)
        target_col = cfg.columns.target_column
        if not score_col:
            self.test_signal = "blue"
            return {"DASHBOARD": "<h4>M5.2 skipped</h4><p>Score column is missing.</p>"}

        result = self.psi_calc.calculate(
            expected=train_df[score_col],
            actual=test_df[score_col],
            target_expected=train_df[target_col],
            target_actual=test_df[target_col],
            is_categorical=False,
        )
        try:
            total_psi = float(result["all"]["psi"].sum())
        except Exception:
            total_psi = float("inf")

        if not np.isfinite(total_psi) or total_psi >= 0.20:
            self.test_signal = "red"
        elif total_psi >= 0.10:
            self.test_signal = "orange"
        else:
            self.test_signal = "green"

        html = (
            "<h4>M5.2 Score Distribution Stability</h4>"
            f"<p>Total score PSI: <b>{total_psi:.4f}</b></p>"
            + self.psi_calc.generate_html_block(result, feature_name=score_col)
        )
        return {"DASHBOARD": html}
