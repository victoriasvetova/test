# -*- coding: utf-8 -*-
"""Auto-extracted from ``tests/m4_model_performance.py`` in the Phase 2 split.

See ``tests/m4/__init__.py`` for the package overview.
"""

from __future__ import annotations
import base64
from io import BytesIO
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import logging

from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score, r2_score, mean_squared_error
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
from sklearn.utils.multiclass import type_of_target

from ...core.base_test import BaseModelTest
from ...core.metrics import gini_normalized, bootstrap_values
from ...core.styles import COLORS, STATUS_COLORS, figure
from ...core.config_validation import validate_config as _validate_config, ConfigValidationError
from ...core.data_utils import (
    ensure_config,
    split_frames,
    split_sample_masks,
    get_weight_col,
    get_col_name,
    get_vectors,
    get_features,
    get_model_mode,
    is_binary_mode,
    is_big_data_mode,
    is_generic_classification_mode,
    sample_frame_for_big_data,
)
from .._visual_utils import (
    MEAN_RATE_LABEL,
    OBSERVATION_COUNT_LABEL,
    SHARE_LABEL,
    build_tabbed_sections_html,
    build_period_specs,
    build_scale_specs,
    figure_to_base64,
)

import matplotlib.dates as mdates
from math import log

from ._shared import (
    _classification_mode_na,
    _subset_by_sample,
    _safe_threshold_labels,
    _to_base64,
)

logger = logging.getLogger(__name__)


class M41_TargetRateTest(BaseModelTest):
    """Predicted vs Observed Rate of Target with simple CI-based traffic light.

    Signal logic:
    - GREEN if mean_pred within 95% CI of mean_true
    - ORANGE if within 99% CI (but not 95%)
    - RED if outside 99% CI
    """
    def __init__(self, test_num='M 4.1', test_name='Predicted vs Observed Rate of Target'):
        super().__init__(test_num, test_name)

    @staticmethod
    def _weighted_mean(y: np.ndarray, w: Optional[np.ndarray] = None) -> float:
        """Взвешенное среднее: Sum(y * w) / Sum(w).
        Используется для predicted rate.
        """
        y = np.asarray(y, dtype=float)
        if w is None:
            return float(np.mean(y))
        w = np.asarray(w, dtype=float)
        if y.shape != w.shape:
            w = w[: y.shape[0]]
        sw = np.sum(w)
        if sw <= 0:
            return float(np.mean(y))
        return float(np.sum(y * w) / sw)
    
    @staticmethod
    def _rate_mean(y: np.ndarray, w: Optional[np.ndarray] = None) -> float:
        """Среднее для rate/frequency: Sum(y) / Sum(w).
        Используется для observed rate в страховании.
        В страховании: частота = количество событий / экспозиция.
        """
        y = np.asarray(y, dtype=float)
        if w is None:
            return float(np.mean(y))
        w = np.asarray(w, dtype=float)
        if y.shape != w.shape:
            w = w[: y.shape[0]]
        sw = np.sum(w)
        if sw <= 0:
            return float(np.mean(y))
        # Для rate: просто сумма событий / сумма экспозиции
        return float(np.sum(y) / sw)

    @staticmethod
    def _ci_mean_classification(y: np.ndarray, z: float, w: Optional[np.ndarray] = None) -> tuple:
        """Вычисляет доверительный интервал для среднего (вероятности) в классификации.
        
        Для взвешенной выборки используется эффективный размер выборки:
        n_eff = (sum(w))^2 / sum(w^2)
        
        Это корректно учитывает неравномерность весов при расчете стандартной ошибки.
        """
        y = np.asarray(y).astype(float)
        if w is not None:
            w = np.asarray(w, dtype=float)
            if y.shape != w.shape:
                w = w[: y.shape[0]]
            sw = np.sum(w)
            if sw <= 0:
                w = None
        
        if w is None:
            # Невзвешенный случай
            n = max(1, y.size)
            p = float(np.mean(y))
            se = np.sqrt(max(p * (1 - p), 0.0) / n)
        else:
            # Взвешенный случай - для RATE (sum(y) / sum(w))
            sw = np.sum(w)
            p = float(np.sum(y) / sw)  # Rate: sum(events) / sum(exposure)
            
            # Эффективный размер выборки для взвешенных данных
            n_eff = (sw ** 2) / np.sum(w ** 2)
            n_eff = max(1.0, n_eff)
            
            var = max(p * (1 - p), 0.0)
            se = np.sqrt(var / n_eff)
        return (p - z * se, p + z * se)

    @staticmethod
    def _ci_mean_regression(y: np.ndarray, z: float, w: Optional[np.ndarray] = None) -> tuple:
        """Вычисляет доверительный интервал для среднего в регрессии (для RATE).
        
        Для взвешенной выборки используется:
        - среднее для rate: sum(y) / sum(w) (не sum(y*w)/sum(w)!)
        - дисперсия для rate: var(y/w) при равных w, или через bootstrap
        - эффективный размер выборки: n_eff = (sum(w))^2 / sum(w^2)
        - стандартная ошибка: SE = sqrt(s^2 / n_eff)
        """
        y = np.asarray(y).astype(float)
        if w is not None:
            w = np.asarray(w, dtype=float)
            if y.shape != w.shape:
                w = w[: y.shape[0]]
            sw = np.sum(w)
            if sw <= 0:
                w = None
        
        if w is None:
            # Невзвешенный случай
            n = max(1, y.size)
            m = float(np.mean(y))
            s = float(np.nanstd(y, ddof=1)) if n > 1 else 0.0
            se = s / np.sqrt(n) if n > 0 else 0.0
        else:
            # Взвешенный случай - для RATE
            sw = np.sum(w)
            m = float(np.sum(y) / sw)  # Rate: sum(events) / sum(exposure)
            
            # Для rate дисперсия считается как для индивидуальных rate_i = y_i / exposure_total
            # Приближенная формула: используем дисперсию y относительно m*w
            s2 = np.sum((y - m * w) ** 2 / w) / len(y) if np.all(w > 0) else np.var(y / w) if np.all(w > 0) else 0.0
            s = float(np.sqrt(max(s2, 0.0)))
            
            # Эффективный размер выборки
            n_eff = (sw ** 2) / np.sum(w ** 2)
            n_eff = max(1.0, n_eff)
            
            se = s / np.sqrt(n_eff) if n_eff > 0 else 0.0
        return (m - z * se, m + z * se)

    @staticmethod
    def _ci_mean_poisson(y: np.ndarray, z: float, w: Optional[np.ndarray] = None,
                          center_rate: Optional[float] = None) -> tuple:
        """Normal-approximation CI for a Poisson rate.

        If ``center_rate`` is provided, the CI is built around it
        (the *predicted* rate λ̂) with ``SE = sqrt(λ̂ / Σw)`` — this is
        the standard actuarial calibration test ("does the observed mean
        fall inside the sampling distribution of the model-implied
        mean?"). When ``center_rate`` is None the CI falls back to the
        observed rate.
        """
        y = np.asarray(y, dtype=float)
        y = y[np.isfinite(y)]
        if y.size == 0:
            return (0.0, 0.0)

        if w is None:
            exposure = float(y.size)
            obs_rate = float(np.sum(y) / exposure)
        else:
            w = np.asarray(w, dtype=float)
            if y.shape != w.shape:
                w = w[: y.shape[0]]
            mask = np.isfinite(w) & (w > 0)
            y = y[mask]
            w = w[mask]
            exposure = float(np.sum(w))
            obs_rate = float(np.sum(y) / exposure) if exposure > 0 else float(np.mean(y))

        center = obs_rate if center_rate is None else float(center_rate)
        se = np.sqrt(max(center, 0.0) / max(exposure, 1.0))
        return (max(0.0, center - z * se), center + z * se)

    @staticmethod
    def _ci_mean_gamma(
        y: np.ndarray,
        z: float,
        w: Optional[np.ndarray] = None,
        dispersion: Optional[float] = None,
    ) -> tuple:
        """Normal approximation CI for a Gamma mean using Var(Y)=phi*mu^2."""
        y = np.asarray(y, dtype=float)
        mask = np.isfinite(y) & (y > 0)
        y = y[mask]
        if y.size == 0:
            return (0.0, 0.0)

        weights = None
        if w is not None:
            w_arr = np.asarray(w, dtype=float)
            if mask.shape == w_arr.shape:
                w_arr = w_arr[mask]
            elif y.shape != w_arr.shape:
                w_arr = w_arr[: y.shape[0]]
            w_mask = np.isfinite(w_arr) & (w_arr > 0)
            if np.any(w_mask):
                y = y[w_mask]
                weights = w_arr[w_mask]

        if weights is None:
            mean = float(np.mean(y))
            n_eff = float(y.size)
        else:
            mean = float(np.average(y, weights=weights))
            n_eff = float((np.sum(weights) ** 2) / np.sum(weights ** 2))

        if mean <= 0 or n_eff <= 0:
            return (0.0, 0.0)

        if dispersion is None:
            resid2 = ((y - mean) / mean) ** 2
            if weights is None:
                phi = float(np.sum(resid2) / max(y.size - 1, 1))
            else:
                phi = float(np.average(resid2, weights=weights))
        else:
            phi = float(dispersion)

        se = mean * np.sqrt(max(phi, 0.0) / max(n_eff, 1.0))
        return (max(0.0, mean - z * se), mean + z * se)

    @staticmethod
    def _determine_signal(mean_pred: float, ci_95: tuple, ci_99: tuple) -> str:
        if ci_95[0] <= mean_pred <= ci_95[1]:
            return 'green'
        elif ci_99[0] <= mean_pred <= ci_99[1]:
            return 'orange'
        return 'red'

    def _plot(self, mean_true: float, mean_pred: float, ci_95: tuple, ci_99: tuple) -> str:
        from matplotlib.lines import Line2D
        fig, ax = figure(size="small")
        # Corporate CI lines
        ax.hlines([ci_99[0], ci_99[1]], xmin=-0.2, xmax=0.2, colors=COLORS['RED'], linewidth=2)
        ax.hlines([ci_95[0], ci_95[1]], xmin=-0.2, xmax=0.2, colors=COLORS['ORANGE'], linewidth=3)
        # Points
        ax.scatter([0], [mean_true], color=COLORS['BLUE'], s=60, label="Observed mean")
        ax.scatter([0], [mean_pred], color=COLORS['EMERALD'], s=60, label="Predicted mean")
        ax.set_xlim(-0.5, 0.5)
        ymin = min(ci_99[0], ci_95[0], mean_true, mean_pred)
        ymax = max(ci_99[1], ci_95[1], mean_true, mean_pred)
        ax.set_ylim(ymin - 0.02 * (ymax - ymin), ymax + 0.02 * (ymax - ymin))
        ax.set_xticks([])
        ax.set_title("Observed vs Predicted Mean with 95%/99% CI")
        legend_lines = [
            Line2D([0], [0], color=COLORS['ORANGE'], lw=3, label="95% CI"),
            Line2D([0], [0], color=COLORS['RED'], lw=2, label="99% CI"),
        ]
        scatter = [
            Line2D([0], [0], marker='o', color='w', label='Observed mean', markerfacecolor=COLORS['BLUE'], markersize=8),
            Line2D([0], [0], marker='o', color='w', label='Predicted mean', markerfacecolor=COLORS['EMERALD'], markersize=8),
        ]
        ax.legend(handles=legend_lines + scatter, loc='upper right')
        buf = BytesIO()
        plt.tight_layout()
        plt.savefig(buf, format='png', bbox_inches='tight')
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode('utf-8')

    def _compute_panel(self, target, score, w, model_mode: str,
                       gamma_dispersion: Optional[float] = None) -> tuple[str, str]:
        """Observed/predicted means + CI around predicted + signal for one sample.

        Returns ``(signal, panel_html)``. ``panel_html`` excludes the top-level
        ``<h4>`` (added once by :meth:`run`).
        """
        target = pd.Series(target)
        score = pd.Series(score)
        if not pd.api.types.is_numeric_dtype(score) or not pd.api.types.is_numeric_dtype(target):
            raise ValueError("Score and target must be numeric.")
        if score.isnull().any() or target.isnull().any():
            raise ValueError("Score and target must not contain NaN values.")

        w_arr = None
        if w is not None:
            w_series = w.reindex(target.index) if hasattr(w, "reindex") else pd.Series(np.asarray(w))
            w_arr = w_series.to_numpy(dtype=float)

        # Для страховой частоты:
        # Observed rate = Sum(events) / Sum(exposure)
        # Predicted rate = Sum(prediction * exposure) / Sum(exposure) = weighted mean(prediction)
        if model_mode == 'frequency':
            mean_true = self._rate_mean(target.to_numpy(), w_arr)
            mean_pred = self._weighted_mean(score.to_numpy(), w_arr)
        else:
            mean_true = self._weighted_mean(target.to_numpy(), w_arr)
            mean_pred = self._weighted_mean(score.to_numpy(), w_arr)

        # Build CI around the *predicted* mean (calibration-test
        # interpretation: would the observed mean be expected if the
        # model-implied rate were the truth?).
        ci_method = 'empirical normal'
        if model_mode == 'binary':
            n_eff = (np.sum(w_arr) ** 2 / np.sum(np.asarray(w_arr, dtype=float) ** 2)) if w_arr is not None and np.sum(w_arr) > 0 else float(target.size)
            n_eff = max(1.0, float(n_eff))
            se_b = np.sqrt(max(mean_pred * (1 - mean_pred), 0.0) / n_eff)
            ci_95 = (mean_pred - 1.96 * se_b, mean_pred + 1.96 * se_b)
            ci_99 = (mean_pred - 2.576 * se_b, mean_pred + 2.576 * se_b)
            ci_method = 'binomial normal (around predicted)'
        elif model_mode == 'frequency':
            ci_95 = self._ci_mean_poisson(target.values, 1.96, w_arr, center_rate=mean_pred)
            ci_99 = self._ci_mean_poisson(target.values, 2.576, w_arr, center_rate=mean_pred)
            ci_method = 'Poisson SE = sqrt(λ̂ / Σw) around predicted'
        elif model_mode == 'severity':
            ci_95 = self._ci_mean_gamma(target.values, 1.96, w_arr, gamma_dispersion)
            ci_99 = self._ci_mean_gamma(target.values, 2.576, w_arr, gamma_dispersion)
            ci_method = 'Gamma'
        else:
            ci_95 = self._ci_mean_regression(target.values, 1.96, w_arr)
            ci_99 = self._ci_mean_regression(target.values, 2.576, w_arr)

        # Signal: observed mean inside CI95 → green, inside CI99 only → orange, outside → red.
        if ci_95[0] <= mean_true <= ci_95[1]:
            sig = 'green'
        elif ci_99[0] <= mean_true <= ci_99[1]:
            sig = 'orange'
        else:
            sig = 'red'
        img = self._plot(mean_true, mean_pred, ci_95, ci_99)
        n_obs = int(target.size)

        # Reference output: single-row table | n | observed | predicted | CI 99 low | CI 95 low | CI 95 high | CI 99 high |
        table_html = (
            "<table border='1' cellpadding='6' cellspacing='0' style='border-collapse:collapse;'>"
            "<thead><tr>"
            "<th>Число наблюдений</th>"
            "<th>Средний уровень целевого события</th>"
            "<th>Средний уровень прогноза</th>"
            "<th>CI 99% low</th>"
            "<th>CI 95% low</th>"
            "<th>CI 95% high</th>"
            "<th>CI 99% high</th>"
            "</tr></thead><tbody><tr>"
            f"<td>{n_obs}</td>"
            f"<td>{mean_true:.4f}</td>"
            f"<td>{mean_pred:.4f}</td>"
            f"<td>{ci_99[0]:.4f}</td>"
            f"<td>{ci_95[0]:.4f}</td>"
            f"<td>{ci_95[1]:.4f}</td>"
            f"<td>{ci_99[1]:.4f}</td>"
            "</tr></tbody></table>"
        )
        panel_html = f"""
        <p><b>Signal:</b> <span style='color:{sig}; font-weight:bold'>{sig.upper()}</span>
        &nbsp;&nbsp;<i>(observed mean {'inside' if sig != 'red' else 'OUTSIDE'} CI around predicted)</i></p>
        <p><i>Model mode: {model_mode}. CI method: {ci_method}.</i></p>
        {table_html}
        <br>
        <img src='data:image/png;base64,{img}' />
        """
        return sig, panel_html

    def run(self, df: Optional[pd.DataFrame] = None, config: Optional[dict] = None,
            score: Optional[pd.Series] = None, target: Optional[pd.Series] = None,
            sample: str = 'genpop', show_sample_tabs: bool = True, **kwargs) -> Dict[str, str]:
        """Supports two invocation styles:
        - New (preferred): run(df=..., config=...). Renders Test/Train/All tabs
          (``show_sample_tabs=True``) and reports the flag computed on the **Test**
          sample. Set ``show_sample_tabs=False`` to render a single ``sample``.
        - Backward-compatible: run(score=..., target=...).
        """
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # Distribution dispatch: preset.calibration_distribution wins when
        # available, otherwise fall back to model_mode (legacy contract).
        # Aliases map both spellings to the canonical CI branch labels.
        model_mode = str(kwargs.get('distribution') or kwargs.get('model_mode') or '').lower() or None
        mode_aliases = {
            'gamma': 'severity',
            'poisson': 'frequency',
            'binomial': 'binary',
            'classification': 'binary',
        }
        model_mode = mode_aliases.get(model_mode, model_mode)
        gamma_dispersion = kwargs.get('gamma_dispersion')

        sample_payloads = []
        # Config-driven path
        if df is not None and config is not None:
            try:
                cfg = ensure_config(config, df)
                if is_generic_classification_mode(cfg):
                    self.test_signal = 'blue'
                    logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                    return _classification_mode_na(self.test_name)
                target_col = getattr(cfg.columns, 'target_column', None)
                score_col = get_col_name(cfg, 'score_column')
                weight_col = getattr(cfg.columns, 'weight_column', None)
                if is_big_data_mode(cfg):
                    train_mask, test_mask = split_sample_masks(df, cfg)
                    needed_cols = [target_col, score_col, weight_col]
                    needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
                    df_small = df.loc[:, needed_cols]
                    df_tr = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=250_000, random_state=411).copy()
                    df_te = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=250_000, random_state=412).copy()
                    df_all = sample_frame_for_big_data(df_small, cfg, max_rows=350_000, random_state=413).copy()
                else:
                    df_tr, df_te, df_all = split_frames(df, cfg)
                # Preset takes priority over model_mode for the CI branch.
                preset = getattr(cfg, "preset", None)
                if preset is not None:
                    # poisson|gamma|binomial -> internal frequency|severity|binary labels
                    model_mode = mode_aliases.get(preset.calibration_distribution, preset.calibration_distribution)
                else:
                    model_mode = get_model_mode(cfg)

                if show_sample_tabs:
                    sample_frames = [("test", "Test", df_te), ("train", "Train", df_tr), ("all", "All", df_all)]
                else:
                    sample_map = {
                        "train": ("train", "Train", df_tr),
                        "test": ("test", "Test", df_te),
                        "genpop": ("all", "All", df_all),
                        "all": ("all", "All", df_all),
                    }
                    sample_frames = [sample_map.get(str(sample).lower(), ("all", "All", df_all))]

                for key, label, df_used in sample_frames:
                    y, pred, sc = get_vectors(df_used, cfg, for_classification=is_binary_mode(cfg))
                    try:
                        w_series = get_weight_col(df_used, cfg)
                    except Exception:
                        w_series = None
                    sample_payloads.append({
                        "key": key, "label": label,
                        "target": y, "score": sc if sc is not None else pred, "w": w_series,
                    })
            except Exception as e:
                self.test_signal = 'red'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"combined": f"<h4>Predicted vs Observed Rate of Target</h4><p>Config error: {str(e)}</p>"}
        else:
            # Backward-compatible direct path: single panel, no tabs.
            if score is None or target is None:
                self.test_signal = 'red'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"combined": "<h4>Predicted vs Observed Rate of Target</h4><p>Missing score/target data.</p>"}
            if model_mode is None:
                model_mode = 'binary' if type_of_target(target) == 'binary' else 'regression'
                model_mode = mode_aliases.get(model_mode, model_mode)
            sample_payloads.append({"key": "all", "label": "All", "target": target, "score": score, "w": None})

        if model_mode is None:
            model_mode = 'binary' if type_of_target(sample_payloads[0]["target"]) == 'binary' else 'regression'
            model_mode = mode_aliases.get(model_mode, model_mode)

        tabs = []
        signal_by_key = {}
        for p in sample_payloads:
            try:
                sig, panel_html = self._compute_panel(p["target"], p["score"], p["w"], model_mode, gamma_dispersion)
            except Exception as e:
                sig, panel_html = 'red', f"<p><i>Ошибка расчёта по выборке {p['label']}: {e}</i></p>"
            signal_by_key[p["key"]] = sig
            tabs.append({
                "label": p["label"],
                "html": panel_html,
                "color": COLORS['BLUE'] if p["key"] == "test" else COLORS['GRAY_DARK'],
            })

        # Итоговый флаг — по выборке Test (fallback: All, затем первая доступная).
        overall = signal_by_key.get("test") or signal_by_key.get("all") or next(iter(signal_by_key.values()))
        self.test_signal = overall

        if len(tabs) > 1:
            body = build_tabbed_sections_html(tabs, root_prefix="m41-sample")
            signal_label = "Signal (Test)"
            flag_note = "<p><i>Итоговый флаг теста рассчитан по выборке <b>Test</b>.</i></p>"
        else:
            body = tabs[0]["html"]
            signal_label = "Signal"
            flag_note = ""

        html = f"""
        <h4>Predicted vs Observed Rate of Target</h4>
        <p><b>{signal_label}:</b> <span style='color:{overall}; font-weight:bold'>{overall.upper()}</span></p>
        {flag_note}
        {body}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


