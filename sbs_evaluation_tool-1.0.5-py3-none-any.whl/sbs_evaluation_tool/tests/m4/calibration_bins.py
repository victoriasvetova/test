# -*- coding: utf-8 -*-
"""Auto-extracted from ``tests/m4_model_performance.py`` in the Phase 2 split.

See ``tests/m4/__init__.py`` for the package overview.
"""

from __future__ import annotations
import base64
from io import BytesIO
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import logging

from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score, r2_score, mean_squared_error
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
from sklearn.utils.multiclass import type_of_target

from ...core.base_test import BaseModelTest
from ...core.metrics import gini_normalized, bootstrap_values
from ...core.styles import COLORS, STATUS_COLORS, figure
from ...core.render_context import get_render_mode
from ...core.config_validation import validate_config as _validate_config, ConfigValidationError
from ...core.data_utils import (
    ensure_config,
    split_frames,
    split_sample_masks,
    get_weight_col,
    get_col_name,
    get_vectors,
    get_features,
    get_model_mode,
    is_binary_mode,
    is_big_data_mode,
    is_generic_classification_mode,
    sample_frame_for_big_data,
)
from .._visual_utils import (
    MEAN_RATE_LABEL,
    OBSERVATION_COUNT_LABEL,
    SHARE_LABEL,
    build_tabbed_sections_html,
    build_period_specs,
    build_scale_specs,
    figure_to_base64,
)

import matplotlib.dates as mdates
from math import log

from ._shared import (
    _classification_mode_na,
    _subset_by_sample,
    _safe_threshold_labels,
    _to_base64,
    calibration_traffic_light,
)

logger = logging.getLogger(__name__)


class M42_CalibrationCurveByPredictBinsLn(BaseModelTest):
    """Калибровка по бинам предсказаний.

    По умолчанию тест строит две версии графика:
    - обычная шкала
    - логарифмическая шкала

    Для обратной совместимости можно отключить двойной вывод и оставить только
    одну из шкал через show_both_scales=False + use_log_scale.
    """
    def __init__(
        self,
        test_num='M 4.2',
        test_name='Calibration Curve (Predict Bins)',
        use_log_scale: bool = False,
        show_both_scales: bool = True,
    ):
        resolved_name = test_name
        if not show_both_scales and use_log_scale:
            resolved_name += ' (ln scale)'
        super().__init__(test_num, resolved_name)
        self.use_log_scale = use_log_scale
        self.show_both_scales = show_both_scales

    @staticmethod
    def _safe_log(x):
        x = np.asarray(x, dtype=float)
        return np.log(np.clip(x, 1e-12, None))

    @staticmethod
    def _format_intervals(intervals) -> list:
        """Render pd.Interval values with adaptive precision.

        The default ``str(Interval)`` keeps every float digit, producing labels
        like ``(8.8e-05, 0.00152]``. Here we pick a number of decimals from the
        smallest gap between bin edges, so the labels stay tight but distinct.
        """
        ivals = list(intervals)
        edges = []
        for iv in ivals:
            if hasattr(iv, "left") and hasattr(iv, "right"):
                edges.extend([iv.left, iv.right])
        edges = [e for e in edges if np.isfinite(e)]
        if len(edges) < 2:
            return [str(iv) for iv in ivals]
        uniq = sorted(set(edges))
        diffs = np.diff(uniq)
        diffs = diffs[diffs > 0]
        if len(diffs) == 0:
            return [str(iv) for iv in ivals]
        min_step = float(np.min(diffs))
        # Decimals = enough to show min_step with ~2 significant digits.
        decimals = max(0, int(np.ceil(-np.log10(min_step))) + 1)
        decimals = min(decimals, 6)

        def fmt(x):
            if not np.isfinite(x):
                return str(x)
            return f"{x:.{decimals}f}"

        out = []
        for iv in ivals:
            if hasattr(iv, "left") and hasattr(iv, "right"):
                out.append(f"({fmt(iv.left)}, {fmt(iv.right)}]")
            else:
                out.append(str(iv))
        return out

    def _compute_grouped(self, score: pd.Series, target: pd.Series, weight: Optional[pd.Series] = None,
                         num_groups: int = 20, bins_step: float = None,
                         binning: str = "count_quantile") -> pd.DataFrame:
        """Compute per-bin observed / predicted means.

        Parameters
        ----------
        binning : {"count_quantile", "exposure_quantile", "fixed_width"}
            How to slice the score axis:

            * ``count_quantile`` (legacy default): ``pd.qcut`` — each bin
              holds ~ N/num_groups rows. Sensitive to score-tie clustering.
            * ``exposure_quantile``: sort by score, cut at quantiles of
              the cumulative exposure (``Σw``). Each bin carries
              ~ Σw/num_groups exposure-mass — the actuarial standard for
              Poisson-frequency calibration plots.
            * ``fixed_width``: ``pd.cut`` on a uniform grid (used when
              ``bins_step`` is provided).
        """
        df = pd.DataFrame({"score": score, "target": target})
        if weight is not None:
            w = pd.to_numeric(weight, errors="coerce").reindex(df.index).fillna(0.0)
            df["weight"] = w
        if bins_step:
            bins = np.arange(float(score.min()), float(score.max()) + float(bins_step), float(bins_step))
            if len(bins) < 2:
                bins = np.linspace(float(score.min()), float(score.max()), max(3, num_groups))
            df["bin"] = pd.cut(df["score"], bins=bins, include_lowest=True)
        elif binning == "exposure_quantile" and "weight" in df.columns and df["weight"].sum() > 0:
            # Sort rows by score, then split into ``num_groups`` chunks of
            # equal cumulative exposure. Edge values are taken from the
            # score column so the bin labels stay meaningful.
            order = df["score"].sort_values(kind="mergesort").index
            w_sorted = df.loc[order, "weight"].to_numpy(dtype=float)
            sc_sorted = df.loc[order, "score"].to_numpy(dtype=float)
            cum_w = np.cumsum(w_sorted)
            total_w = float(cum_w[-1])
            target_edges = np.linspace(0, total_w, num_groups + 1)
            # For each interior target edge, find the row where cum_w crosses it.
            edge_positions = np.searchsorted(cum_w, target_edges[1:-1], side="right")
            edge_positions = np.clip(edge_positions, 1, len(sc_sorted) - 1)
            edge_scores = sc_sorted[edge_positions]
            bin_edges = np.concatenate([[sc_sorted[0]], edge_scores, [sc_sorted[-1]]])
            # Dedupe consecutive equal edges (score ties can collapse bins).
            bin_edges = np.unique(bin_edges)
            if len(bin_edges) < 2:
                bin_edges = np.array([sc_sorted[0], sc_sorted[-1] + 1e-12])
            df["bin"] = pd.cut(df["score"], bins=bin_edges, include_lowest=True, duplicates="drop")
        else:
            df['bin'] = pd.qcut(df['score'], q=min(num_groups, max(1, df['score'].nunique())), duplicates='drop')
        if "weight" in df.columns:
            grouped = df.groupby("bin", observed=False)[["score", "target", "weight"]].apply(
                lambda g: pd.Series({
                    "n_obs": int(len(g)),
                    "count": float(g["weight"].sum()),
                    # Для страховой частоты: observed rate = sum(events) / sum(exposure)
                    "mean_true": float(g["target"].sum() / g["weight"].sum()) if g["weight"].sum() > 0 else 0.0,
                    # Для predicted: взвешенное среднее = sum(score * exposure) / sum(exposure)
                    "mean_pred": float(np.average(g["score"], weights=g["weight"])),
                    # Для rate стандартное отклонение считается от индивидуальных rate_i относительно среднего rate
                    "std_true": float(np.sqrt(np.sum((g["target"] - (g["target"].sum() / g["weight"].sum()) * g["weight"]) ** 2 / g["weight"]) / len(g)) if g["weight"].sum() > 0 and np.all(g["weight"] > 0) else g["target"].std()),
                })
            ).reset_index()
        else:
            grouped = df.groupby("bin", observed=False).agg(
                n_obs=("target", "count"),
                count=("target", "count"),
                mean_true=("target", "mean"),
                mean_pred=("score", "mean"),
                std_true=("target", "std"),
            ).reset_index()
        return grouped

    def _plot(self, grouped: pd.DataFrame, mode: str, use_log_scale: bool) -> tuple[str, str, Dict[str, bool]]:
        fig, ax1 = figure(size="short")
        x = np.arange(len(grouped))
        labels = self._format_intervals(grouped['bin'].tolist())

        # CI around observed mean
        # Для взвешенных данных count = sum(weights) в каждом бине
        # Эффективный размер выборки учитывает неравномерность весов
        n = grouped['count'].replace(0, np.nan)
        if mode == 'classification':
            p = grouped['mean_true'].clip(0, 1)
            # Для взвешенной выборки используем count как эффективный n
            # (уже учтено в _compute_grouped для взвешенного случая)
            se = np.sqrt(p * (1 - p)) / np.sqrt(n)
            ci95_low = (p - 1.96 * se).clip(lower=0)
            ci95_high = (p + 1.96 * se).clip(upper=1)
            ci99_low = (p - 2.58 * se).clip(lower=0)
            ci99_high = (p + 2.58 * se).clip(upper=1)
        else:
            # Для регрессии используем взвешенное std и count
            se = grouped['std_true'] / np.sqrt(n)
            m = grouped['mean_true']
            ci95_low = m - 1.96 * se
            ci95_high = m + 1.96 * se
            ci99_low = m - 2.58 * se
            ci99_high = m + 2.58 * se

        # Bright shaded CI areas (plot on ln scale values if requested)
        if use_log_scale:
            y_obs = self._safe_log(grouped['mean_true'])
            y_pred = self._safe_log(grouped['mean_pred'])
            ci99_l = self._safe_log(ci99_low)
            ci99_h = self._safe_log(ci99_high)
            ci95_l = self._safe_log(ci95_low)
            ci95_h = self._safe_log(ci95_high)
            ylabel = f"ln({MEAN_RATE_LABEL})"
        else:
            y_obs = grouped['mean_true']
            y_pred = grouped['mean_pred']
            ci99_l = ci99_low
            ci99_h = ci99_high
            ci95_l = ci95_low
            ci95_h = ci95_high
            ylabel = MEAN_RATE_LABEL

        ax1.fill_between(x, ci99_l, ci99_h, color=COLORS['RED'], alpha=0.30, label="99% CI (observed)")
        ax1.fill_between(x, ci95_l, ci95_h, color=COLORS['ORANGE'], alpha=0.45, label="95% CI (observed)")

        obs_label = "Observed mean (ln)" if use_log_scale else "Observed mean"
        pred_label = "Predicted mean (ln)" if use_log_scale else "Predicted mean"
        ax1.plot(x, y_obs, label=obs_label, marker='o', color=COLORS['BLUE'])
        ax1.plot(x, y_pred, label=pred_label, linestyle='--', color=COLORS['GRAY_DARK'])

        # Mark red-zone violations with red stars (predicted outside 99% CI)
        # Note: logic remains on original scale values for mask check
        red_mask = (grouped['mean_pred'] > ci99_high) | (grouped['mean_pred'] < ci99_low)
        ax1.scatter(np.where(red_mask)[0], y_pred[red_mask], color=COLORS['RED'], marker='*', s=120, zorder=5, label="Pred>99% CI (red)")

        ax1.set_xlabel("Prediction Bins")
        ax1.set_ylabel(ylabel)
        ax1.set_xticks(x)
        ax1.set_xticklabels(labels, rotation=45, ha='right')
        ax1.grid(True, linestyle='--', alpha=0.3)

        # Secondary axis: bin share %
        ax2 = ax1.twinx()
        share_pct = grouped['count'] / max(1.0, grouped['count'].sum()) * 100.0
        ax2.bar(x, share_pct, alpha=0.35, color=COLORS['EMERALD'], label="Bin Share (%)")
        ax2.set_ylabel(f"{SHARE_LABEL} (%)")

        # Legends
        ax1.legend(loc='upper left')
        ax2.legend(loc='upper right')
        plt.tight_layout()
        img_b64 = figure_to_base64(fig)
        plt.close(fig)

        # Per-bin statuses + binomial-derived counts (used by traffic-light logic).
        out95_mask = (grouped['mean_pred'] > ci95_high) | (grouped['mean_pred'] < ci95_low)
        orange_only_mask = out95_mask & (~red_mask)
        flags = {
            'n_bins': int(len(grouped)),
            'n_out_95': int(out95_mask.sum()),      # outside 95 % CI (includes out-of-99 %)
            'n_out_99': int(red_mask.sum()),        # outside 99 % CI (red zone)
            # Legacy keys kept so plot-rendering paths can still highlight stars.
            'any_red':    bool(np.any(red_mask)),
            'any_orange': bool(np.any(orange_only_mask)),
        }
        return img_b64, grouped.to_html(index=False, float_format='%.6f'), flags

    def _plot_plotly(self, grouped: pd.DataFrame, mode: str, use_log_scale: bool) -> tuple[str, Dict[str, bool]]:
        """Plotly-вариант ``_plot``. Возвращает (html_div, flags)."""
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots

        x = np.arange(len(grouped))
        labels = self._format_intervals(grouped['bin'].tolist())
        n = grouped['count'].replace(0, np.nan)
        if mode == 'classification':
            p = grouped['mean_true'].clip(0, 1)
            se = np.sqrt(p * (1 - p)) / np.sqrt(n)
            ci95_low = (p - 1.96 * se).clip(lower=0)
            ci95_high = (p + 1.96 * se).clip(upper=1)
            ci99_low = (p - 2.58 * se).clip(lower=0)
            ci99_high = (p + 2.58 * se).clip(upper=1)
        else:
            se = grouped['std_true'] / np.sqrt(n)
            m = grouped['mean_true']
            ci95_low = m - 1.96 * se
            ci95_high = m + 1.96 * se
            ci99_low = m - 2.58 * se
            ci99_high = m + 2.58 * se

        if use_log_scale:
            y_obs = self._safe_log(grouped['mean_true'])
            y_pred = self._safe_log(grouped['mean_pred'])
            ci99_l = self._safe_log(ci99_low)
            ci99_h = self._safe_log(ci99_high)
            ci95_l = self._safe_log(ci95_low)
            ci95_h = self._safe_log(ci95_high)
            ylabel = f"ln({MEAN_RATE_LABEL})"
        else:
            y_obs = grouped['mean_true']
            y_pred = grouped['mean_pred']
            ci99_l = ci99_low
            ci99_h = ci99_high
            ci95_l = ci95_low
            ci95_h = ci95_high
            ylabel = MEAN_RATE_LABEL

        red_mask = (grouped['mean_pred'] > ci99_high) | (grouped['mean_pred'] < ci99_low)
        orange_mask = ((grouped['mean_pred'] > ci95_high) | (grouped['mean_pred'] < ci95_low)) & (~red_mask)

        fig = make_subplots(specs=[[{"secondary_y": True}]])

        share_pct = (grouped['count'] / max(1.0, grouped['count'].sum()) * 100.0).to_numpy()
        fig.add_trace(
            go.Bar(x=labels, y=share_pct, name=f"{SHARE_LABEL} (%)",
                   marker=dict(color=COLORS['EMERALD']), opacity=0.35,
                   hovertemplate="%{x}<br>Share: %{y:.1f}%<extra></extra>"),
            secondary_y=True,
        )

        # 99% CI band
        fig.add_trace(
            go.Scatter(x=labels, y=ci99_l, mode="lines", line=dict(width=0),
                       hoverinfo="skip", showlegend=False),
            secondary_y=False,
        )
        fig.add_trace(
            go.Scatter(x=labels, y=ci99_h, mode="lines", line=dict(width=0),
                       fill="tonexty", fillcolor="rgba(250,25,41,0.25)",
                       name="99% CI", hoverinfo="skip"),
            secondary_y=False,
        )
        # 95% CI band
        fig.add_trace(
            go.Scatter(x=labels, y=ci95_l, mode="lines", line=dict(width=0),
                       hoverinfo="skip", showlegend=False),
            secondary_y=False,
        )
        fig.add_trace(
            go.Scatter(x=labels, y=ci95_h, mode="lines", line=dict(width=0),
                       fill="tonexty", fillcolor="rgba(255,204,0,0.45)",
                       name="95% CI", hoverinfo="skip"),
            secondary_y=False,
        )

        obs_label = "Observed mean (ln)" if use_log_scale else "Observed mean"
        pred_label = "Predicted mean (ln)" if use_log_scale else "Predicted mean"
        fig.add_trace(
            go.Scatter(x=labels, y=y_obs, mode="lines+markers", name=obs_label,
                       line=dict(color=COLORS['BLUE'], width=2),
                       marker=dict(size=7),
                       hovertemplate="%{x}<br>Observed: %{y:.5f}<extra></extra>"),
            secondary_y=False,
        )
        fig.add_trace(
            go.Scatter(x=labels, y=y_pred, mode="lines+markers", name=pred_label,
                       line=dict(color=COLORS['GRAY_DARK'], dash="dash", width=2),
                       marker=dict(size=6),
                       hovertemplate="%{x}<br>Predicted: %{y:.5f}<extra></extra>"),
            secondary_y=False,
        )

        red_idx = np.where(red_mask)[0]
        if red_idx.size:
            fig.add_trace(
                go.Scatter(x=[labels[i] for i in red_idx],
                           y=[y_pred.iloc[i] if hasattr(y_pred, "iloc") else y_pred[i] for i in red_idx],
                           mode="markers", name="Pred>99% CI",
                           marker=dict(symbol="star", size=15, color=COLORS['RED'])),
                secondary_y=False,
            )

        fig.update_layout(
            template="plotly_white",
            hovermode="x unified",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
            margin=dict(l=60, r=60, t=60, b=120),
            height=440,
        )
        fig.update_xaxes(title_text="Prediction Bins", tickangle=-45)
        fig.update_yaxes(title_text=ylabel, secondary_y=False)
        fig.update_yaxes(title_text=f"{SHARE_LABEL} (%)", secondary_y=True, showgrid=False)

        html = fig.to_html(include_plotlyjs="cdn", full_html=False, config={"displaylogo": False})
        out95_mask = (grouped['mean_pred'] > ci95_high) | (grouped['mean_pred'] < ci95_low)
        flags = {
            'n_bins': int(len(grouped)),
            'n_out_95': int(out95_mask.sum()),
            'n_out_99': int(red_mask.sum()),
            'any_red': bool(np.any(red_mask)),
            'any_orange': bool(np.any(orange_mask)),
        }
        return html, flags

    @staticmethod
    def _adjusted_hhi_from_counts(counts: pd.Series) -> float:
        values = pd.to_numeric(counts, errors="coerce").dropna().astype(float)
        values = values[values > 0]
        n_total = float(values.sum())
        n_groups = int(len(values))
        if n_total <= 0:
            return float("nan")
        if n_groups <= 1:
            return 1.0
        shares = values / n_total
        raw_hhi = float(np.sum(np.square(shares)))
        adjusted = (raw_hhi - 1.0 / n_groups) / (1.0 - 1.0 / n_groups)
        return float(np.clip(adjusted, 0.0, 1.0))

    @staticmethod
    def _hhi_traffic_light(hhi_value: float, orange_threshold: float, red_threshold: float) -> str:
        if not np.isfinite(hhi_value):
            return "gray"
        if hhi_value > red_threshold:
            return "red"
        if hhi_value > orange_threshold:
            return "orange"
        return "green"

    @staticmethod
    def _worst_signal(signals: List[str]) -> str:
        rank = {"gray": 0, "blue": 0, "green": 1, "orange": 2, "red": 3}
        ordered = [s for s in signals if s in rank]
        if not ordered:
            return "blue"
        return max(ordered, key=lambda s: rank[s])

    @staticmethod
    def _signal_html(label: str, signal: str) -> str:
        return f"<p><b>{label}:</b> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span></p>"

    def _binning_specs(self, weight: Optional[pd.Series], bins_step: float = None) -> List[tuple[str, str, str]]:
        if weight is not None and not bins_step:
            return [
                ("count_quantile",    "Bins by count",    COLORS['GRAY_DARK']),
                ("exposure_quantile", "Bins by exposure", COLORS['BLUE']),
            ]
        return [
            ("count_quantile",    "Bins by count",    COLORS['GRAY_DARK']),
        ]

    def _prepare_sample_data(
        self,
        score: Optional[pd.Series],
        target: Optional[pd.Series],
        weight: Optional[pd.Series],
        num_groups: int,
        bins_step: float = None,
    ) -> tuple[Optional[pd.Series], Optional[pd.Series], Optional[pd.Series], Optional[str]]:
        if score is None or target is None:
            return None, None, None, "Missing score/target data."

        score = pd.Series(score)
        target = pd.Series(target)
        if len(score) == 0 or len(target) == 0:
            return None, None, None, "No rows in the selected sample."
        if len(score) != len(target):
            raise ValueError("Score and target must have the same length.")
        if not pd.api.types.is_numeric_dtype(score) or not pd.api.types.is_numeric_dtype(target):
            raise ValueError("Score and target must be numeric.")
        if score.isnull().any() or target.isnull().any():
            raise ValueError("Score and target must not contain NaN values.")
        if not bins_step and len(score) < num_groups:
            return None, None, None, "Not enough rows for the requested number of groups."

        if weight is not None:
            weight = pd.to_numeric(pd.Series(weight), errors="coerce").reindex(score.index).fillna(0.0)
            if (weight > 0).sum() == 0:
                weight = None

        return score, target, weight, None

    def _compute_grouped_hhi_adjusted(
        self,
        score: pd.Series,
        target: pd.Series,
        weight: Optional[pd.Series],
        num_groups: int,
        bins_step: float,
        binning: str,
        hhi_orange_threshold: float,
    ) -> tuple[pd.DataFrame, dict]:
        if bins_step:
            grouped = self._compute_grouped(
                score, target, weight=weight, num_groups=num_groups,
                bins_step=bins_step, binning=binning,
            )
            hhi = self._adjusted_hhi_from_counts(grouped["n_obs"])
            return grouped, {
                "requested_groups": int(num_groups),
                "selected_groups": "fixed width",
                "actual_bins": int(len(grouped)),
                "n_total": int(pd.to_numeric(grouped["n_obs"], errors="coerce").fillna(0).sum()),
                "hhi_adj": hhi,
            }

        max_groups = int(min(max(1, num_groups), max(1, score.nunique()), len(score)))
        best_grouped = None
        best_meta = None
        for candidate_groups in range(max_groups, 0, -1):
            try:
                grouped = self._compute_grouped(
                    score, target, weight=weight, num_groups=candidate_groups,
                    bins_step=None, binning=binning,
                )
            except ValueError:
                continue
            if grouped.empty:
                continue

            hhi = self._adjusted_hhi_from_counts(grouped["n_obs"])
            meta = {
                "requested_groups": int(num_groups),
                "selected_groups": int(candidate_groups),
                "actual_bins": int(len(grouped)),
                "n_total": int(pd.to_numeric(grouped["n_obs"], errors="coerce").fillna(0).sum()),
                "hhi_adj": hhi,
            }
            if best_meta is None:
                best_grouped, best_meta = grouped, meta
            else:
                best_hhi = float(best_meta["hhi_adj"])
                if hhi < best_hhi - 1e-12 or (np.isclose(hhi, best_hhi) and len(grouped) > len(best_grouped)):
                    best_grouped, best_meta = grouped, meta

            # Keep the highest number of candidate groups that already gives
            # a green HHI split.
            if hhi <= hhi_orange_threshold:
                return grouped, meta

        if best_grouped is None or best_meta is None:
            grouped = self._compute_grouped(
                score, target, weight=weight, num_groups=num_groups,
                bins_step=None, binning=binning,
            )
            hhi = self._adjusted_hhi_from_counts(grouped["n_obs"])
            best_grouped = grouped
            best_meta = {
                "requested_groups": int(num_groups),
                "selected_groups": int(num_groups),
                "actual_bins": int(len(grouped)),
                "n_total": int(pd.to_numeric(grouped["n_obs"], errors="coerce").fillna(0).sum()),
                "hhi_adj": hhi,
            }
        return best_grouped, best_meta

    def _render_plot_tabs(
        self,
        grouped: pd.DataFrame,
        mode: str,
        scale_specs: List[tuple[bool, str]],
        binning_label: str,
        binning_color: str,
        use_plotly: bool,
        prefix_html: str = "",
    ) -> tuple[List[dict], Dict[str, bool]]:
        tabs = []
        first_flags = {'any_red': False, 'any_orange': False}
        for idx, (scale_flag, scale_title) in enumerate(scale_specs):
            if use_plotly:
                plot_html, plot_flags = self._plot_plotly(grouped, mode, use_log_scale=scale_flag)
                tab_html = prefix_html + plot_html
            else:
                img_b64, _, plot_flags = self._plot(grouped, mode, use_log_scale=scale_flag)
                tab_html = (
                    prefix_html
                    + f"<img src='data:image/png;base64,{img_b64}' "
                    "style='display:block; width:100%; max-width:1100px; height:auto;' />"
                )
            if idx == 0:
                first_flags = plot_flags
            tabs.append(
                {
                    "label": f"{binning_label} · {scale_title}",
                    "html": tab_html,
                    "color": binning_color if not scale_flag else COLORS['EMERALD'],
                }
            )
        return tabs, first_flags

    def _render_standard_sample_panel(
        self,
        score: Optional[pd.Series],
        target: Optional[pd.Series],
        weight: Optional[pd.Series],
        num_groups: int,
        bins_step: float,
        scale_specs: List[tuple[bool, str]],
        use_plotly: bool,
    ) -> tuple[str, str]:
        score, target, weight, error = self._prepare_sample_data(score, target, weight, num_groups, bins_step)
        if error:
            return f"<p><i>{error}</i></p>", "blue"

        mode = 'classification' if type_of_target(target) == 'binary' else 'regression'
        rendered_tabs = []
        flags = {'n_bins': 0, 'n_out_95': 0, 'n_out_99': 0}
        primary_grouped = None

        for b_idx, (binning_kind, binning_label, binning_color) in enumerate(self._binning_specs(weight, bins_step)):
            grouped = self._compute_grouped(
                score, target, weight=weight, num_groups=num_groups,
                bins_step=bins_step, binning=binning_kind,
            )
            if primary_grouped is None:
                primary_grouped = grouped
            tabs, plot_flags = self._render_plot_tabs(
                grouped, mode, scale_specs, binning_label, binning_color, use_plotly
            )
            if b_idx == 0:
                flags = plot_flags
            rendered_tabs.extend(tabs)

        if primary_grouped is None:
            return "<p><i>No data available for binning.</i></p>", "blue"

        grouped_for_html = primary_grouped.copy()
        grouped_for_html['bin'] = self._format_intervals(primary_grouped['bin'].tolist())
        table_html = grouped_for_html.to_html(index=False, float_format='%.6f')

        n_bins = int(flags.get('n_bins', 0))
        n_out_95 = int(flags.get('n_out_95', 0))
        n_out_99 = int(flags.get('n_out_99', 0))
        signal, thresholds = calibration_traffic_light(n_bins, n_out_95, n_out_99)
        counts_html = (
            f"<p><i>Bins: {n_bins} · outside 95 % CI: {n_out_95} "
            f"(critical orange={thresholds.get('k95_orange','-')} / red={thresholds.get('k99_orange','-')}) "
            f"· outside 99 % CI: {n_out_99} "
            f"(critical orange={thresholds.get('k95_red','-')} / red={thresholds.get('k99_red','-')})</i></p>"
        )

        html = f"""
        {self._signal_html("Standard signal", signal)}
        {counts_html}
        {build_tabbed_sections_html(rendered_tabs, root_prefix="m42-standard-scale")}
        <br>
        <h5>Group Stats</h5>
        {table_html}
        """
        return html, signal

    def _render_hhi_sample_panel(
        self,
        score: Optional[pd.Series],
        target: Optional[pd.Series],
        weight: Optional[pd.Series],
        num_groups: int,
        bins_step: float,
        scale_specs: List[tuple[bool, str]],
        use_plotly: bool,
        hhi_orange_threshold: float,
        hhi_red_threshold: float,
    ) -> tuple[str, str]:
        score, target, weight, error = self._prepare_sample_data(score, target, weight, num_groups, bins_step)
        if error:
            return f"<p><i>{error}</i></p>", "blue"

        mode = 'classification' if type_of_target(target) == 'binary' else 'regression'
        rendered_tabs = []
        hhi_rows = []
        hhi_signals = []
        primary_grouped = None

        for b_idx, (binning_kind, binning_label, binning_color) in enumerate(self._binning_specs(weight, bins_step)):
            grouped, meta = self._compute_grouped_hhi_adjusted(
                score, target, weight=weight, num_groups=num_groups,
                bins_step=bins_step, binning=binning_kind,
                hhi_orange_threshold=hhi_orange_threshold,
            )
            hhi_value = float(meta["hhi_adj"])
            hhi_signal = self._hhi_traffic_light(hhi_value, hhi_orange_threshold, hhi_red_threshold)
            hhi_signals.append(hhi_signal)
            hhi_rows.append(
                {
                    "Binning": binning_label,
                    "Requested groups": meta["requested_groups"],
                    "Selected groups": meta["selected_groups"],
                    "Actual bins": meta["actual_bins"],
                    "N": meta["n_total"],
                    "HHI_adj": hhi_value,
                    "Signal": hhi_signal,
                }
            )
            if primary_grouped is None:
                primary_grouped = grouped

            prefix_html = (
                f"<p><i>Adjusted HHI: <b>{hhi_value:.6f}</b> · "
                f"selected groups: {meta['selected_groups']} · actual bins: {meta['actual_bins']} · "
                f"signal: <span style='color:{hhi_signal}; font-weight:bold'>{hhi_signal.upper()}</span></i></p>"
            )
            tabs, _ = self._render_plot_tabs(
                grouped, mode, scale_specs, binning_label, binning_color, use_plotly, prefix_html=prefix_html
            )
            rendered_tabs.extend(tabs)

        if primary_grouped is None:
            return "<p><i>No data available for HHI binning.</i></p>", "blue"

        signal = self._worst_signal(hhi_signals)
        summary_html = pd.DataFrame(hhi_rows).to_html(index=False, float_format='%.6f')
        grouped_for_html = primary_grouped.copy()
        grouped_for_html['bin'] = self._format_intervals(primary_grouped['bin'].tolist())
        table_html = grouped_for_html.to_html(index=False, float_format='%.6f')
        thresholds_html = (
            f"<p><i>HHI thresholds: green ≤ {hhi_orange_threshold:.4f}; "
            f"orange ≤ {hhi_red_threshold:.4f}; red &gt; {hhi_red_threshold:.4f}.</i></p>"
        )

        html = f"""
        {self._signal_html("HHI signal", signal)}
        {thresholds_html}
        <h5>HHI Summary</h5>
        {summary_html}
        {build_tabbed_sections_html(rendered_tabs, root_prefix="m42-hhi-scale")}
        <br>
        <h5>Group Stats</h5>
        {table_html}
        """
        return html, signal

    def run(self, df: Optional[pd.DataFrame] = None, config: Optional[dict] = None,
        score: Optional[pd.Series] = None, target: Optional[pd.Series] = None,
            num_groups: int = 20, bins_step: float = None, sample: str = 'genpop',
            show_sample_tabs: bool = True,
            hhi_orange_threshold: float = 0.10,
            hhi_red_threshold: float = 0.25,
            **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        if not (0 <= hhi_orange_threshold <= hhi_red_threshold <= 1):
            raise ValueError("HHI thresholds must satisfy 0 <= orange <= red <= 1.")

        sample_payloads = []
        if df is not None and config is not None:
            try:
                cfg = ensure_config(config, df)
                if is_generic_classification_mode(cfg):
                    self.test_signal = 'blue'
                    logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                    return _classification_mode_na(self.test_name)
                target_col = getattr(cfg.columns, 'target_column', None)
                score_col = get_col_name(cfg, 'score_column') or get_col_name(cfg, 'prediction_column')
                weight_col = getattr(cfg.columns, 'weight_column', None)
                if is_big_data_mode(cfg):
                    train_mask, test_mask = split_sample_masks(df, cfg)
                    needed_cols = [target_col, score_col, weight_col]
                    needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
                    df_small = df.loc[:, needed_cols]
                    df_tr = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=250_000, random_state=421).copy()
                    df_te = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=250_000, random_state=422).copy()
                    df_all = sample_frame_for_big_data(df_small, cfg, max_rows=350_000, random_state=423).copy()
                else:
                    df_tr, df_te, df_all = split_frames(df, cfg)

                if show_sample_tabs:
                    sample_frames = [
                        ("test", "Test", df_te),
                        ("train", "Train", df_tr),
                        ("all", "All", df_all),
                    ]
                else:
                    sample_key = str(sample).lower()
                    sample_map = {"train": df_tr, "test": df_te, "genpop": df_all, "all": df_all}
                    sample_label_map = {"train": "Train", "test": "Test", "genpop": "All", "all": "All"}
                    sample_frames = [
                        (sample_key, sample_label_map.get(sample_key, "All"), sample_map.get(sample_key, df_all))
                    ]

                for sample_key, sample_label, df_used in sample_frames:
                    y, pred, sc = get_vectors(df_used, cfg, for_classification=is_binary_mode(cfg))
                    sample_payloads.append(
                        {
                            "key": sample_key,
                            "label": sample_label,
                            "score": sc if sc is not None else pred,
                            "target": y,
                            "weight": get_weight_col(df_used, cfg),
                        }
                    )
            except Exception as e:
                self.test_signal = 'red'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"combined": f"<h4>Calibration Curve by Predict Bins</h4><p>Config error: {str(e)}</p>"}
        else:
            sample_payloads.append(
                {
                    "key": "all",
                    "label": "All",
                    "score": score,
                    "target": target,
                    "weight": None,
                }
            )

        scale_specs = build_scale_specs(self.show_both_scales, self.use_log_scale)
        use_plotly = get_render_mode() == "plotly"

        title = "Calibration Curve by Prediction Bins"
        if not self.show_both_scales and self.use_log_scale:
            title += " (ln scale)"

        standard_sample_tabs = []
        hhi_sample_tabs = []
        signals = []

        for payload in sample_payloads:
            standard_html, standard_signal = self._render_standard_sample_panel(
                payload["score"], payload["target"], payload["weight"],
                num_groups, bins_step, scale_specs, use_plotly,
            )
            hhi_html, hhi_signal = self._render_hhi_sample_panel(
                payload["score"], payload["target"], payload["weight"],
                num_groups, bins_step, scale_specs, use_plotly,
                hhi_orange_threshold, hhi_red_threshold,
            )
            signals.extend([standard_signal, hhi_signal])
            standard_sample_tabs.append(
                {
                    "label": payload["label"],
                    "html": standard_html,
                    "color": COLORS['BLUE'] if payload["key"] == "test" else COLORS['GRAY_DARK'],
                }
            )
            hhi_sample_tabs.append(
                {
                    "label": payload["label"],
                    "html": hhi_html,
                    "color": COLORS['BLUE'] if payload["key"] == "test" else COLORS['GRAY_DARK'],
                }
            )

        if len(sample_payloads) > 1:
            standard_html = build_tabbed_sections_html(standard_sample_tabs, root_prefix="m42-standard-sample")
            hhi_html = build_tabbed_sections_html(hhi_sample_tabs, root_prefix="m42-hhi-sample")
        else:
            standard_html = standard_sample_tabs[0]["html"]
            hhi_html = hhi_sample_tabs[0]["html"]

        sig = self._worst_signal(signals)
        self.test_signal = sig
        mode_tabs = [
            {"label": "Standard", "html": standard_html, "color": COLORS['BLUE']},
            {"label": "HHI", "html": hhi_html, "color": COLORS['EMERALD']},
        ]

        html = f"""
        <h4>{title}</h4>
        <p><b>Signal:</b> <span style='color:{sig}; font-weight:bold'>{sig.upper()}</span></p>
        <p><i>Overall signal is the worst signal across rendered modes and samples.</i></p>
        {build_tabbed_sections_html(mode_tabs, root_prefix="m42-mode")}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}
