"""Model-type strategies for SBS Evaluation.

A *strategy* encapsulates which test groups run for a given model type and how
they are parameterised. The runner delegates group selection to the strategy
instead of hardcoding the M0..M5 list, so adding a new model type (e.g.
``GLMTariffFactorStrategy``) becomes a new class instead of an edit to the
runner.

Today the meaningful split is:

- :class:`GLMStrategy`        — frequency / severity / other; runs every group
  M0..M5 *including* M3 multicollinearity (VIF). All current GLM modes share
  the same group list; severity- or frequency-specific differences happen
  *inside* individual tests (e.g. weighting), not in the group composition.

- :class:`BlackBoxStrategy`   — tree-based / non-parametric models; skips M3
  because VIF is undefined without regression coefficients. The BlackBox path
  also has its own dedicated lightweight runner under ``tests_blackbox/`` for
  the methodology-aligned subset; this strategy is the integration point if we
  later collapse both runners into one.

Both strategies build their own :class:`TestGroupBuilder` instances and the
matching ``test_params`` dicts. The runner only iterates them.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, List, Tuple

import pandas as pd

from .base_test import TestGroupBuilder
from .config_validation import SBSConfig


GroupSpec = Tuple[TestGroupBuilder, Dict[str, Dict]]


class BaseModelStrategy(ABC):
    """Interface every concrete strategy implements."""

    @property
    def name(self) -> str:
        return self.__class__.__name__

    @abstractmethod
    def get_test_groups(
        self,
        data: pd.DataFrame,
        cfg: SBSConfig,
        psi_calc,
    ) -> List[GroupSpec]:
        """Return ``[(group, params), ...]`` in execution order.

        Each ``group`` is a fully populated :class:`TestGroupBuilder`; each
        ``params`` is the dict expected by ``group.run_all_tests``.
        """


def select_strategy(cfg: SBSConfig, *, exclude_heavy: bool = False) -> BaseModelStrategy:
    """Pick a strategy based on the validated config.

    Resolution order:

    1. If ``cfg.preset`` is set, ``preset.architecture`` decides — ``"glm"``
       returns :class:`GLMStrategy`, ``"blackbox"`` returns
       :class:`BlackBoxStrategy`.
    2. Otherwise (legacy config) fall back to GLMStrategy, which is what the
       runner used to do unconditionally.

    Parameters
    ----------
    cfg : SBSConfig
        Already-validated config.
    exclude_heavy : bool
        Legacy ``size == "heavy"`` flag: when True, the strategy is asked to
        drop heavy tests (currently M3 in the GLM strategy). Has no effect
        on BlackBoxStrategy (it does not include M3 to begin with).

    Returns
    -------
    BaseModelStrategy
    """
    preset = getattr(cfg, "preset", None)
    if preset is not None and preset.architecture == "blackbox":
        return BlackBoxStrategy()
    return GLMStrategy(exclude_multicollinearity=exclude_heavy)


class GLMStrategy(BaseModelStrategy):
    """GLM frequency / severity / other — full M0..M5 group set.

    ``exclude_multicollinearity=True`` drops the M3 group. This corresponds
    to the historical ``size="heavy"`` shortcut — kept temporarily so the
    runner's external contract is unchanged.
    """

    def __init__(self, *, exclude_multicollinearity: bool = False):
        self.exclude_multicollinearity = exclude_multicollinearity

    def get_test_groups(self, data, cfg, psi_calc) -> List[GroupSpec]:
        # Local imports to keep the strategy file decoupled from concrete test classes.
        from ..tests.m0_data_quality import (
            M01_DataQualityOverviewTest,
            M04_MonthlyDistributionsTest,
            M05_ModeAndMissingByPeriodTest,
        )
        from ..tests.m1_distribution_tests import (
            M11_TrainVsGenpopPSITest,
            M12_OOSVsGenpopPSITest,
            M13_MaxDateRecencyTest,
        )
        from ..tests.m2_gini_tests import (
            M21_GiniTest,
            M22_GiniFactorsTest,
            M23_GiniDynamicsTest,
            M24_GiniUpliftTest,
        )
        from ..tests.m3_multicollinearity import (
            M31_LikelihoodRatioTest,
            M32_MulticollinearityTest,
        )
        from ..tests.m4_model_performance import (
            M41_TargetRateTest,
            M42_CalibrationCurveByPredictBinsLn,
            M43_CalibrationCurveByDatesLn,
        )
        from ..tests.m5_model_stability import (
            M51_ModelGiniStabilityTest,
            M52_FactorGiniStabilityTest,
            M53_ScorePSITest,
            M54_FactorPSITest,
        )

        groups: List[GroupSpec] = []

        # ---- M0: Data Quality ----
        g0 = TestGroupBuilder(group_code="M0", group_name="M0. Data Quality")
        g0.add_test(M01_DataQualityOverviewTest())
        g0.add_test(M04_MonthlyDistributionsTest())
        g0.add_test(M05_ModeAndMissingByPeriodTest())
        groups.append((g0, {
            "M 0.1": {"df": data, "config": cfg},
            "M 0.4": {"df": data, "config": cfg},
            "M 0.5": {"df": data, "config": cfg},
        }))

        # ---- M1: Distribution ----
        g1 = TestGroupBuilder(group_code="M1", group_name="M1. Distribution")
        g1.add_test(M11_TrainVsGenpopPSITest(psi_calc=psi_calc))
        g1.add_test(M12_OOSVsGenpopPSITest(psi_calc=psi_calc))
        g1.add_test(M13_MaxDateRecencyTest())
        groups.append((g1, {
            "M 1.1": {"df": data, "config": cfg},
            "M 1.2": {"df": data, "config": cfg},
            "M 1.3": {"df": data, "config": cfg},
        }))

        # ---- M2: Gini ----
        g2 = TestGroupBuilder(group_code="M2", group_name="M2. Gini")
        g2.add_test(M21_GiniTest())
        g2.add_test(M22_GiniFactorsTest())
        g2.add_test(M23_GiniDynamicsTest())
        g2.add_test(M24_GiniUpliftTest())
        groups.append((g2, {
            "M 2.1": {"df": data, "config": cfg},
            "M 2.2": {"df": data, "config": cfg},
            "M 2.3": {"df": data, "config": cfg},
            "M 2.4": {"df": data, "config": cfg},
        }))

        # ---- M3: Multicollinearity (GLM-only) ----
        if not self.exclude_multicollinearity:
            g3 = TestGroupBuilder(group_code="M3", group_name="M3. Multicollinearity")
            g3.add_test(M31_LikelihoodRatioTest())
            g3.add_test(M32_MulticollinearityTest())
            groups.append((g3, {
                "M 3.1": {"df": data, "config": cfg},
                "M 3.2": {"df": data, "config": cfg},
            }))

        # ---- M4: Calibration ----
        # Each test shows Test/Train/All sample tabs; the overall flag is taken
        # from the Test sample.
        #   M4.2 — Standard+HHI modes, both scales (lin+log), AUTO binning
        #          (count + exposure quantiles), 10 groups;
        #   M4.3 — periods W/M/Q, both scales (lin+log)
        #          (8 buttons: Test/Train/All + Weekly/Monthly/Quarterly + Linear/Log).
        g4 = TestGroupBuilder(group_code="M4", group_name="M4. Calibration")
        g4.add_test(M41_TargetRateTest())
        g4.add_test(M42_CalibrationCurveByPredictBinsLn())
        g4.add_test(M43_CalibrationCurveByDatesLn())
        groups.append((g4, {
            "M 4.1": {"df": data, "config": cfg, "show_sample_tabs": True},
            "M 4.2": {"df": data, "config": cfg, "num_groups": 10, "show_sample_tabs": True},
            "M 4.3": {"df": data, "config": cfg, "show_sample_tabs": True},
        }))

        # ---- M5: Stability ----
        g5 = TestGroupBuilder(group_code="M5", group_name="M5. Stability")
        g5.add_test(M51_ModelGiniStabilityTest())
        g5.add_test(M52_FactorGiniStabilityTest())
        g5.add_test(M53_ScorePSITest(psi_calc=psi_calc))
        g5.add_test(M54_FactorPSITest(psi_calc=psi_calc))
        groups.append((g5, {
            "M 5.1": {"df": data, "config": cfg},
            "M 5.2": {"df": data, "config": cfg},
            "M 5.3": {"df": data, "config": cfg},
            "M 5.4": {"df": data, "config": cfg},
        }))

        return groups


class BlackBoxStrategy(BaseModelStrategy):
    """BlackBox / tree-based — replaces M3 with SHAP drift + permutation placeholder.

    VIF and likelihood-ratio tests have no meaning without regression
    coefficients. Per Часть 100 §M3 the BlackBox group instead runs:

    - M3.1 — Permutation feature significance (informational; placeholder
      until we settle on the model-object input contract).
    - M3.2 — SHAP importance drift train vs validation, using pre-computed
      SHAP scalars supplied via ``config['shap_importance']``.

    Other groups (M0, M1, M2, M4, M5) are reused from the GLM strategy.
    """

    def get_test_groups(self, data, cfg, psi_calc) -> List[GroupSpec]:
        from ..tests.m3_blackbox import (
            BBM31_PermutationPlaceholderTest,
            BBM32_ShapDriftTest,
        )

        groups = GLMStrategy(exclude_multicollinearity=True).get_test_groups(
            data, cfg, psi_calc
        )

        m3_group = TestGroupBuilder(group_code="M3", group_name="M3. Specification (BlackBox)")
        m3_group.add_test(BBM31_PermutationPlaceholderTest())
        m3_group.add_test(BBM32_ShapDriftTest())
        m3_params = {
            "M 3.1": {"df": data, "config": cfg},
            "M 3.2": {"df": data, "config": cfg},
        }
        # Insert M3 between M2 and M4 to keep the canonical M0..M5 order.
        groups.insert(3, (m3_group, m3_params))
        return groups
