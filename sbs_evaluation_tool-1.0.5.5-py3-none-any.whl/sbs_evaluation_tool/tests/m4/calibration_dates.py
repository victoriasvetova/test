# -*- coding: utf-8 -*-
"""Auto-extracted from ``tests/m4_model_performance.py`` in the Phase 2 split.

See ``tests/m4/__init__.py`` for the package overview.
"""

from __future__ import annotations
import base64
from io import BytesIO
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import logging

from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score, r2_score, mean_squared_error
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
from sklearn.utils.multiclass import type_of_target

from ...core.base_test import BaseModelTest
from ...core.metrics import gini_normalized, bootstrap_values
from ...core.styles import COLORS, STATUS_COLORS, figure
from ...core.render_context import get_render_mode
from ...core.config_validation import validate_config as _validate_config, ConfigValidationError
from ...core.data_utils import (
    ensure_config,
    split_frames,
    split_sample_masks,
    get_weight_col,
    get_col_name,
    get_vectors,
    get_features,
    get_model_mode,
    is_binary_mode,
    is_big_data_mode,
    is_generic_classification_mode,
    sample_frame_for_big_data,
)
from .._visual_utils import (
    MEAN_RATE_LABEL,
    OBSERVATION_COUNT_LABEL,
    SHARE_LABEL,
    build_tabbed_sections_html,
    build_period_specs,
    build_scale_specs,
    figure_to_base64,
)

import matplotlib.dates as mdates
from math import log

from ._shared import (
    _classification_mode_na,
    _subset_by_sample,
    _safe_threshold_labels,
    _to_base64,
    calibration_traffic_light,
)

logger = logging.getLogger(__name__)


class M43_CalibrationCurveByDatesLn(BaseModelTest):
    """Калибровка по времени.

    Поведение по умолчанию:
    - period=None: строятся месяцы и кварталы
    - для каждой разбивки строятся обычный и логарифмический графики

    Для inline-использования можно передать period='W' | 'M' | 'Q', чтобы
    отрисовать только одну временную разбивку.
    """
    def __init__(
        self,
        test_num='M 4.3',
        test_name='Calibration Curve (Dates)',
        use_log_scale: bool = False,
        show_both_scales: bool = True,
    ):
        resolved_name = test_name
        if not show_both_scales and use_log_scale:
            resolved_name += ' (ln scale)'
        super().__init__(test_num, resolved_name)
        self.use_log_scale = use_log_scale
        self.show_both_scales = show_both_scales

    @staticmethod
    def _safe_log(x):
        x = np.asarray(x, dtype=float)
        return np.log(np.clip(x, 1e-12, None))

    @staticmethod
    def _format_period_label(period_value, period: str) -> str:
        if pd.isna(period_value):
            return ""
        if period == 'M':
            return f"{period_value.year}-{period_value.month:02d}"
        if period == 'Q':
            return f"{period_value.year}-Q{period_value.quarter}"
        if period == 'W':
            return period_value.start_time.strftime('%Y-%m-%d')
        return str(period_value)

    @staticmethod
    def _ci_bands_around_prediction(grouped: pd.DataFrame, model_mode: str) -> tuple[pd.Series, pd.Series, pd.Series, pd.Series]:
        """CI вокруг прогнозного среднего — идентично M4.2 (методология: M4.3 «аналогично M4.2»).

        frequency/poisson: SE = sqrt(λ̂ / Σw); binary: биномиальная SE;
        severity/regression: std_true / sqrt(n).
        """
        center = pd.to_numeric(grouped["mean_pred"], errors="coerce").astype(float)
        n = pd.to_numeric(grouped["count"], errors="coerce").replace(0, np.nan).astype(float)
        mode = str(model_mode or "").lower()

        if mode in {"binary", "classification", "binomial"}:
            p = center.clip(0, 1)
            se = np.sqrt((p * (1 - p)).clip(lower=0) / n)
            lower_bound = 0.0
        elif mode in {"frequency", "poisson"}:
            se = np.sqrt(center.clip(lower=0) / n)
            lower_bound = 0.0
        else:
            std = pd.to_numeric(grouped["std_true"], errors="coerce").fillna(0.0).astype(float)
            se = std / np.sqrt(n)
            lower_bound = -np.inf

        ci95_low = (center - 1.96 * se).clip(lower=lower_bound)
        ci95_high = center + 1.96 * se
        ci99_low = (center - 2.58 * se).clip(lower=lower_bound)
        ci99_high = center + 2.58 * se
        return ci95_low, ci95_high, ci99_low, ci99_high

    def _group(self, date: pd.Series, score: pd.Series, target: pd.Series,
               weight: Optional[pd.Series], period: str) -> pd.DataFrame:
        try:
            date_converted = pd.to_datetime(date, errors='coerce')
        except Exception:
            # If conversion fails, return empty DataFrame
            return pd.DataFrame()
        
        df = pd.DataFrame({"date": date_converted, "score": score, "target": target}).dropna(subset=['date'])
        if df.empty:
            return df
            
        period = str(period).upper()
        if period not in {'W', 'M', 'Q'}:
            raise ValueError("period должен быть одним из: 'W', 'M', 'Q'")

        if weight is not None:
            w = pd.to_numeric(weight, errors="coerce").reindex(df.index).fillna(0.0)
            df["weight"] = w
        if "weight" in df.columns:
            grouped = df.groupby(df['date'].dt.to_period(period)).apply(
                lambda g: pd.Series({
                    "count": float(g["weight"].sum()),
                    # Для страховой частоты: observed rate = sum(events) / sum(exposure)
                    "mean_true": float(g["target"].sum() / g["weight"].sum()) if g["weight"].sum() > 0 else 0.0,
                    # Для predicted: взвешенное среднее = sum(score * exposure) / sum(exposure)
                    "mean_pred": float(np.average(g["score"], weights=g["weight"])),
                    # Для rate стандартное отклонение
                    "std_true": float(np.sqrt(np.sum((g["target"] - (g["target"].sum() / g["weight"].sum()) * g["weight"]) ** 2 / g["weight"]) / len(g)) if g["weight"].sum() > 0 and np.all(g["weight"] > 0) else g["target"].std()),
                })
            ).reset_index()
        else:
            grouped = df.groupby(df['date'].dt.to_period(period)).agg(
                count=("target", "count"),
                mean_true=("target", "mean"),
                mean_pred=("score", "mean"),
                std_true=("target", "std"),
            ).reset_index()
        grouped['date_str'] = grouped['date'].apply(lambda p: self._format_period_label(p, period))
        return grouped

    def _plot(self, grouped: pd.DataFrame, mode: str, title_suffix: str, use_log_scale: bool) -> tuple[str, Dict[str, bool]]:
        fig, ax1 = figure(size="short")
        x = np.arange(len(grouped))
        labels = grouped['date_str'].tolist()

        # CI вокруг прогнозного среднего — как в M4.2 (методология: «аналогично M4.2»).
        ci95_low, ci95_high, ci99_low, ci99_high = self._ci_bands_around_prediction(grouped, mode)

        if use_log_scale:
            y_obs = self._safe_log(grouped['mean_true'])
            y_pred = self._safe_log(grouped['mean_pred'])
            ci99_l = self._safe_log(ci99_low)
            ci99_h = self._safe_log(ci99_high)
            ci95_l = self._safe_log(ci95_low)
            ci95_h = self._safe_log(ci95_high)
            ylabel = "ln(Mean Rate)"
        else:
            y_obs = grouped['mean_true']
            y_pred = grouped['mean_pred']
            ci99_l = ci99_low
            ci99_h = ci99_high
            ci95_l = ci95_low
            ci95_h = ci95_high
            ylabel = MEAN_RATE_LABEL

        ax1.fill_between(x, ci99_l, ci99_h, color=COLORS['RED'], alpha=0.30, label="99% CI")
        ax1.fill_between(x, ci95_l, ci95_h, color=COLORS['ORANGE'], alpha=0.45, label="95% CI")

        obs_label = "Observed mean (ln)" if use_log_scale else "Observed mean"
        pred_label = "Predicted mean (ln)" if use_log_scale else "Predicted mean"
        ax1.plot(x, y_pred, label=pred_label, color="#111111", linewidth=2)
        ax1.scatter(x, y_obs, label=obs_label, color=COLORS['BLUE'], s=48, zorder=5)

        red_mask = (grouped['mean_true'] > ci99_high) | (grouped['mean_true'] < ci99_low)
        if np.any(red_mask):
            ax1.scatter(np.where(red_mask)[0], y_obs[red_mask], color=COLORS['RED'], marker='*',
                        s=120, zorder=6, label="Observed outside 99% CI")

        ax1.set_xlabel("Period")
        ax1.set_ylabel(ylabel)
        ax1.set_xticks(x)
        ax1.set_xticklabels(labels, rotation=45, ha='right')
        ax1.set_title(f"Calibration Over Time - {title_suffix}")
        ax1.grid(True, linestyle='--', alpha=0.3)

        ax2 = ax1.twinx()
        share_pct = grouped['count'] / max(1.0, grouped['count'].sum()) * 100.0
        ax2.bar(x, share_pct, alpha=0.35, color=COLORS['EMERALD'], label="Share (%)")
        ax2.set_ylabel(f"{SHARE_LABEL} (%)")

        ax1.legend(loc='upper left')
        ax2.legend(loc='upper right')
        plt.tight_layout()
        img_b64 = figure_to_base64(fig)
        plt.close(fig)

        out95_mask = (grouped['mean_true'] > ci95_high) | (grouped['mean_true'] < ci95_low)
        orange_only_mask = out95_mask & (~red_mask)
        flags = {
            'n_bins': int(len(grouped)),
            'n_out_95': int(out95_mask.sum()),
            'n_out_99': int(red_mask.sum()),
            'any_red':    bool(np.any(red_mask)),
            'any_orange': bool(np.any(orange_only_mask)),
        }
        return img_b64, flags

    def _plot_plotly(self, grouped: pd.DataFrame, mode: str, title_suffix: str, use_log_scale: bool) -> tuple[str, Dict[str, bool]]:
        """Plotly-вариант ``_plot``. Возвращает (html_div, flags)."""
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots

        labels = grouped['date_str'].tolist()
        ci95_low, ci95_high, ci99_low, ci99_high = self._ci_bands_around_prediction(grouped, mode)

        if use_log_scale:
            y_obs = self._safe_log(grouped['mean_true'])
            y_pred = self._safe_log(grouped['mean_pred'])
            ci99_l = self._safe_log(ci99_low)
            ci99_h = self._safe_log(ci99_high)
            ci95_l = self._safe_log(ci95_low)
            ci95_h = self._safe_log(ci95_high)
            ylabel = "ln(Mean Rate)"
        else:
            y_obs = grouped['mean_true']
            y_pred = grouped['mean_pred']
            ci99_l = ci99_low
            ci99_h = ci99_high
            ci95_l = ci95_low
            ci95_h = ci95_high
            ylabel = MEAN_RATE_LABEL

        red_mask = (grouped['mean_true'] > ci99_high) | (grouped['mean_true'] < ci99_low)
        orange_mask = ((grouped['mean_true'] > ci95_high) | (grouped['mean_true'] < ci95_low)) & (~red_mask)

        fig = make_subplots(specs=[[{"secondary_y": True}]])

        share_pct = (grouped['count'] / max(1.0, grouped['count'].sum()) * 100.0).to_numpy()
        fig.add_trace(
            go.Bar(x=labels, y=share_pct, name=f"{SHARE_LABEL} (%)",
                   marker=dict(color=COLORS['EMERALD']), opacity=0.35,
                   hovertemplate="%{x}<br>Share: %{y:.1f}%<extra></extra>"),
            secondary_y=True,
        )

        fig.add_trace(go.Scatter(x=labels, y=ci99_l, mode="lines",
                                 line=dict(width=0), hoverinfo="skip", showlegend=False),
                      secondary_y=False)
        fig.add_trace(go.Scatter(x=labels, y=ci99_h, mode="lines",
                                 line=dict(width=0), fill="tonexty",
                                 fillcolor="rgba(250,25,41,0.25)", name="99% CI",
                                 hoverinfo="skip"),
                      secondary_y=False)
        fig.add_trace(go.Scatter(x=labels, y=ci95_l, mode="lines",
                                 line=dict(width=0), hoverinfo="skip", showlegend=False),
                      secondary_y=False)
        fig.add_trace(go.Scatter(x=labels, y=ci95_h, mode="lines",
                                 line=dict(width=0), fill="tonexty",
                                 fillcolor="rgba(255,204,0,0.45)", name="95% CI",
                                 hoverinfo="skip"),
                      secondary_y=False)

        obs_label = "Observed mean (ln)" if use_log_scale else "Observed mean"
        pred_label = "Predicted mean (ln)" if use_log_scale else "Predicted mean"
        fig.add_trace(go.Scatter(x=labels, y=y_pred, mode="lines+markers",
                                 name=pred_label,
                                 line=dict(color="#111111", width=2),
                                 marker=dict(size=5, color="#111111"),
                                 hovertemplate="%{x}<br>Predicted: %{y:.5f}<extra></extra>"),
                      secondary_y=False)
        fig.add_trace(go.Scatter(x=labels, y=y_obs, mode="lines+markers",
                                 name=obs_label,
                                 line=dict(color=COLORS['BLUE'], width=2),
                                 marker=dict(size=8, color=COLORS['BLUE']),
                                 hovertemplate="%{x}<br>Observed: %{y:.5f}<extra></extra>"),
                      secondary_y=False)

        red_idx = np.where(red_mask)[0]
        if red_idx.size:
            fig.add_trace(go.Scatter(
                x=[labels[i] for i in red_idx],
                y=[y_obs.iloc[i] if hasattr(y_obs, "iloc") else y_obs[i] for i in red_idx],
                mode="markers", name="Observed outside 99% CI",
                marker=dict(symbol="star", size=15, color=COLORS['RED'])),
                secondary_y=False)

        fig.update_layout(
            title=dict(text=f"Calibration Over Time - {title_suffix}", font=dict(size=15)),
            template="plotly_white",
            hovermode="x unified",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
            margin=dict(l=60, r=60, t=80, b=110),
            height=440,
        )
        fig.update_xaxes(title_text="Period", tickangle=-45)
        fig.update_yaxes(title_text=ylabel, secondary_y=False)
        fig.update_yaxes(title_text=f"{SHARE_LABEL} (%)", secondary_y=True, showgrid=False)

        html = fig.to_html(include_plotlyjs="cdn", full_html=False, config={"displaylogo": False})
        out95_mask = (grouped['mean_true'] > ci95_high) | (grouped['mean_true'] < ci95_low)
        flags = {
            'n_bins': int(len(grouped)),
            'n_out_95': int(out95_mask.sum()),
            'n_out_99': int(red_mask.sum()),
            'any_red':    bool(np.any(red_mask)),
            'any_orange': bool(np.any(orange_mask)),
        }
        return html, flags

    def _render_sample(self, date_column, score_column, target_column, w_series, model_mode,
                       period_specs, scale_specs, use_plotly) -> tuple[str, str]:
        """Render period (M/Q) + scale tabs for a single sample.

        Returns ``(sample_html, signal)``. Signal uses the Q grouping when present
        (else the first non-empty period) via the binomial Табл. 6.20 rule.
        """
        if date_column is None or target_column is None or score_column is None:
            return "<p><i>Missing date/score/target data.</i></p>", "blue"
        score_column = pd.Series(score_column)
        target_column = pd.Series(target_column)
        if not pd.api.types.is_numeric_dtype(score_column) or not pd.api.types.is_numeric_dtype(target_column):
            raise ValueError("Score and target must be numeric.")
        if score_column.isnull().any() or target_column.isnull().any():
            raise ValueError("Score and target must not contain NaN values.")

        period_tabs = []
        period_flags = {}
        non_empty_periods = 0
        for period_code, period_title in period_specs:
            grouped = self._group(date_column, score_column, target_column, w_series, period=period_code)
            if grouped.empty:
                continue
            non_empty_periods += 1
            scale_tabs = []
            for idx, (scale_flag, scale_title) in enumerate(scale_specs):
                if use_plotly:
                    tab_html, flags = self._plot_plotly(grouped, model_mode, period_title, use_log_scale=scale_flag)
                else:
                    img_b64, flags = self._plot(grouped, model_mode, period_title, use_log_scale=scale_flag)
                    tab_html = f"<img src='data:image/png;base64,{img_b64}' style='display:block; width:100%; max-width:1100px; height:auto;' />"
                if idx == 0:
                    period_flags[period_code] = flags
                scale_tabs.append(
                    {
                        "label": scale_title,
                        "html": tab_html,
                        "color": COLORS['BLUE'] if not scale_flag else COLORS['EMERALD'],
                    }
                )
            period_tabs.append(
                {
                    "label": period_title,
                    "html": build_tabbed_sections_html(scale_tabs, root_prefix=f"m43-scale-{period_code.lower()}"),
                    "color": COLORS['BLUE'],
                }
            )

        if non_empty_periods == 0:
            return "<p><i>No data available for the selected grouping.</i></p>", "blue"

        signal_period = 'Q' if 'Q' in period_flags else next(iter(period_flags))
        signal_flags = period_flags[signal_period]
        signal_period_label = dict(period_specs).get(signal_period, signal_period)
        # Traffic light per methodology Табл. 6.20 (same rule as M4.2).
        n_bins = int(signal_flags.get('n_bins', 0))
        n_out_95 = int(signal_flags.get('n_out_95', 0))
        n_out_99 = int(signal_flags.get('n_out_99', 0))
        sig, thresholds = calibration_traffic_light(n_bins, n_out_95, n_out_99)
        counts_html = (
            f"<p><i>Signal computed on <b>{signal_period_label}</b> grouping · "
            f"Bins: {n_bins} · outside 95 % CI: {n_out_95} "
            f"(critical orange={thresholds.get('k95_orange','-')} / red={thresholds.get('k99_orange','-')}) "
            f"· outside 99 % CI: {n_out_99} "
            f"(critical orange={thresholds.get('k95_red','-')} / red={thresholds.get('k99_red','-')})</i></p>"
        )
        # Single traffic light only — shown once in the test header. The panel
        # keeps the informational counts but no coloured signal badge.
        html = f"""
        {counts_html}
        <p><i>Final signal is based on the {signal_period_label} breakdown.</i></p>
        {build_tabbed_sections_html(period_tabs, root_prefix="m43-period")}
        """
        return html, sig

    def run(self, df: Optional[pd.DataFrame] = None, config: Optional[dict] = None,
            date_column: Optional[pd.Series] = None, score_column: Optional[pd.Series] = None,
            target_column: Optional[pd.Series] = None, sample: str = 'genpop',
            period: Optional[str] = None, show_sample_tabs: bool = True, **kwargs) -> Dict[str, str]:
        """Config path renders Test/Train/All tabs (``show_sample_tabs=True``) and
        reports the flag computed on the **Test** sample. Direct path
        (``date_column=``/``score_column=``/``target_column=``) renders one panel.
        """
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # Distribution dispatch identical to M4.1/M4.2: preset wins, then
        # explicit kwargs, then type_of_target fallback (set below).
        mode_aliases = {
            'gamma': 'severity',
            'poisson': 'frequency',
            'binomial': 'binary',
            'classification': 'binary',
        }
        model_mode = str(kwargs.get('distribution') or kwargs.get('model_mode') or '').lower() or None
        model_mode = mode_aliases.get(model_mode, model_mode)

        requested_period = None if period is None else str(period).upper()
        if requested_period not in {None, 'W', 'M', 'Q'}:
            raise ValueError("period must be None, 'W', 'M', or 'Q'.")

        title = "Calibration Curve by Dates"
        if not self.show_both_scales and self.use_log_scale:
            title += " (ln scale)"

        sample_payloads = []
        # Config-driven path
        if df is not None and config is not None:
            try:
                cfg = ensure_config(config, df)
                if is_generic_classification_mode(cfg):
                    self.test_signal = 'blue'
                    logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                    return _classification_mode_na(self.test_name)
                preset = getattr(cfg, "preset", None)
                if preset is not None:
                    model_mode = mode_aliases.get(preset.calibration_distribution, preset.calibration_distribution)
                else:
                    model_mode = get_model_mode(cfg)
                dcol = getattr(cfg.columns, 'date_column', None)
                scol = getattr(cfg.columns, 'score_column', None)
                tcol = getattr(cfg.columns, 'target_column', None)
                weight_col = getattr(cfg.columns, 'weight_column', None)
                if dcol is None or dcol not in df.columns:
                    self.test_signal = 'blue'
                    logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                    return {"combined": f"<h4>{title}</h4><p>date_column is missing in the data.</p>"}
                if is_big_data_mode(cfg):
                    train_mask, test_mask = split_sample_masks(df, cfg)
                    needed_cols = [dcol, scol, tcol, weight_col]
                    needed_cols = list(dict.fromkeys([c for c in needed_cols if c and c in df.columns]))
                    df_small = df.loc[:, needed_cols]
                    df_tr = sample_frame_for_big_data(df_small.loc[train_mask], cfg, max_rows=250_000, random_state=431).copy()
                    df_te = sample_frame_for_big_data(df_small.loc[test_mask], cfg, max_rows=250_000, random_state=432).copy()
                    df_all = sample_frame_for_big_data(df_small, cfg, max_rows=350_000, random_state=433).copy()
                else:
                    df_tr, df_te, df_all = split_frames(df, cfg)

                if show_sample_tabs:
                    sample_frames = [("test", "Test", df_te), ("train", "Train", df_tr), ("all", "All", df_all)]
                else:
                    sample_map = {
                        "train": ("train", "Train", df_tr),
                        "test": ("test", "Test", df_te),
                        "genpop": ("all", "All", df_all),
                        "all": ("all", "All", df_all),
                    }
                    sample_frames = [sample_map.get(str(sample).lower(), ("all", "All", df_all))]

                for key, label, df_used in sample_frames:
                    sample_payloads.append({
                        "key": key, "label": label,
                        "date": df_used[dcol], "target": df_used[tcol], "score": df_used[scol],
                        "w": get_weight_col(df_used, cfg),
                    })
            except Exception as e:
                self.test_signal = 'red'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"combined": f"<h4>{title}</h4><p>Config error: {str(e)}</p>"}
        else:
            # Backward-compatible direct path: single panel, no sample tabs.
            if score_column is None or target_column is None or date_column is None:
                self.test_signal = 'red'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"combined": f"<h4>{title}</h4><p>Missing date/score/target data.</p>"}
            if not (len(score_column) == len(target_column) == len(date_column)):
                raise ValueError("date, score, and target must have the same length.")
            if model_mode is None:
                model_mode = 'binary' if type_of_target(target_column) == 'binary' else 'regression'
                model_mode = mode_aliases.get(model_mode, model_mode)
            sample_payloads.append({
                "key": "all", "label": "All",
                "date": date_column, "target": target_column, "score": score_column, "w": None,
            })

        if model_mode is None:
            model_mode = 'binary' if type_of_target(sample_payloads[0]["target"]) == 'binary' else 'regression'
        model_mode = mode_aliases.get(model_mode, model_mode)

        period_specs = build_period_specs(requested_period)
        scale_specs = build_scale_specs(self.show_both_scales, self.use_log_scale)
        use_plotly = get_render_mode() == "plotly"

        tabs = []
        signal_by_key = {}
        for p in sample_payloads:
            try:
                sample_html, sig = self._render_sample(
                    p["date"], p["score"], p["target"], p["w"], model_mode,
                    period_specs, scale_specs, use_plotly,
                )
            except Exception as e:
                sample_html, sig = f"<p><i>Ошибка расчёта по выборке {p['label']}: {e}</i></p>", "red"
            signal_by_key[p["key"]] = sig
            tabs.append({
                "label": p["label"],
                "html": sample_html,
                "color": COLORS['BLUE'] if p["key"] == "test" else COLORS['GRAY_DARK'],
            })

        # Итоговый флаг — по выборке Test (fallback: All, затем первая доступная).
        overall = signal_by_key.get("test") or signal_by_key.get("all") or next(iter(signal_by_key.values()))
        self.test_signal = overall

        # Always wrap samples in tab buttons (even a single Test sample) so the
        # report shows a labelled button, consistent with M4.1/M4.2.
        body = build_tabbed_sections_html(tabs, root_prefix="m43-sample")
        if len(tabs) > 1:
            signal_label = "Signal (Test)"
            flag_note = "<p><i>Итоговый флаг теста рассчитан по выборке <b>Test</b>.</i></p>"
        else:
            signal_label = "Signal"
            flag_note = "<p><i>Показана выборка <b>" + tabs[0]["label"] + "</b>.</i></p>"

        html = f"""
        <h4>{title}</h4>
        <p><b>{signal_label}:</b> <span style='color:{overall}; font-weight:bold'>{overall.upper()}</span></p>
        {flag_note}
        {body}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


